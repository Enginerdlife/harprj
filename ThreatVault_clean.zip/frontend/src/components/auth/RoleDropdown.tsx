import React from 'react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { UserRole } from '@/contexts/AuthContext';

interface RoleDropdownProps {
  value: UserRole;
  onChange: (value: UserRole) => void;
  disabled?: boolean;
}

const roles: { value: UserRole; label: string; description: string }[] = [
  { value: 'student', label: 'Student', description: 'Limited access, no verification required' },
  { value: 'employee', label: 'Employee', description: 'Standard employee access' },
  { value: 'manager', label: 'Manager', description: 'Team management access' },
  { value: 'administrator', label: 'Administrator', description: 'Full system access' },
  { value: 'it_support', label: 'IT Support', description: 'Technical support access' },
  { value: 'auditor', label: 'Auditor', description: 'Audit and logs access' },
  { value: 'compliance_officer', label: 'Compliance Officer', description: 'Compliance monitoring' },
  { value: 'security_analyst', label: 'Security Analyst', description: 'Security monitoring' },
  { value: 'hr', label: 'HR', description: 'Human resources access' },
  { value: 'custom', label: 'Custom Role', description: 'Custom permissions' },
];

const RoleDropdown: React.FC<RoleDropdownProps> = ({ value, onChange, disabled }) => {
  return (
    <Select value={value} onValueChange={(val) => onChange(val as UserRole)} disabled={disabled}>
      <SelectTrigger className="w-full">
        <SelectValue placeholder="Select your role" />
      </SelectTrigger>
      <SelectContent>
        {roles.map((role) => (
          <SelectItem key={role.value} value={role.value}>
            <div className="flex flex-col">
              <span className="font-medium">{role.label}</span>
              <span className="text-xs text-muted-foreground">{role.description}</span>
            </div>
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
};

export default RoleDropdown;
