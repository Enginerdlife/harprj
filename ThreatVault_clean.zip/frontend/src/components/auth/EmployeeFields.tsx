import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Building2, Hash, Briefcase } from 'lucide-react';

interface EmployeeFieldsProps {
  employeeId: string;
  orgCode: string;
  department: string;
  onEmployeeIdChange: (value: string) => void;
  onOrgCodeChange: (value: string) => void;
  onDepartmentChange: (value: string) => void;
  errors?: {
    employeeId?: string;
    orgCode?: string;
    department?: string;
  };
}

const EmployeeFields: React.FC<EmployeeFieldsProps> = ({
  employeeId,
  orgCode,
  department,
  onEmployeeIdChange,
  onOrgCodeChange,
  onDepartmentChange,
  errors,
}) => {
  return (
    <div className="space-y-4 animate-fade-in">
      <div className="p-4 rounded-lg bg-muted/50 border border-border">
        <p className="text-sm text-muted-foreground mb-4">
          Employee verification required. Please provide your organization details.
        </p>
        
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="employeeId" className="flex items-center gap-2">
              <Hash className="h-4 w-4 text-muted-foreground" />
              Employee ID
            </Label>
            <Input
              id="employeeId"
              value={employeeId}
              onChange={(e) => onEmployeeIdChange(e.target.value)}
              placeholder="Enter your employee ID"
              className={errors?.employeeId ? 'border-destructive' : ''}
            />
            {errors?.employeeId && (
              <p className="text-xs text-destructive">{errors.employeeId}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="orgCode" className="flex items-center gap-2">
              <Building2 className="h-4 w-4 text-muted-foreground" />
              Organization Code
            </Label>
            <Input
              id="orgCode"
              value={orgCode}
              onChange={(e) => onOrgCodeChange(e.target.value)}
              placeholder="Enter your organization code"
              className={errors?.orgCode ? 'border-destructive' : ''}
            />
            {errors?.orgCode && (
              <p className="text-xs text-destructive">{errors.orgCode}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="department" className="flex items-center gap-2">
              <Briefcase className="h-4 w-4 text-muted-foreground" />
              Department
            </Label>
            <Input
              id="department"
              value={department}
              onChange={(e) => onDepartmentChange(e.target.value)}
              placeholder="Enter your department"
              className={errors?.department ? 'border-destructive' : ''}
            />
            {errors?.department && (
              <p className="text-xs text-destructive">{errors.department}</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmployeeFields;
