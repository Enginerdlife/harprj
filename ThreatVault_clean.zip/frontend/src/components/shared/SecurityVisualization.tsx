import React, { useState, useEffect } from 'react';

const SecurityVisualization: React.FC = () => {
  const [animationActive, setAnimationActive] = useState(true);

  useEffect(() => {
    setAnimationActive(true);
  }, []);

  return (
    <div className="relative w-full h-full min-h-[400px] flex items-center justify-center overflow-hidden">
      <svg
        viewBox="0 0 400 400"
        width="100%"
        height="100%"
        className="max-w-md"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <linearGradient id="securityGrad1" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" style={{ stopColor: 'hsl(var(--primary))', stopOpacity: 1 }} />
            <stop offset="100%" style={{ stopColor: 'hsl(var(--primary) / 0.6)', stopOpacity: 1 }} />
          </linearGradient>
          <linearGradient id="securityGrad2" x1="0%" y1="100%" x2="100%" y2="0%">
            <stop offset="0%" style={{ stopColor: 'hsl(280 100% 50%)', stopOpacity: 0.8 }} />
            <stop offset="100%" style={{ stopColor: 'hsl(var(--primary) / 0.4)', stopOpacity: 0.4 }} />
          </linearGradient>
          <filter id="securityGlow">
            <feGaussianBlur stdDeviation="2" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
          <style>
            {`
              @keyframes rotate {
                from { transform: rotate(0deg); }
                to { transform: rotate(360deg); }
              }
              @keyframes pulse {
                0%, 100% { opacity: 0.4; }
                50% { opacity: 1; }
              }
              @keyframes float {
                0%, 100% { transform: translateY(0px); }
                50% { transform: translateY(-20px); }
              }
              .spin-slow {
                animation: rotate 20s linear infinite;
                transform-origin: 200px 200px;
              }
              .pulse-glow {
                animation: pulse 2s ease-in-out infinite;
              }
              .float-elem {
                animation: float 3s ease-in-out infinite;
              }
            `}
          </style>
        </defs>

        {/* Background circles */}
        <circle cx="200" cy="200" r="180" fill="none" stroke="url(#securityGrad2)" strokeWidth="1" opacity="0.3" />
        <circle cx="200" cy="200" r="140" fill="none" stroke="url(#securityGrad1)" strokeWidth="1" opacity="0.2" />

        {/* Rotating outer ring with data points */}
        <g className="spin-slow">
          <circle cx="200" cy="60" r="6" fill="hsl(var(--primary))" opacity="0.8" />
          <circle cx="320" cy="120" r="6" fill="hsl(var(--primary))" opacity="0.8" />
          <circle cx="340" cy="200" r="6" fill="hsl(var(--primary))" opacity="0.8" />
          <circle cx="320" cy="280" r="6" fill="hsl(var(--primary))" opacity="0.8" />
          <circle cx="200" cy="340" r="6" fill="hsl(var(--primary))" opacity="0.8" />
          <circle cx="80" cy="280" r="6" fill="hsl(var(--primary))" opacity="0.8" />
          <circle cx="60" cy="200" r="6" fill="hsl(var(--primary))" opacity="0.8" />
          <circle cx="80" cy="120" r="6" fill="hsl(var(--primary))" opacity="0.8" />
        </g>

        {/* Center shield with encryption pattern */}
        <g filter="url(#securityGlow)">
          {/* Shield outline */}
          <path
            d="M 200 100 L 280 140 L 280 220 Q 200 300 200 300 Q 120 300 120 220 L 120 140 Z"
            fill="url(#securityGrad1)"
            stroke="hsl(var(--primary))"
            strokeWidth="2.5"
            opacity="0.95"
          />

          {/* Inner shield gradient */}
          <path
            d="M 200 110 L 270 145 L 270 220 Q 200 285 200 285 Q 130 285 130 220 L 130 145 Z"
            fill="none"
            stroke="hsl(var(--primary) / 0.5)"
            strokeWidth="1.5"
          />

          {/* Encryption lock symbol */}
          <g transform="translate(200, 180)">
            {/* Padlock body */}
            <rect x="-12" y="-8" width="24" height="20" rx="3" fill="white" opacity="0.15" stroke="white" strokeWidth="1.5" />

            {/* Keyhole */}
            <circle cx="0" cy="0" r="4" fill="none" stroke="white" strokeWidth="1.5" opacity="0.9" />
            <line x1="0" y1="-4" x2="0" y2="-6" stroke="white" strokeWidth="1" opacity="0.7" />
            <line x1="0" y1="4" x2="0" y2="6" stroke="white" strokeWidth="1" opacity="0.7" />
          </g>

          {/* Data lines representing encrypted information */}
          <g opacity="0.6" className="pulse-glow">
            <line x1="160" y1="160" x2="180" y2="170" stroke="white" strokeWidth="1.5" />
            <line x1="220" y1="170" x2="240" y2="160" stroke="white" strokeWidth="1.5" />
            <line x1="160" y1="220" x2="180" y2="210" stroke="white" strokeWidth="1.5" />
            <line x1="220" y1="210" x2="240" y2="220" stroke="white" strokeWidth="1.5" />
          </g>
        </g>

        {/* Floating particles */}
        <g opacity="0.4">
          <circle cx="150" cy="130" r="3" fill="hsl(var(--primary))" className="float-elem" />
          <circle cx="250" cy="150" r="2.5" fill="hsl(var(--primary))" className="float-elem" style={{ animationDelay: '0.5s' }} />
          <circle cx="130" cy="240" r="2" fill="hsl(var(--primary))" className="float-elem" style={{ animationDelay: '1s' }} />
          <circle cx="270" cy="260" r="2.5" fill="hsl(var(--primary))" className="float-elem" style={{ animationDelay: '1.5s' }} />
        </g>

        {/* Center glow point */}
        <circle cx="200" cy="200" r="1" fill="white" opacity="0.5" />
      </svg>
    </div>
  );
};

export default SecurityVisualization;
