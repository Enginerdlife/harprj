import React from 'react';
import { cn } from '@/lib/utils';
import {
  LogIn,
  LogOut,
  Upload,
  Download,
  Share2,
  ShieldAlert,
  Key,
  Ban,
  AlertTriangle,
  LucideIcon,
} from 'lucide-react';

interface LogEntry {
  id: string;
  type: 'login' | 'logout' | 'upload' | 'download' | 'share' | 'share_revoke' | '2fa' | 'failed_access' | 'suspicious';
  message: string;
  timestamp: string;
  details?: string;
  ip?: string;
  hash?: string;
}

interface LogsTimelineProps {
  logs: LogEntry[];
}

const getLogIcon = (type: LogEntry['type']): LucideIcon => {
  const icons: Record<LogEntry['type'], LucideIcon> = {
    login: LogIn,
    logout: LogOut,
    upload: Upload,
    download: Download,
    share: Share2,
    share_revoke: Ban,
    '2fa': Key,
    failed_access: ShieldAlert,
    suspicious: AlertTriangle,
  };
  return icons[type];
};

const getLogColor = (type: LogEntry['type']) => {
  const colors: Record<LogEntry['type'], string> = {
    login: 'bg-success/20 text-success border-success/30',
    logout: 'bg-muted text-muted-foreground border-border',
    upload: 'bg-primary/20 text-primary border-primary/30',
    download: 'bg-primary/20 text-primary border-primary/30',
    share: 'bg-warning/20 text-warning border-warning/30',
    share_revoke: 'bg-destructive/20 text-destructive border-destructive/30',
    '2fa': 'bg-success/20 text-success border-success/30',
    failed_access: 'bg-destructive/20 text-destructive border-destructive/30',
    suspicious: 'bg-destructive/20 text-destructive border-destructive/30',
  };
  return colors[type];
};

const LogsTimeline: React.FC<LogsTimelineProps> = ({ logs }) => {
  return (
    <div className="space-y-4">
      {logs.map((log, index) => {
        const Icon = getLogIcon(log.type);
        const colorClass = getLogColor(log.type);

        return (
          <div key={log.id} className="flex gap-4 animate-fade-in" style={{ animationDelay: `${index * 50}ms` }}>
            <div className="relative flex flex-col items-center">
              <div className={cn('p-2 rounded-full border', colorClass)}>
                <Icon className="h-4 w-4" />
              </div>
              {index < logs.length - 1 && (
                <div className="flex-1 w-px bg-border mt-2" />
              )}
            </div>
            
            <div className="flex-1 pb-6">
              <div className="bg-card rounded-lg border border-border p-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <p className="font-medium text-foreground">{log.message}</p>
                    {log.details && (
                      <p className="text-sm text-muted-foreground mt-1">{log.details}</p>
                    )}
                    {log.ip && (
                      <p className="text-xs text-muted-foreground mt-2">IP: {log.ip}</p>
                    )}
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className="text-xs text-muted-foreground">{log.timestamp}</p>
                    {log.hash && (
                      <p className="text-[10px] font-mono text-muted-foreground/60 mt-1 truncate max-w-[120px]">
                        #{log.hash.slice(0, 8)}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default LogsTimeline;
