import React, { useState, useEffect, useCallback } from 'react';
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, File as FileIcon, Shield, Check, Square, CheckSquare } from 'lucide-react';
import { useFiles, EncryptedFile } from '@/contexts/FileContext';
import { cn } from '@/lib/utils';

interface FileSelectionModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSelect: (files: EncryptedFile[]) => void;
}

const FileSelectionModal: React.FC<FileSelectionModalProps> = ({
    isOpen,
    onClose,
    onSelect,
}) => {
    const { files } = useFiles();
    const [searchQuery, setSearchQuery] = useState('');
    const [selectedFileIds, setSelectedFileIds] = useState<Set<string>>(new Set());

    const filteredFiles = (Array.isArray(files) ? files : []).filter(file =>
        file?.name?.toLowerCase().includes(searchQuery.toLowerCase())
    );

    // Reset selection when modal opens/closes
    useEffect(() => {
        if (isOpen) {
            setSelectedFileIds(new Set());
            setSearchQuery('');
        }
    }, [isOpen]);

    // Handle Ctrl+A for Select All
    const handleKeyDown = useCallback((e: KeyboardEvent) => {
        if (!isOpen) return;

        if ((e.ctrlKey || e.metaKey) && e.key === 'a') {
            e.preventDefault();
            const allIds = new Set(filteredFiles.map(f => f.id));
            // If all are already selected, deselect all. Otherwise select all.
            if (allIds.size > 0 && Array.from(allIds).every(id => selectedFileIds.has(id))) {
                setSelectedFileIds(new Set());
            } else {
                setSelectedFileIds(allIds);
            }
        }
    }, [isOpen, filteredFiles, selectedFileIds]);

    useEffect(() => {
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [handleKeyDown]);


    const toggleSelection = (fileId: string) => {
        const newSelection = new Set(selectedFileIds);
        if (newSelection.has(fileId)) {
            newSelection.delete(fileId);
        } else {
            newSelection.add(fileId);
        }
        setSelectedFileIds(newSelection);
    };

    const handleConfirm = () => {
        const selectedFiles = files.filter(f => selectedFileIds.has(f.id));
        onSelect(selectedFiles);
    };

    const formatFileSize = (bytes: number) => {
        if (!bytes) return '0 B';
        if (bytes < 1024) return bytes + ' B';
        if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
        return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
    };

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="sm:max-w-2xl p-0 overflow-hidden border-none rounded-[2rem] shadow-2xl bg-white max-h-[85vh] flex flex-col">
                <DialogHeader className="bg-slate-900 px-8 py-6 shrink-0">
                    <div className="flex items-center gap-3">
                        <div className="bg-indigo-500/20 p-2.5 rounded-2xl backdrop-blur-sm">
                            <Shield className="h-5 w-5 text-indigo-400" />
                        </div>
                        <DialogTitle className="text-white font-black text-xl tracking-tight">Select Files to Share</DialogTitle>
                    </div>
                    <DialogDescription className="text-slate-400 mt-1">
                        Select one or more encrypted files. Press <kbd className="bg-slate-800 px-1.5 py-0.5 rounded text-xs ml-1">Ctrl+A</kbd> to select all.
                    </DialogDescription>
                </DialogHeader>

                <div className="p-6 space-y-4 flex-1 overflow-hidden flex flex-col">
                    <div className="relative shrink-0">
                        <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                        <Input
                            placeholder="Search files..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="pl-10 h-11 bg-slate-50/50 border-slate-200 rounded-xl focus:ring-indigo-500"
                        />
                    </div>

                    <div className="flex-1 overflow-y-auto space-y-2 pr-2 custom-scrollbar min-h-0">
                        {filteredFiles.length === 0 ? (
                            <div className="text-center py-12 space-y-2">
                                <FileIcon className="h-10 w-10 text-slate-200 mx-auto" />
                                <p className="text-slate-500 font-medium">No files found matching your search</p>
                            </div>
                        ) : (
                            filteredFiles.map((file) => {
                                const isSelected = selectedFileIds.has(file.id);
                                return (
                                    <button
                                        key={file.id}
                                        onClick={() => toggleSelection(file.id)}
                                        className={cn(
                                            "w-full flex items-center justify-between p-4 border rounded-2xl transition-all group",
                                            isSelected
                                                ? "bg-indigo-50 border-indigo-200 shadow-sm"
                                                : "bg-white hover:bg-slate-50 border-slate-100"
                                        )}
                                    >
                                        <div className="flex items-center gap-4 text-left min-w-0">
                                            <div className={cn(
                                                "h-12 w-12 rounded-xl flex items-center justify-center transition-colors shrink-0",
                                                isSelected ? "bg-indigo-100" : "bg-slate-100 group-hover:bg-indigo-50"
                                            )}>
                                                <FileIcon className={cn(
                                                    "h-6 w-6 transition-colors",
                                                    isSelected ? "text-indigo-600" : "text-slate-400 group-hover:text-indigo-500"
                                                )} />
                                            </div>
                                            <div className="min-w-0">
                                                <p className={cn(
                                                    "font-bold truncate max-w-[300px]",
                                                    isSelected ? "text-indigo-900" : "text-slate-900"
                                                )}>{file.name}</p>
                                                <p className="text-xs text-slate-400 font-medium">
                                                    {formatFileSize(file.size)} • {new Date(file.createdAt).toLocaleDateString()}
                                                </p>
                                            </div>
                                        </div>
                                        <div className={cn(
                                            "h-6 w-6 rounded-md border flex items-center justify-center transition-all",
                                            isSelected
                                                ? "bg-indigo-600 border-indigo-600"
                                                : "bg-white border-slate-300"
                                        )}>
                                            {isSelected && <Check className="h-4 w-4 text-white" />}
                                        </div>
                                    </button>
                                );
                            })
                        )}
                    </div>
                </div>

                <div className="p-6 pt-0 shrink-0">
                    <Button
                        onClick={handleConfirm}
                        disabled={selectedFileIds.size === 0}
                        className="w-full h-14 rounded-2xl text-lg font-bold shadow-xl shadow-indigo-100 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50"
                    >
                        Share {selectedFileIds.size > 0 ? `${selectedFileIds.size} Selected File${selectedFileIds.size === 1 ? '' : 's'}` : 'Selected Files'}
                    </Button>
                </div>
            </DialogContent>
        </Dialog>
    );
};

export default FileSelectionModal;
