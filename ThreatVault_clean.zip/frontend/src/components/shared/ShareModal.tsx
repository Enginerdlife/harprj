import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Copy,
  Check,
  Clock,
  Mail,
  ShieldCheck,
  Share2,
  Lock,
  Loader2,
  Files,
  AlertTriangle
} from 'lucide-react';
import { toast } from 'sonner';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  fileNames: string[];
  onShare: (email: string, expiresIn: number) => Promise<string>;
}

const ShareModal: React.FC<ShareModalProps> = ({
  isOpen,
  onClose,
  fileNames,
  onShare,
}) => {
  const [email, setEmail] = useState('');
  const [expiresIn, setExpiresIn] = useState('24');
  const [shareLink, setShareLink] = useState(''); // Only used for single file or first file
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [success, setSuccess] = useState(false);

  // Reset state when opening
  React.useEffect(() => {
    if (isOpen) {
      setShareLink('');
      setSuccess(false);
      setIsLoading(false);
      setEmail('');
    }
  }, [isOpen]);

  const handleShare = async () => {
    if (!email) {
      toast.error('Recipient email is required');
      return;
    }

    setIsLoading(true);
    try {
      const link = await onShare(email, parseInt(expiresIn));
      setShareLink(link);
      setSuccess(true);
      toast.success(fileNames.length > 1 ? 'Files shared successfully' : 'Secure share link generated');
    } catch (error: any) {
      const message = error?.message || 'Failed to generate secure links';
      toast.error(message);
      console.error('[ShareModal] Share failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = async () => {
    await navigator.clipboard.writeText(shareLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast.success('Link copied to clipboard');
  };

  const handleSendEmail = () => {
    // If batch, we just open Gmail compose generically, as the backend already sent the real emails
    const subject = encodeURIComponent(fileNames.length > 1 ? `SECURE FILES (${fileNames.length})` : `SECURE FILE: ${fileNames[0]}`);
    const body = encodeURIComponent(
      `Secure File Transfer\n\n` +
      `Files: ${fileNames.join(', ')}\n` +
      `\nSecurity: End-to-End Encrypted (AES-256-GCM)`
    );

    const gmailUrl = `https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(email)}&su=${subject}&body=${body}`;
    window.open(gmailUrl, '_blank');
    toast.info('Opening secure Gmail compose...');
  };

  const handleClose = () => {
    onClose();
  };

  const isBatch = fileNames.length > 1;

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-xl p-0 overflow-hidden border-none rounded-[2rem] shadow-2xl bg-white">
        <div className="bg-slate-900 px-8 py-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-indigo-500/20 p-2.5 rounded-2xl backdrop-blur-sm">
              <Share2 className="h-5 w-5 text-indigo-400" />
            </div>
            <h2 className="text-white font-black text-xl tracking-tight">Generate Share</h2>
          </div>
          <div className="flex items-center gap-1.5 px-3 py-1 bg-white/5 rounded-full border border-white/10">
            <Lock className="h-3 w-3 text-emerald-400" />
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">AES-256-GCM</span>
          </div>
        </div>

        <div className="p-8 space-y-8">
          {!success ? (
            <>
              <div className="space-y-4">
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 flex items-center gap-4">
                  <div className="h-12 w-12 bg-white rounded-xl border border-slate-100 flex items-center justify-center shrink-0 shadow-sm">
                    {isBatch ? <Files className="h-6 w-6 text-indigo-500" /> : <ShieldCheck className="h-6 w-6 text-indigo-500" />}
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-bold text-slate-900 truncate max-w-[300px]">
                      {isBatch ? `${fileNames.length} Files Selected` : fileNames[0]}
                    </p>
                    <p className="text-xs text-slate-500">
                      {isBatch ? 'Batch secure transfer' : 'Preparing secure access tunnel'}
                    </p>
                  </div>
                </div>

                <div className="space-y-5">
                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-slate-700 font-bold ml-1">Recipient Identity</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="recipient@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="h-12 rounded-xl bg-slate-50 border-slate-200 focus:ring-indigo-500"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="expires" className="text-slate-700 font-bold ml-1">Tunnel Expiry</Label>
                    <Select value={expiresIn} onValueChange={setExpiresIn}>
                      <SelectTrigger className="h-12 rounded-xl bg-slate-50 border-slate-200">
                        <div className="flex items-center gap-2">
                          <Clock className="h-4 w-4 text-slate-400" />
                          <SelectValue />
                        </div>
                      </SelectTrigger>
                      <SelectContent className="rounded-xl">
                        <SelectItem value="1">1 Hour (Highly Volatile)</SelectItem>
                        <SelectItem value="6">6 Hours (Medium)</SelectItem>
                        <SelectItem value="24">24 Hours (Standard)</SelectItem>
                        <SelectItem value="72">3 Days (Extended)</SelectItem>
                        <SelectItem value="168">7 Days (Maximum)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              <Button
                onClick={handleShare}
                disabled={isLoading || !email}
                className="w-full h-14 rounded-2xl text-lg font-bold shadow-xl shadow-indigo-100 bg-indigo-600 hover:bg-indigo-700 transition-all hover:scale-[1.01]"
              >
                {isLoading ? (
                  <div className="flex items-center gap-3">
                    <Loader2 className="h-5 w-5 animate-spin" />
                    Generating Certificates...
                  </div>
                ) : (
                  isBatch ? 'Share All Securely' : 'Establish Secure Share'
                )}
              </Button>
            </>
          ) : (
            <div className="space-y-8 animate-in fade-in zoom-in-95 duration-500">
              <div className="text-center space-y-2">
                <div className="h-16 w-16 bg-emerald-50 rounded-full flex items-center justify-center mx-auto mb-4 border border-emerald-100">
                  <ShieldCheck className="h-8 w-8 text-emerald-500" />
                </div>
                <h3 className="text-2xl font-black text-slate-900">
                  {isBatch ? 'Batch Transfer Initiated' : 'Secure Link Established'}
                </h3>
                <p className="text-slate-500 italic text-sm">
                  {isBatch ? `Emails sent for ${fileNames.length} files` : `Valid for ${expiresIn} hours`}
                </p>
              </div>

              <div className="space-y-6">
                {!isBatch && (
                  <div className="space-y-3">
                    <Label className="text-slate-700 font-bold ml-1">Access URL</Label>
                    <div className="relative group">
                      <Input
                        value={shareLink}
                        readOnly
                        className="h-14 rounded-2xl bg-slate-900 border-none text-white font-mono text-xs pr-14 pl-6"
                      />
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={handleCopy}
                        className="absolute right-2 top-1/2 -translate-y-1/2 h-10 w-10 text-slate-400 hover:text-white hover:bg-white/10 rounded-xl"
                      >
                        {copied ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4">
                  <Button
                    onClick={handleSendEmail}
                    className="h-14 rounded-2xl font-bold bg-slate-900 hover:bg-slate-800 shadow-lg flex gap-3"
                  >
                    <Mail className="h-5 w-5" />
                    Gmail Share
                  </Button>
                  <Button
                    variant="outline"
                    onClick={handleClose}
                    className="h-14 rounded-2xl font-bold border-slate-200 text-slate-600"
                  >
                    Complete
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ShareModal;
