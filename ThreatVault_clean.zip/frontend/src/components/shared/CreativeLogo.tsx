import React from 'react';

interface CreativeLogoProps {
  size?: 'sm' | 'md' | 'lg';
}

const CreativeLogo: React.FC<CreativeLogoProps> = ({ size = 'md' }) => {
  const sizeMap = {
    sm: '32',
    md: '48',
    lg: '64',
  };

  const dimensions = sizeMap[size];

  return (
    <svg
      width={dimensions}
      height={dimensions}
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="drop-shadow-lg"
    >
      <defs>
        <linearGradient id="lockGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" style={{ stopColor: 'currentColor', stopOpacity: 1 }} />
          <stop offset="100%" style={{ stopColor: 'currentColor', stopOpacity: 0.6 }} />
        </linearGradient>
        <filter id="glow">
          <feGaussianBlur stdDeviation="1.5" result="coloredBlur" />
          <feMerge>
            <feMergeNode in="coloredBlur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      {/* Outer circle background */}
      <circle cx="32" cy="32" r="30" fill="currentColor" opacity="0.08" />

      {/* Main padlock body with creative design */}
      <g filter="url(#glow)">
        {/* Shackle (top arch with circuit pattern) */}
        <path
          d="M 20 32 Q 20 16 32 16 Q 44 16 44 32"
          stroke="currentColor"
          strokeWidth="3.5"
          fill="none"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Circuit pattern on shackle */}
        <circle cx="32" cy="20" r="1.5" fill="currentColor" opacity="0.7" />
        <circle cx="25" cy="24" r="1" fill="currentColor" opacity="0.5" />
        <circle cx="39" cy="24" r="1" fill="currentColor" opacity="0.5" />
        <line x1="32" y1="20" x2="32" y2="26" stroke="currentColor" strokeWidth="0.8" opacity="0.4" />
        <line x1="25" y1="24" x2="28" y2="24" stroke="currentColor" strokeWidth="0.8" opacity="0.4" />
        <line x1="39" y1="24" x2="36" y2="24" stroke="currentColor" strokeWidth="0.8" opacity="0.4" />

        {/* Main lock body (rounded rectangle) */}
        <rect
          x="18"
          y="32"
          width="28"
          height="20"
          rx="4"
          fill="url(#lockGradient)"
          stroke="currentColor"
          strokeWidth="2.5"
        />

        {/* Keyhole with digital accent */}
        <circle cx="32" cy="40" r="4" fill="currentColor" opacity="0.15" />
        <circle cx="32" cy="40" r="3" fill="none" stroke="currentColor" strokeWidth="2" />

        {/* Digital accent lines */}
        <line x1="32" y1="37" x2="32" y2="35" stroke="currentColor" strokeWidth="1.5" opacity="0.7" />
        <line x1="32" y1="45" x2="32" y2="47" stroke="currentColor" strokeWidth="1.5" opacity="0.7" />

        {/* Decorative data points */}
        <circle cx="24" cy="36" r="1.2" fill="currentColor" opacity="0.6" />
        <circle cx="40" cy="36" r="1.2" fill="currentColor" opacity="0.6" />
        <circle cx="24" cy="44" r="1.2" fill="currentColor" opacity="0.6" />
        <circle cx="40" cy="44" r="1.2" fill="currentColor" opacity="0.6" />
      </g>

      {/* Highlight effect */}
      <ellipse cx="28" cy="36" rx="3" ry="4" fill="white" opacity="0.15" />
    </svg>
  );
};

export default CreativeLogo;
