import React, { useState } from 'react';
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogDescription,
    DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
    Lock,
    Eye,
    Loader2,
    AlertCircle,
    FileText,
    Download,
    ShieldCheck,
    X,
    File
} from 'lucide-react';
import { toast } from 'sonner';
import {
    base64ToUint8Array,
    base64ToArrayBuffer,
    deriveKeyFromPassword,
    decryptFile
} from '@/lib/encryption';
import { EncryptedFile } from '@/contexts/FileContext';

interface FileViewerModalProps {
    isOpen: boolean;
    onClose: () => void;
    file: EncryptedFile;
}

const FileViewerModal: React.FC<FileViewerModalProps> = ({ isOpen, onClose, file }) => {
    const [password, setPassword] = useState('');
    const [isUnlocking, setIsUnlocking] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [decryptedUrl, setDecryptedUrl] = useState<string | null>(null);
    const [viewState, setViewState] = useState<'locked' | 'viewing'>('locked');

    const handleUnlock = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!password) {
            setError('Password is required');
            return;
        }

        setIsUnlocking(true);
        setError(null);

        try {
            if (!file.salt || !file.iv) {
                throw new Error('This file is missing cryptographic metadata.');
            }

            console.log(`[FileViewerModal] Verifying access for file ${file.id}`);

            // 1. Verify password with backend
            const { filesAPI } = await import('@/lib/api');
            const { data: verifyResponse } = await filesAPI.verifyFilePassword(file.id, password);

            if (!verifyResponse.valid) {
                throw new Error(verifyResponse.message || 'Incorrect password.');
            }

            // 2. Fetch encrypted content
            const { data: downloadResponse } = await filesAPI.downloadFile(file.id);
            const fullFile = downloadResponse.data;

            if (!fullFile || !fullFile.encryptedData) {
                throw new Error('Failed to retrieve encrypted payload.');
            }

            // 3. Derive key
            const salt = base64ToUint8Array(file.salt);
            const key = await deriveKeyFromPassword(password, salt);

            // 4. Decrypt file
            const encryptedData = base64ToArrayBuffer(fullFile.encryptedData);
            const iv = base64ToUint8Array(fullFile.iv || file.iv);

            const decryptedData = await decryptFile(encryptedData, key, iv);

            // 5. Success
            const blob = new Blob([decryptedData], { type: file.type });
            const url = URL.createObjectURL(blob);
            setDecryptedUrl(url);
            setViewState('viewing');
            toast.success('File decrypted successfully');

        } catch (err: any) {
            console.error('[FileViewerModal] Unlock failed:', err);
            setError(err.message || 'Decryption failed. Please check your password.');
        } finally {
            setIsUnlocking(false);
        }
    };

    const cleanUp = () => {
        if (decryptedUrl) {
            URL.revokeObjectURL(decryptedUrl);
            setDecryptedUrl(null);
        }
        setPassword('');
        setViewState('locked');
        setError(null);
    };

    const handleClose = () => {
        cleanUp();
        onClose();
    };

    const renderPreview = () => {
        if (!decryptedUrl) return null;

        if (file.type.startsWith('image/')) {
            return (
                <div className="flex justify-center bg-slate-50 rounded-2xl p-4 overflow-hidden border border-slate-100 shadow-inner">
                    <img src={decryptedUrl} alt={file.name} className="max-h-[50vh] object-contain rounded-lg shadow-lg animate-in zoom-in-95" />
                </div>
            );
        }

        if (file.type === 'application/pdf') {
            return (
                <div className="bg-slate-100 rounded-2xl border border-slate-200 h-[60vh] overflow-hidden shadow-inner">
                    <iframe src={decryptedUrl} className="w-full h-full" title={file.name} />
                </div>
            );
        }

        return (
            <div className="flex flex-col items-center justify-center py-16 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200 text-center space-y-4">
                <div className="h-20 w-20 bg-white shadow-sm border border-slate-100 rounded-3xl flex items-center justify-center">
                    <File className="h-10 w-10 text-indigo-500" />
                </div>
                <div>
                    <p className="text-xl font-bold text-slate-800">Preview Unavailable</p>
                    <p className="text-slate-500 max-w-xs">{file.name} is ready for download.</p>
                </div>
                <Button asChild className="rounded-xl shadow-md bg-indigo-600 hover:bg-indigo-700">
                    <a href={decryptedUrl} download={file.name}>
                        <Download className="h-4 w-4 mr-2" />
                        Download Now
                    </a>
                </Button>
            </div>
        );
    };

    return (
        <Dialog open={isOpen} onOpenChange={(open) => !open && handleClose()}>
            <DialogContent className="sm:max-w-3xl p-0 overflow-hidden border-none rounded-3xl shadow-2xl">
                <div className="bg-slate-900 px-6 py-4 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <div className={viewState === 'locked' ? 'bg-amber-500/10 p-2 rounded-xl' : 'bg-emerald-500/10 p-2 rounded-xl'}>
                            {viewState === 'locked' ? <Lock className="h-5 w-5 text-amber-500" /> : <ShieldCheck className="h-5 w-5 text-emerald-500" />}
                        </div>
                        <h2 className="text-white font-bold text-lg truncate max-w-[400px]">
                            {viewState === 'locked' ? 'Cryptographic Unlock' : file.name}
                        </h2>
                    </div>
                </div>

                <div className="p-8">
                    {viewState === 'locked' ? (
                        <div className="space-y-6">
                            <div className="space-y-2">
                                <h3 className="text-2xl font-black text-slate-900">Secure Access Required</h3>
                                <p className="text-slate-500">
                                    Provide the password used to encrypt <span className="text-indigo-600 font-bold">{file.name}</span>.
                                </p>
                            </div>

                            <form onSubmit={handleUnlock} className="space-y-6">
                                <div className="space-y-3">
                                    <Label htmlFor="file-password" className="text-slate-700 font-bold ml-1">Master Password</Label>
                                    <Input
                                        id="file-password"
                                        type="password"
                                        placeholder="••••••••••••"
                                        value={password}
                                        onChange={(e) => setPassword(e.target.value)}
                                        disabled={isUnlocking}
                                        className={`h-12 rounded-xl bg-slate-50 border-slate-200 focus:ring-indigo-500 transition-all ${error ? 'border-rose-500 shadow-sm shadow-rose-100' : ''}`}
                                        autoFocus
                                    />
                                    {error && (
                                        <div className="flex items-center gap-2 bg-rose-50 text-rose-600 p-3 rounded-xl border border-rose-100 animate-in slide-in-from-top-2">
                                            <AlertCircle className="h-4 w-4 shrink-0" />
                                            <p className="text-sm font-medium">{error}</p>
                                        </div>
                                    )}
                                </div>
                                <div className="flex gap-3 pt-2">
                                    <Button type="button" variant="outline" onClick={handleClose} className="h-12 px-6 rounded-xl border-slate-200 text-slate-600">
                                        Cancel
                                    </Button>
                                    <Button type="submit" disabled={isUnlocking || !password} className="h-12 flex-1 rounded-xl shadow-lg bg-indigo-600 hover:bg-indigo-700 shadow-indigo-100">
                                        {isUnlocking ? (
                                            <>
                                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                                Decrypting Payload...
                                            </>
                                        ) : (
                                            'Authenticate & Decrypt'
                                        )}
                                    </Button>
                                </div>
                            </form>
                        </div>
                    ) : (
                        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
                            {renderPreview()}

                            <div className="flex flex-col sm:flex-row gap-4 items-center justify-between pt-4 border-t border-slate-100">
                                <div className="flex items-center gap-2 text-slate-500 text-sm">
                                    <ShieldCheck className="h-4 w-4 text-emerald-500" />
                                    Successfully Authenticated
                                </div>
                                <div className="flex gap-3 w-full sm:w-auto">
                                    <Button asChild variant="outline" className="h-11 rounded-xl border-slate-200 flex-1 sm:flex-none">
                                        <a href={decryptedUrl!} download={file.name}>
                                            <Download className="h-4 w-4 mr-2" />
                                            Save File
                                        </a>
                                    </Button>
                                    <Button onClick={handleClose} className="h-11 rounded-xl bg-slate-900 hover:bg-slate-800 flex-1 sm:flex-none px-8">
                                        Close
                                    </Button>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </DialogContent>
        </Dialog>
    );
};

export default FileViewerModal;
