import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  FileText,
  Image,
  FileArchive,
  File,
  Download,
  Share2,
  Trash2,
  Eye,
  Lock,
  ChevronRight,
  ShieldCheck
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface FileCardProps {
  id: string;
  name: string;
  size: string;
  type: string;
  uploadedAt: string;
  isEncrypted?: boolean;
  onView?: () => void;
  onDownload?: () => void;
  onShare?: () => void;
  onDelete?: () => void;
  viewMode?: 'grid' | 'list';
}

const FileCard: React.FC<FileCardProps> = ({
  name,
  size,
  type,
  uploadedAt,
  isEncrypted = true,
  onView,
  onDownload,
  onShare,
  onDelete,
  viewMode = 'list'
}) => {
  const getFileIcon = () => {
    if (type.includes('image')) return Image;
    if (type.includes('pdf')) return FileText;
    if (type.includes('zip') || type.includes('archive')) return FileArchive;
    return File;
  };

  const Icon = getFileIcon();

  if (viewMode === 'list') {
    return (
      <div className="group flex items-center gap-4 p-4 bg-white border border-slate-200 rounded-xl hover:border-indigo-300 hover:shadow-sm transition-all animate-in fade-in duration-300">
        <div className="h-12 w-12 rounded-lg bg-slate-50 flex items-center justify-center text-slate-400 group-hover:bg-indigo-50 group-hover:text-indigo-500 transition-colors shrink-0">
          <Icon className="h-6 w-6" />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="font-semibold text-slate-900 truncate">{name}</h3>
            {isEncrypted && (
              <span className="flex items-center gap-1 bg-emerald-50 text-emerald-600 text-[10px] font-bold px-1.5 py-0.5 rounded-full border border-emerald-100 uppercase tracking-wider">
                <Lock className="h-3 w-3" /> Encrypted
              </span>
            )}
          </div>
          <div className="flex items-center gap-3 text-xs text-slate-500 mt-1">
            <span>{size}</span>
            <span>•</span>
            <span>{uploadedAt}</span>
          </div>
        </div>

        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <Button variant="ghost" size="icon" className="h-9 w-9 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50" title="Quick View" onClick={onView}>
            <Eye className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" className="h-9 w-9 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50" title="Download" onClick={onDownload}>
            <Download className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" className="h-9 w-9 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50" title="Share & Generate Link" onClick={onShare}>
            <Share2 className="h-4 w-4" />
          </Button>
          <div className="w-px h-4 bg-slate-200 mx-1" />
          <Button variant="ghost" size="icon" className="h-9 w-9 text-slate-400 hover:text-rose-600 hover:bg-rose-50" title="Revoke & Delete" onClick={onDelete}>
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>

        <ChevronRight className="h-4 w-4 text-slate-300 group-hover:text-indigo-400 transition-colors" />
      </div>
    );
  }

  return (
    <Card className="group transition-all duration-300 hover:shadow-lg hover:border-indigo-200 overflow-hidden bg-white animate-in zoom-in-95 duration-300">
      <CardContent className="p-0">
        <div className="p-6">
          <div className="flex justify-between items-start mb-4">
            <div className="h-12 w-12 rounded-xl bg-slate-50 flex items-center justify-center text-slate-400 group-hover:bg-indigo-50 group-hover:text-indigo-500 transition-colors">
              <Icon className="h-7 w-7" />
            </div>
            {isEncrypted && (
              <div className="h-8 w-8 rounded-full bg-emerald-50 border border-emerald-100 flex items-center justify-center" title="End-to-end encrypted">
                <ShieldCheck className="h-4 w-4 text-emerald-600" />
              </div>
            )}
          </div>

          <div className="space-y-1">
            <h3 className="font-bold text-slate-900 truncate pr-2" title={name}>{name}</h3>
            <p className="text-xs text-slate-500">{size} • {uploadedAt}</p>
          </div>
        </div>

        <div className="grid grid-cols-4 border-t border-slate-100 bg-slate-50/50">
          <Button variant="ghost" size="sm" className="h-11 rounded-none border-r border-slate-100 hover:bg-indigo-50 hover:text-indigo-600" onClick={onView} title="View Details">
            <Eye className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" className="h-11 rounded-none border-r border-slate-100 hover:bg-indigo-50 hover:text-indigo-600" onClick={onDownload} title="Download Decrypted">
            <Download className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" className="h-11 rounded-none border-r border-slate-100 hover:bg-indigo-50 hover:text-indigo-600" onClick={onShare} title="Share File">
            <Share2 className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" className="h-11 rounded-none hover:bg-rose-50 hover:text-rose-600" onClick={onDelete} title="Revoke & Delete">
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default FileCard;
