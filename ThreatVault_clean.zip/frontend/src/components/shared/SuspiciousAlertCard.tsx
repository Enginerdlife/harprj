import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, MapPin, Clock, User, X } from 'lucide-react';
import { cn } from '@/lib/utils';

interface SuspiciousAlertCardProps {
  id: string;
  type: 'unusual_ip' | 'failed_attempts' | 'download_frequency' | 'location_anomaly';
  severity: 'low' | 'medium' | 'high' | 'critical';
  title: string;
  description: string;
  timestamp: string;
  user?: string;
  ip?: string;
  location?: string;
  onDismiss?: () => void;
  onInvestigate?: () => void;
}

const SuspiciousAlertCard: React.FC<SuspiciousAlertCardProps> = ({
  type,
  severity,
  title,
  description,
  timestamp,
  user,
  ip,
  location,
  onDismiss,
  onInvestigate,
}) => {
  const severityStyles = {
    low: 'border-muted bg-muted/30',
    medium: 'border-warning/50 bg-warning/10',
    high: 'border-destructive/50 bg-destructive/10',
    critical: 'border-destructive bg-destructive/20 animate-pulse-glow',
  };

  const severityBadge = {
    low: 'bg-muted text-muted-foreground',
    medium: 'bg-warning text-warning-foreground',
    high: 'bg-destructive text-destructive-foreground',
    critical: 'bg-destructive text-destructive-foreground',
  };

  return (
    <Card className={cn('transition-all duration-200', severityStyles[severity])}>
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2">
            <AlertTriangle className={cn('h-5 w-5', severity === 'critical' || severity === 'high' ? 'text-destructive' : 'text-warning')} />
            <CardTitle className="text-base">{title}</CardTitle>
          </div>
          <div className="flex items-center gap-2">
            <Badge className={severityBadge[severity]}>{severity.toUpperCase()}</Badge>
            {onDismiss && (
              <Button variant="ghost" size="icon" className="h-6 w-6" onClick={onDismiss}>
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground mb-4">{description}</p>
        
        <div className="flex flex-wrap gap-4 text-xs text-muted-foreground mb-4">
          {user && (
            <div className="flex items-center gap-1">
              <User className="h-3 w-3" />
              <span>{user}</span>
            </div>
          )}
          {ip && (
            <div className="flex items-center gap-1">
              <span className="font-mono">{ip}</span>
            </div>
          )}
          {location && (
            <div className="flex items-center gap-1">
              <MapPin className="h-3 w-3" />
              <span>{location}</span>
            </div>
          )}
          <div className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            <span>{timestamp}</span>
          </div>
        </div>

        {onInvestigate && (
          <Button variant="outline" size="sm" onClick={onInvestigate}>
            Investigate
          </Button>
        )}
      </CardContent>
    </Card>
  );
};

export default SuspiciousAlertCard;
