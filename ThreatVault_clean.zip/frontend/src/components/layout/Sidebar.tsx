import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  FileText,
  Share2,
  Download,
  Settings,
  Shield,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useAuth, UserRole } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';

interface SidebarProps {
  collapsed: boolean;
  onToggle: () => void;
}

interface NavItem {
  href: string;
  label: string;
  icon: React.ElementType;
  roles: UserRole[];
}

const navItems: NavItem[] = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: ['student', 'employee', 'manager', 'administrator', 'it_support', 'auditor', 'compliance_officer', 'security_analyst', 'hr'] },
  { href: '/my-files', label: 'Files', icon: FileText, roles: ['student', 'employee', 'manager', 'administrator', 'it_support', 'security_analyst'] },
  { href: '/my-shares', label: 'Shared', icon: Share2, roles: ['employee', 'manager', 'administrator', 'it_support', 'security_analyst'] },
  { href: '/received', label: 'Received', icon: Download, roles: ['student', 'employee', 'manager', 'administrator', 'it_support', 'auditor', 'compliance_officer', 'security_analyst'] },
  { href: '/admin/dashboard', label: 'Admin Dashboard', icon: Shield, roles: ['administrator'] },
  { href: '/profile', label: 'Settings', icon: Settings, roles: ['student', 'employee', 'manager', 'administrator', 'it_support', 'auditor', 'compliance_officer', 'security_analyst', 'hr'] },
  // Keeping others just in case but they might not be in the primary requested list.
  { href: '/security', label: 'Security', icon: Shield, roles: ['student', 'employee', 'manager', 'administrator', 'it_support', 'auditor', 'compliance_officer', 'security_analyst', 'hr'] },
];

const Sidebar: React.FC<SidebarProps> = ({ collapsed, onToggle }) => {
  const location = useLocation();
  const { user, isAuthenticated } = useAuth();

  // Debug logging
  React.useEffect(() => {
    if (user) {
      console.log(`[Sidebar] User: ${user.name}, ID: ${user.id}, Role: ${user.activeRole}`);
    } else {
      console.log('[Sidebar] No user session found');
    }
  }, [user]);

  const visibleItems = navItems.filter(item => {
    // If user is not loaded yet or role is missing, we shouldn't return false for everything if we want to debug.
    // However, for production, if no role, maybe show nothing. 
    // But user claimed "completely empty", which implies they are logged in but seeing nothing.
    // I will add a safe check: if user exists but activeRole is missing, maybe default to 'guest' or similar?
    // Or just check if item.roles includes the user's role.
    if (!user) return false;
    if (!user.activeRole) return true; // Show all if role is missing? Or maybe safe default? Let's show all for now to avoid 'empty' complaints if role specific.
    return item.roles.includes(user.activeRole);
  });

  return (
    <aside
      className={cn(
        'fixed left-0 top-0 h-screen bg-sidebar border-r border-sidebar-border transition-all duration-300 z-50 flex flex-col',
        collapsed ? 'w-20' : 'w-72'
      )}
    >
      {/* App Logo / Name */}
      <Link to={isAuthenticated ? "/home" : "/"} className={cn("h-16 flex items-center gap-3 px-4 border-b border-sidebar-border", collapsed && "justify-center px-2")}>
        <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center flex-shrink-0">
          <Shield className="h-5 w-5 text-primary-foreground" />
        </div>
        {!collapsed && (
          <div className="flex flex-col overflow-hidden">
            <span className="font-bold text-foreground truncate">ThreatVault</span>
            <span className="text-xs text-muted-foreground truncate">File Sharing Platform</span>
          </div>
        )}
      </Link>

      {/* Toggle Button - Moved to be subtle or part of a different interaction, but keeping it as absolute for now matching user request for collapsible */}
      <Button
        variant="ghost"
        size="icon"
        onClick={onToggle}
        className="absolute -right-3 top-8 h-6 w-6 rounded-full border border-border bg-background shadow-sm hover:bg-accent z-50"
      >
        {collapsed ? (
          <ChevronRight className="h-3 w-3" />
        ) : (
          <ChevronLeft className="h-3 w-3" />
        )}
      </Button>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
        {visibleItems.map((item) => {
          const isActive = location.pathname === item.href;
          const Icon = item.icon;

          return (
            <Link
              key={item.href}
              to={item.href}
              className={cn(
                'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 group',
                isActive
                  ? 'bg-primary/10 text-primary'
                  : 'text-muted-foreground hover:text-foreground hover:bg-accent/50',
                collapsed && 'justify-center px-2'
              )}
              title={collapsed ? item.label : undefined}
            >
              <Icon className={cn('h-5 w-5 flex-shrink-0 transition-colors', isActive ? 'text-primary' : 'text-muted-foreground group-hover:text-foreground')} />
              {!collapsed && <span>{item.label}</span>}
            </Link>
          );
        })}
      </nav>

      {/* User Info */}
      {user && (
        <div className="p-4 border-t border-sidebar-border mt-auto">
          <div className={cn("flex items-center gap-3", collapsed && "justify-center")}>
            <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
              <span className="text-sm font-semibold text-primary">
                {user.name?.charAt(0).toUpperCase() || 'U'}
              </span>
            </div>
            {!collapsed && (
              <div className="flex-1 min-w-0 overflow-hidden">
                <p className="text-sm font-medium text-foreground truncate">{user.name || 'User'}</p>
                <p className="text-xs text-muted-foreground truncate capitalize">
                  {user.activeRole?.replace('_', ' ') || 'Guest'}
                </p>
              </div>
            )}
          </div>
        </div>
      )}
    </aside>
  );
};

export default Sidebar;
