import React from 'react';
import PublicLayout from '@/components/layout/PublicLayout';
import { Briefcase, MapPin, Globe, Sparkles, Rocket } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Careers: React.FC = () => {
    const openings = [
        { title: 'Senior Cryptography Engineer', team: 'Security', location: 'Remote (GMT+5:30)' },
        { title: 'Full-Stack Security Architect', team: 'Engineering', location: 'Bengaluru, India' },
        { title: 'Product UI/UX Designer', team: 'Design', location: 'Hybrid' },
    ];

    return (
        <PublicLayout>
            <div className="container py-24 md:py-32">
                <section className="text-center mb-24 max-w-3xl mx-auto space-y-6">
                    <div className="h-16 w-16 bg-indigo-50 rounded-3xl flex items-center justify-center mx-auto mb-8 border border-indigo-100">
                        <Sparkles className="h-8 w-8 text-indigo-600" />
                    </div>
                    <h1 className="text-5xl md:text-6xl font-black text-slate-900 tracking-tight">Join the Defense</h1>
                    <p className="text-xl text-slate-500 font-medium">We’re building the future of zero-trust data sovereignty. Join our mission to reclaim privacy for the enterprise.</p>
                    <Button className="h-14 px-8 rounded-2xl bg-indigo-600 hover:bg-indigo-700 font-bold shadow-xl shadow-indigo-100">View Active Missions</Button>
                </section>

                <div className="max-w-4xl mx-auto space-y-6">
                    <h2 className="text-2xl font-black text-slate-900 ml-2">Open Roles</h2>
                    {openings.map((job, index) => (
                        <div key={index} className="p-8 bg-white border border-slate-100 rounded-[2.5rem] flex flex-col md:flex-row md:items-center justify-between gap-6 hover:border-indigo-500/30 transition-all hover:shadow-lg group">
                            <div className="space-y-1">
                                <h3 className="text-xl font-black text-slate-900 group-hover:text-indigo-600 transition-colors">{job.title}</h3>
                                <div className="flex flex-wrap gap-4 text-xs font-bold text-slate-400 uppercase tracking-widest">
                                    <span className="flex items-center gap-1.5"><Briefcase className="h-3 w-3" /> {job.team}</span>
                                    <span className="flex items-center gap-1.5"><MapPin className="h-3 w-3" /> {job.location}</span>
                                </div>
                            </div>
                            <Button variant="outline" className="h-12 rounded-xl font-bold border-slate-200">Apply Protocol</Button>
                        </div>
                    ))}
                </div>

                <section className="mt-32 p-12 md:p-24 bg-slate-900 rounded-[3rem] text-center text-white relative overflow-hidden">
                    <div className="absolute top-0 right-0 h-64 w-64 bg-indigo-600/20 rounded-full blur-3xl" />
                    <h2 className="text-4xl font-black mb-6">Can't find a perfect fit?</h2>
                    <p className="text-slate-400 max-w-xl mx-auto mb-10 font-medium">If you’re a security researcher or cryptographer interested in our stack, reach out with your research. We always have room for elite talent.</p>
                    <Button variant="outline" className="h-14 px-8 rounded-2xl border-white/10 text-white hover:bg-white/5 font-bold">Initiate Direct Contact</Button>
                </section>
            </div>
        </PublicLayout>
    );
};

export default Careers;
