import React from 'react';
import PublicLayout from '@/components/layout/PublicLayout';
import { ShieldCheck, Lock, Gavel } from 'lucide-react';

const Privacy: React.FC = () => {
    return (
        <PublicLayout>
            <div className="container py-24 md:py-32 max-w-4xl mx-auto">
                <div className="flex items-center gap-3 mb-8">
                    <div className="h-12 w-12 bg-indigo-50 rounded-2xl flex items-center justify-center shadow-sm">
                        <ShieldCheck className="h-6 w-6 text-indigo-600" />
                    </div>
                    <div>
                        <h1 className="text-4xl font-black text-slate-900 tracking-tight">Privacy Sovereignty</h1>
                        <p className="text-slate-500 font-bold uppercase tracking-widest text-[10px]">Zero-Knowledge Data Protocols</p>
                    </div>
                </div>

                <div className="prose prose-slate max-w-none space-y-10">
                    <section className="space-y-4">
                        <h2 className="text-2xl font-black text-slate-900 flex items-center gap-2">
                            <Lock className="h-5 w-5 text-indigo-600" />
                            Our Absolute Privacy Commitment
                        </h2>
                        <p className="text-slate-600 leading-relaxed font-medium">
                            At Threatvault, privacy isn't just a policy—it's architected into the very code of our platform. We operate on a **Zero-Knowledge** principle, meaning your encrypted assets are mathematically inaccessible to us, any government entity, or unauthorized third parties.
                        </p>
                    </section>

                    <section className="space-y-4">
                        <h2 className="text-2xl font-black text-slate-900">1. Cryptographic Isolation</h2>
                        <p className="text-slate-600 leading-relaxed font-medium">
                            Every file uploaded is encrypted CLIENT-SIDE using AES-256-GCM. The primary encryption keys never depart your browser. We store only encrypted blobs and verification metadata. We cannot "look" at your files, even if compelled by law.
                        </p>
                    </section>

                    <section className="space-y-4">
                        <h2 className="text-2xl font-black text-slate-900">2. Metadata & Audit Trails</h2>
                        <p className="text-slate-600 leading-relaxed font-medium">
                            To ensure system integrity, we collect minimal operational metadata:
                        </p>
                        <ul className="list-disc pl-5 space-y-2 text-slate-600 font-medium">
                            <li>Authentication timestamps and IP addresses for audit-friendly activity tracking.</li>
                            <li>Transaction records for billing and compliance purposes.</li>
                            <li>File names and sizes for UI rendering (metadata can optionally be obfuscated).</li>
                        </ul>
                    </section>

                    <section className="space-y-4 p-8 bg-slate-50 rounded-[2rem] border border-slate-100">
                        <h2 className="text-2xl font-black text-slate-900 flex items-center gap-2">
                            <Gavel className="h-5 w-5 text-indigo-600" />
                            Compliance Transparency
                        </h2>
                        <p className="text-slate-600 leading-relaxed font-medium">
                            We comply with GDPR and HIPAA standards regarding data handling and operational security. Users have the absolute right to "Forget Me," which results in the immediate and permanent deletion of all account metadata and encrypted asset references from our clusters.
                        </p>
                    </section>

                    <div className="pt-10 border-t border-slate-100">
                        <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">Last Updated: October 2023 | Version 2.0.4-Secure</p>
                    </div>
                </div>
            </div>
        </PublicLayout>
    );
};

export default Privacy;
