import React from 'react';
import PublicLayout from '@/components/layout/PublicLayout';
import { Scale, FileText, Info, ShieldCheck, Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Legal: React.FC = () => {
    return (
        <PublicLayout>
            <div className="container py-24 md:py-32 max-w-5xl mx-auto">
                <div className="text-center mb-20 space-y-4">
                    <h1 className="text-5xl font-black text-slate-900 tracking-tight">Legal Transparency</h1>
                    <p className="text-xl text-slate-500 font-medium">Compliance, governance, and ethical protocols for the ThreatVault ecosystem.</p>
                </div>

                <div className="grid md:grid-cols-2 gap-8 mb-16">
                    <div className="p-10 bg-white border border-slate-100 rounded-[3rem] space-y-6 hover:shadow-xl transition-all">
                        <div className="h-14 w-14 bg-indigo-50 rounded-2xl flex items-center justify-center">
                            <Scale className="h-7 w-7 text-indigo-600" />
                        </div>
                        <h2 className="text-2xl font-black text-slate-900">Governance Model</h2>
                        <p className="text-slate-500 font-medium leading-relaxed">
                            Threatvault operates as a neutral infrastructure provider. We maintain strict compliance with international data protection regulations while ensuring zero-knowledge isolation.
                        </p>
                        <Button variant="link" className="p-0 h-auto font-black text-indigo-600 flex gap-2">Review Governance Charter</Button>
                    </div>

                    <div className="p-10 bg-white border border-slate-100 rounded-[3rem] space-y-6 hover:shadow-xl transition-all">
                        <div className="h-14 w-14 bg-emerald-50 rounded-2xl flex items-center justify-center">
                            <ShieldCheck className="h-7 w-7 text-emerald-600" />
                        </div>
                        <h2 className="text-2xl font-black text-slate-900">Compliance Stance</h2>
                        <p className="text-slate-500 font-medium leading-relaxed">
                            Our platform architecture is natively compatible with GDPR, CCPA, and HIPAA "technical safeguards" requirements through client-side encryption.
                        </p>
                        <Button variant="link" className="p-0 h-auto font-black text-emerald-600 flex gap-2">View Compliance Reports</Button>
                    </div>
                </div>

                <div className="p-12 bg-slate-50 rounded-[3rem] border border-slate-100 space-y-8">
                    <h3 className="text-2xl font-black text-slate-900 flex items-center gap-3">
                        <Info className="h-6 w-6 text-indigo-600" />
                        Reporting & Inquiries
                    </h3>
                    <div className="grid md:grid-cols-2 gap-10">
                        <div className="space-y-4">
                            <h4 className="font-black text-slate-900 flex items-center gap-2">
                                <FileText className="h-4 w-4 text-slate-400" />
                                Legal Inquiries
                            </h4>
                            <p className="text-sm text-slate-500 font-medium">For formal legal requests, subpoena compliance, or law enforcement inquiries. Note: We cannot decrypt user data.</p>
                            <div className="flex items-center gap-2 text-indigo-600 font-black text-sm">
                                <Mail className="h-4 w-4" />
                                legal@threatvault.com
                            </div>
                        </div>
                        <div className="space-y-4">
                            <h4 className="font-black text-slate-900 flex items-center gap-2">
                                <ShieldCheck className="h-4 w-4 text-slate-400" />
                                Abuse Reporting
                            </h4>
                            <p className="text-sm text-slate-500 font-medium">To report a violation of our Terms of Service, illicit material sharing, or security vulnerabilities.</p>
                            <div className="flex items-center gap-2 text-rose-600 font-black text-sm">
                                <Mail className="h-4 w-4" />
                                abuse@threatvault.com
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </PublicLayout>
    );
};

export default Legal;
