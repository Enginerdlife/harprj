import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Shield,
  Mail,
  Lock,
  Eye,
  EyeOff,
  Loader2,
  ChevronRight,
  Fingerprint,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import RoleDropdown from '@/components/auth/RoleDropdown';
import GoogleLoginButton from '@/components/auth/GoogleLoginButton';
import { useAuth, UserRole } from '@/contexts/AuthContext';
import { authAPI } from '@/lib/api';
import { toast } from 'sonner';

const Login: React.FC = () => {
  const navigate = useNavigate();
  const { login, googleLogin, isLoading } = useAuth();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<UserRole>('employee');
  const [employeeId, setEmployeeId] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [twoFactorRequired, setTwoFactorRequired] = useState(false);
  const [twoFactorCode, setTwoFactorCode] = useState('');
  const [mfaMethod, setMfaMethod] = useState<'app' | 'sms' | 'qr' | 'mfa_required'>('mfa_required');
  const [qrCodeData, setQrCodeData] = useState<{ qrCode: string; code: string; expiresAt: string } | null>(null);

  const showEmployeeFields = !['student', 'administrator', 'ADMIN'].includes(role);

  useEffect(() => {
    setEmail('');
    setPassword('');
    setRole('employee');
    setEmployeeId('');
    setErrors({});
    setShowPassword(false);
  }, []);

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!email) newErrors.email = 'Required';
    else if (!/\S+@\S+\.\S+/.test(email)) newErrors.email = 'Invalid format';

    if (!password) newErrors.password = 'Required';
    else if (password.length < 8) newErrors.password = 'Min 8 chars';

    if (showEmployeeFields && !employeeId) {
      newErrors.employeeId = 'Required for role';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    try {
      const result = await login(email, password, role, showEmployeeFields ? employeeId : undefined, twoFactorCode);

      if (result && result.status === '2fa_required') {
        setTwoFactorRequired(true);
        const method = result.data?.method;
        setMfaMethod(method || 'mfa_required');

        if (method === 'sms') {
          toast.info('Verification code sent to your phone.');
        } else if (method === 'app') {
          toast.info('Enter code from your Authenticator app.');
        } else {
          toast.info('Multi-factor authentication is required.');
        }
        return;
      }

      toast.success('Access Granted. Welcome back.');
      navigate('/dashboard');
    } catch (error: any) {
      console.error('Login error:', error);
      toast.error(error.response?.data?.message || 'Authentication failed.');
    }
  };

  const handleSendOTP = async () => {
    try {
      await authAPI.sendOTP(email);
      toast.success('OTP sent successfully.');
      setMfaMethod('sms');
    } catch (error) {
      toast.error('Failed to send OTP.');
    }
  };

  const handleFetchQR = async () => {
    try {
      const response = await authAPI.getQRCode();
      setQrCodeData(response.data.data);
      setMfaMethod('qr');
    } catch (error) {
      toast.error('Failed to generate session QR.');
    }
  };

  const handleGoogleLogin = async () => {
    try {
      await googleLogin('mock_token');
      toast.success('Google authentication successful');
      navigate('/dashboard');
    } catch (error) {
      toast.error('Google login failed');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#F8FAFC] p-6 selection:bg-indigo-100 relative overflow-hidden">
      {/* Decorative Circles */}
      <div className="absolute -top-24 -left-24 w-96 h-96 bg-indigo-50 rounded-full blur-3xl opacity-50" />
      <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-slate-100 rounded-full blur-3xl opacity-50" />

      <Card className="w-full max-w-lg border-none shadow-2xl rounded-[2.5rem] bg-white relative overflow-hidden animate-in fade-in zoom-in-95 duration-700">
        <div className="bg-slate-900 p-8 text-center space-y-4">
          <Link to="/" className="inline-flex items-center gap-3">
            <div className="bg-indigo-500/20 p-2.5 rounded-2xl backdrop-blur-sm border border-white/5">
              <Shield className="h-6 w-6 text-indigo-400" />
            </div>
            <span className="text-2xl font-black text-white tracking-tight">ThreatVault<span className="text-indigo-500">.</span></span>
          </Link>
          <div className="space-y-1">
            <h1 className="text-xl font-bold text-white">System Authentication</h1>
            <p className="text-slate-400 text-sm">Secure Portal Access Interface</p>
          </div>
        </div>

        <CardContent className="p-8 space-y-6">
          <form onSubmit={handleSubmit} className="space-y-5">
            {twoFactorRequired ? (
              <div className="space-y-6 animate-in slide-in-from-right-8 duration-500">
                <div className="text-center space-y-2">
                  <div className="h-16 w-16 bg-indigo-50 rounded-3xl flex items-center justify-center mx-auto border border-indigo-100">
                    <Fingerprint className="h-8 w-8 text-indigo-600" />
                  </div>
                  <h3 className="text-xl font-bold text-slate-900">MFA Verification</h3>
                  <p className="text-slate-500 text-sm">Mandatory security check for your identity.</p>
                </div>

                {mfaMethod === 'mfa_required' && (
                  <div className="grid grid-cols-2 gap-3">
                    <Button type="button" variant="outline" className="h-20 flex flex-col gap-1 rounded-2xl border-slate-200" onClick={() => setMfaMethod('app')}>
                      <ShieldCheck className="h-5 w-5 text-indigo-600" />
                      <span className="text-xs font-bold">Authenticator</span>
                    </Button>
                    <Button type="button" variant="outline" className="h-20 flex flex-col gap-1 rounded-2xl border-slate-200" onClick={handleSendOTP}>
                      <Mail className="h-5 w-5 text-indigo-600" />
                      <span className="text-xs font-bold">Mobile OTP</span>
                    </Button>
                    <Button type="button" variant="outline" className="h-20 flex flex-col gap-1 rounded-2xl border-slate-200 col-span-2" onClick={handleFetchQR}>
                      <Fingerprint className="h-5 w-5 text-indigo-600" />
                      <span className="text-xs font-bold">Session QR Scan</span>
                    </Button>
                  </div>
                )}

                {mfaMethod === 'qr' && qrCodeData && (
                  <div className="text-center space-y-4">
                    <div className="bg-white p-4 rounded-3xl border-2 border-slate-100 inline-block mx-auto">
                      <img src={qrCodeData.qrCode} alt="Security QR" className="h-40 w-40" />
                    </div>
                    <div className="space-y-1">
                      <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Verification Code</p>
                      <p className="text-3xl font-black text-indigo-600 font-mono tracking-tighter">{qrCodeData.code}</p>
                    </div>
                    <p className="text-[10px] text-rose-500 font-bold uppercase">Expires: {new Date(qrCodeData.expiresAt).toLocaleTimeString()}</p>
                  </div>
                )}

                {mfaMethod !== 'mfa_required' && (
                  <div className="space-y-2">
                    <Label htmlFor="2fa-code" className="text-slate-700 font-bold ml-1">Identity Token</Label>
                    <Input
                      id="2fa-code"
                      type="text"
                      placeholder="••••••"
                      value={twoFactorCode}
                      onChange={(e) => setTwoFactorCode(e.target.value)}
                      className="h-14 bg-slate-50 border-slate-200 rounded-2xl text-center text-2xl font-bold tracking-[0.5em] focus:ring-indigo-500"
                      autoFocus
                      maxLength={8}
                    />
                  </div>
                )}

                <Button type="submit" className="w-full h-14 bg-indigo-600 hover:bg-indigo-700 rounded-2xl text-lg font-bold shadow-xl shadow-indigo-100" disabled={isLoading || (mfaMethod === 'mfa_required' && !twoFactorCode)}>
                  {isLoading ? <Loader2 className="h-5 w-5 animate-spin" /> : 'Confirm Identity'}
                </Button>

                <Button
                  type="button"
                  variant="ghost"
                  className="w-full h-12 text-slate-500 font-bold rounded-xl"
                  onClick={() => {
                    setTwoFactorRequired(false);
                    setMfaMethod('mfa_required');
                  }}
                >
                  Return to Primary Login
                </Button>
              </div>
            ) : (
              <>
                <div className="space-y-5">
                  <div className="flex gap-4">
                    <div className="flex-1 space-y-2">
                      <Label htmlFor="email" className="text-slate-700 font-bold ml-1">Email Address</Label>
                      <div className="relative group">
                        <Mail className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400 group-focus-within:text-indigo-500 transition-colors" />
                        <Input
                          id="email"
                          type="email"
                          placeholder="you@domain.com"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className={`h-12 pl-12 bg-slate-50 border-slate-200 rounded-xl focus:ring-indigo-500 transition-all ${errors.email ? 'border-rose-500' : ''}`}
                        />
                      </div>
                      {errors.email && <p className="text-[10px] text-rose-500 font-bold ml-1 uppercase">{errors.email}</p>}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="password" className="text-slate-700 font-bold ml-1">System Password</Label>
                    <div className="relative group">
                      <Lock className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400 group-focus-within:text-indigo-500 transition-colors" />
                      <Input
                        id="password"
                        type={showPassword ? 'text' : 'password'}
                        placeholder="••••••••••••"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className={`h-12 pl-12 pr-12 bg-slate-50 border-slate-200 rounded-xl focus:ring-indigo-500 transition-all ${errors.password ? 'border-rose-500' : ''}`}
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-indigo-600"
                      >
                        {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                      </button>
                    </div>
                    {errors.password && <p className="text-[10px] text-rose-500 font-bold ml-1 uppercase">{errors.password}</p>}
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-slate-700 font-bold ml-1 text-xs">Access Level</Label>
                      <RoleDropdown value={role} onChange={setRole} />
                    </div>
                    {showEmployeeFields && (
                      <div className="space-y-2 animate-in fade-in zoom-in-95">
                        <Label htmlFor="employeeId" className="text-slate-700 font-bold ml-1 text-xs text-nowrap">Employee Serial</Label>
                        <Input
                          id="employeeId"
                          placeholder="E-12345"
                          value={employeeId}
                          onChange={(e) => setEmployeeId(e.target.value)}
                          className={`h-12 bg-slate-50 border-slate-200 rounded-xl focus:ring-indigo-500 ${errors.employeeId ? 'border-rose-500' : ''}`}
                        />
                      </div>
                    )}
                  </div>
                </div>

                <Button type="submit" className="w-full h-14 bg-indigo-600 hover:bg-indigo-700 rounded-2xl text-lg font-bold shadow-xl shadow-indigo-100 group" disabled={isLoading}>
                  {isLoading ? (
                    <Loader2 className="h-5 w-5 animate-spin" />
                  ) : (
                    <div className="flex items-center gap-2">
                      <span>Sign In</span>
                      <ChevronRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
                    </div>
                  )}
                </Button>
              </>
            )}
          </form>

          <div className="relative my-4">
            <Separator className="bg-slate-100" />
            <span className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 bg-white px-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">
              Zero Trust OAuth
            </span>
          </div>

          <GoogleLoginButton onClick={handleGoogleLogin} disabled={isLoading} />

          <p className="text-center text-sm text-slate-500 mt-4 font-medium italic">
            First time?{' '}
            <Link to="/signup" className="text-indigo-600 hover:text-indigo-700 font-black not-italic hover:underline underline-offset-4">
              Create Secure Profile
            </Link>
          </p>
        </CardContent>

        <div className="bg-slate-50 p-4 border-t border-slate-100 flex justify-center items-center gap-2 text-[10px] text-slate-400 font-bold uppercase tracking-widest">
          <ShieldCheck className="h-3 w-3 text-emerald-500" />
          Military-Grade Encryption Standard
        </div>
      </Card>
    </div>
  );
};

export default Login;
