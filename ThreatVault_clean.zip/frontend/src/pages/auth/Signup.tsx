import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Shield, Mail, Lock, Eye, EyeOff, User, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import RoleDropdown from '@/components/auth/RoleDropdown';
import EmployeeFields from '@/components/auth/EmployeeFields';
import GoogleLoginButton from '@/components/auth/GoogleLoginButton';
import { useAuth, UserRole } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';

const Signup: React.FC = () => {
  const navigate = useNavigate();
  const { signup, googleLogin, isLoading } = useAuth();
  
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [role, setRole] = useState<UserRole>('employee');
  const [employeeId, setEmployeeId] = useState('');
  const [orgCode, setOrgCode] = useState('');
  const [department, setDepartment] = useState('');
  const [authorizationCode, setAuthorizationCode] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const showEmployeeFields = role !== 'student' && role !== 'administrator';
  const requiresApproval = role !== 'student' && role !== 'administrator';

  useEffect(() => {
    setName('');
    setEmail('');
    setPassword('');
    setConfirmPassword('');
    setRole('employee');
    setEmployeeId('');
    setOrgCode('');
    setDepartment('');
    setAuthorizationCode('');
    setErrors({});
    setShowPassword(false);
  }, []);

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!name) newErrors.name = 'Name is required';
    if (!email) newErrors.email = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(email)) newErrors.email = 'Invalid email format';
    
    if (!password) newErrors.password = 'Password is required';
    else if (password.length < 8) newErrors.password = 'Password must be at least 8 characters';
    else if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(password)) {
      newErrors.password = 'Password must contain uppercase, lowercase, and number';
    }
    
    if (password !== confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }
    
    if (showEmployeeFields) {
      if (!employeeId) newErrors.employeeId = 'Employee ID is required';
      if (!orgCode) newErrors.orgCode = 'Organization code is required';
      if (!department) newErrors.department = 'Department is required';
    }

    if (requiresApproval && !authorizationCode) {
      newErrors.authorizationCode = 'Authorization Code is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    try {
      await signup({
        name,
        email,
        password,
        role,
        employeeId: showEmployeeFields ? employeeId : undefined,
        orgCode: showEmployeeFields ? orgCode : undefined,
        department: showEmployeeFields ? department : undefined,
        authorizationCode: requiresApproval ? authorizationCode : undefined,
      });

      if (role === 'student') {
        toast({
          title: 'Account created!',
          description: 'Welcome to ThreatVault!',
        });
        navigate('/dashboard');
      } else {
        toast({
          title: 'Account created!',
          description: 'Your account is pending approval.',
        });
        navigate('/pending-approval');
      }
    } catch (error) {
      toast({
        title: 'Signup failed',
        description: 'Please try again.',
        variant: 'destructive',
      });
    }
  };

  const handleGoogleSignup = async () => {
    try {
      await googleLogin('mock_google_token');
      toast({
        title: 'Google signup successful',
        description: 'Please complete your profile.',
      });
      navigate('/dashboard');
    } catch (error) {
      toast({
        title: 'Google signup failed',
        description: 'Please try again.',
        variant: 'destructive',
      });
    }
  };

  return (
    <div className="h-screen flex items-center justify-center bg-background p-4 auth-bg overflow-hidden">
      <div className="absolute inset-0 gradient-hero" />
      
      <Card className="w-full max-w-lg relative animate-scale-in max-h-[calc(100vh-8rem)] overflow-y-auto my-8">
        <CardHeader className="text-center py-4 px-4">
          <Link to="/" className="flex items-center justify-center gap-2 mb-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg gradient-primary">
              <Shield className="h-4 w-4 text-primary-foreground" />
            </div>
            <span className="text-lg font-bold text-foreground">ThreatVault</span>
          </Link>
          <CardTitle className="text-lg">Create Account</CardTitle>
          <CardDescription className="text-xs">Join the secure file sharing platform</CardDescription>
        </CardHeader>
        
        <CardContent className="px-4 py-3">
          {requiresApproval && (
            <Alert className="mb-3 border-warning/50 bg-warning/10">
              <AlertDescription className="text-xs">
                Non-student accounts require approval. Your details will be verified against the employee registry.
              </AlertDescription>
            </Alert>
          )}

          <form onSubmit={handleSubmit} className="space-y-2">
            <div className="space-y-1">
              <Label htmlFor="name" className="text-xs">Full Name</Label>
              <div className="relative">
                <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="name"
                  placeholder="John Doe"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className={`pl-10 ${errors.name ? 'border-destructive' : ''}`}
                />
              </div>
              {errors.name && <p className="text-xs text-destructive">{errors.name}</p>}
            </div>

            <div className="space-y-1">
              <Label htmlFor="email" className="text-xs">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="email"
                  type="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className={`pl-10 text-sm ${errors.email ? 'border-destructive' : ''}`}
                />
              </div>
              {errors.email && <p className="text-xs text-destructive">{errors.email}</p>}
            </div>

            <div className="space-y-1">
              <Label htmlFor="password" className="text-xs">Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className={`pl-10 pr-10 ${errors.password ? 'border-destructive' : ''}`}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-3 text-muted-foreground hover:text-foreground"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              {errors.password && <p className="text-xs text-destructive">{errors.password}</p>}
            </div>

            <div className="space-y-1">
              <Label htmlFor="confirmPassword" className="text-xs">Confirm Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="confirmPassword"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className={`pl-10 text-sm ${errors.confirmPassword ? 'border-destructive' : ''}`}
                />
              </div>
              {errors.confirmPassword && <p className="text-xs text-destructive">{errors.confirmPassword}</p>}
            </div>

            <div className="space-y-1">
              <Label className="text-xs">Role</Label>
              <RoleDropdown value={role} onChange={setRole} />
            </div>

            {requiresApproval && (
              <div className="space-y-1">
                <Label htmlFor="authorizationCode" className="text-xs">Authorization Code</Label>
                <div className="relative">
                  <Shield className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="authorizationCode"
                    type="text"
                    placeholder="Provide registration token"
                    value={authorizationCode}
                    onChange={(e) => setAuthorizationCode(e.target.value)}
                    className={`pl-10 text-sm ${errors.authorizationCode ? 'border-destructive' : ''}`}
                  />
                </div>
                {errors.authorizationCode && <p className="text-xs text-destructive">{errors.authorizationCode}</p>}
              </div>
            )}

            {showEmployeeFields && (
              <EmployeeFields
                employeeId={employeeId}
                orgCode={orgCode}
                department={department}
                onEmployeeIdChange={setEmployeeId}
                onOrgCodeChange={setOrgCode}
                onDepartmentChange={setDepartment}
                errors={errors}
              />
            )}

            <Button type="submit" className="w-full text-xs py-1" disabled={isLoading}>
              {isLoading ? (
                <>
                  <Loader2 className="h-3 w-3 animate-spin mr-2" />
                  Creating account...
                </>
              ) : (
                'Create Account'
              )}
            </Button>
          </form>

          <div className="relative my-3">
            <Separator />
            <span className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 bg-card px-2 text-xs text-muted-foreground">
              OR
            </span>
          </div>

          <GoogleLoginButton onClick={handleGoogleSignup} disabled={isLoading} isSignUp />

          <p className="text-center text-xs text-muted-foreground mt-3">
            Already have an account?{' '}
            <Link to="/login" className="text-primary hover:underline font-medium">
              Sign in
            </Link>
          </p>
        </CardContent>
      </Card>
    </div>
  );
};

export default Signup;
