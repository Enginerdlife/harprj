import React from 'react';
import { Link } from 'react-router-dom';
import { Shield, Clock, Mail, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth } from '@/contexts/AuthContext';

const PendingApproval: React.FC = () => {
  const { user, logout } = useAuth();

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="absolute inset-0 gradient-hero" />
      
      <Card className="w-full max-w-md relative animate-scale-in text-center">
        <CardHeader>
          <div className="flex items-center justify-center mb-4">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-warning/20">
              <Clock className="h-8 w-8 text-warning" />
            </div>
          </div>
          <CardTitle>Approval Pending</CardTitle>
          <CardDescription>
            Your account is awaiting verification and approval
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <div className="p-4 rounded-lg bg-muted/50 text-left space-y-2">
            <p className="text-sm text-muted-foreground">
              <span className="font-medium text-foreground">Email:</span> {user?.email}
            </p>
            <p className="text-sm text-muted-foreground">
              <span className="font-medium text-foreground">Requested Role:</span>{' '}
              <span className="capitalize">{user?.requestedRole?.replace('_', ' ')}</span>
            </p>
            {user?.employeeId && (
              <p className="text-sm text-muted-foreground">
                <span className="font-medium text-foreground">Employee ID:</span> {user.employeeId}
              </p>
            )}
          </div>

          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Your account details are being verified against the employee registry.
              An administrator or HR will review your request shortly.
            </p>
            <p className="text-sm text-muted-foreground flex items-center justify-center gap-2">
              <Mail className="h-4 w-4" />
              You'll receive an email once approved.
            </p>
          </div>

          <div className="flex flex-col gap-2">
            <Button variant="outline" onClick={logout} className="w-full">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Sign Out
            </Button>
            <Button asChild variant="ghost" className="w-full">
              <Link to="/">Return to Home</Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default PendingApproval;
