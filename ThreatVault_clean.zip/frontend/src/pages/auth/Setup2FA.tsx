import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield, Key, Smartphone, Copy, Check, Loader2, MessageSquare, QrCode } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from '@/hooks/use-toast';

const Setup2FA: React.FC = () => {
  const navigate = useNavigate();
  const [method, setMethod] = useState<'app' | 'sms'>('app');
  const [step, setStep] = useState<'setup' | 'verify'>('setup');
  const [verificationCode, setVerificationCode] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const [secretKey, setSecretKey] = useState('');
  const [qrCodeData, setQrCodeData] = useState('');
  const [otpAuthUrl, setOtpAuthUrl] = useState('');

  // Fetch secret from backend when entering setup (only for App initially)
  React.useEffect(() => {
    if (method === 'app' && step === 'setup') {
      initAppSetup();
    }
  }, [method, step]);

  const initAppSetup = async () => {
    try {
      setIsLoading(true);
      const { authAPI } = await import('@/lib/api');
      const response = await authAPI.setup2FA('app');
      const { secret, qrCode, otpauth_url } = response.data.data;
      setSecretKey(secret);
      setQrCodeData(qrCode);
      setOtpAuthUrl(otpauth_url);
    } catch (error) {
      console.error('Failed to setup 2FA', error);
      toast({
        title: 'Error',
        description: 'Failed to initialize 2FA setup.',
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const initSmsSetup = async () => {
    if (!phoneNumber) {
      toast({ title: 'Error', description: 'Phone number required.', variant: 'destructive' });
      return;
    }
    try {
      setIsLoading(true);
      const { authAPI } = await import('@/lib/api');
      // This will trigger the mock SMS send from backend
      const response = await authAPI.setup2FA('sms', phoneNumber);
      const { secret } = response.data.data;
      setSecretKey(secret); // Backend returns secret even for SMS (to verify provided code against it stateless)

      toast({
        title: 'Code Sent',
        description: 'Check your phone (or backend console) for the code.',
      });
      setStep('verify');
    } catch (error: any) {
      console.error('Failed to setup SMS 2FA', error);
      toast({
        title: 'Error',
        description: error.response?.data?.message || 'Failed to send SMS.',
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = async () => {
    await navigator.clipboard.writeText(secretKey);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast({
      title: 'Copied!',
      description: 'Secret key copied to clipboard.',
    });
  };

  const handleVerify = async () => {
    if (verificationCode.length !== 6) {
      toast({
        title: 'Invalid code',
        description: 'Please enter a 6-digit verification code.',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);

    try {
      const { authAPI } = await import('@/lib/api');
      // Pass method and phoneNumber to verify
      await authAPI.verify2FA(verificationCode, method, method === 'sms' ? phoneNumber : undefined);

      toast({
        title: '2FA Enabled',
        description: 'Two-factor authentication has been set up successfully.',
      });
      navigate('/dashboard');
    } catch (error: any) {
      console.error('Verify failed', error);
      toast({
        title: 'Verification Failed',
        description: error.response?.data?.message || 'Invalid code. Please try again.',
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="absolute inset-0 gradient-hero" />

      <Card className="w-full max-w-md relative animate-scale-in">
        <CardHeader className="text-center">
          <div className="flex items-center justify-center mb-4">
            <div className="flex h-14 w-14 items-center justify-center rounded-full gradient-primary">
              <Key className="h-7 w-7 text-primary-foreground" />
            </div>
          </div>
          <CardTitle>Set Up Two-Factor Authentication</CardTitle>
          <CardDescription>
            Secure your account with an additional layer of protection
          </CardDescription>
        </CardHeader>

        <CardContent>
          <Tabs value={method} onValueChange={(v) => { setMethod(v as 'app' | 'sms'); setStep('setup'); }} className="space-y-6">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="app" className="flex items-center gap-2">
                <QrCode className="h-4 w-4" /> Authenticator App
              </TabsTrigger>
              <TabsTrigger value="sms" className="flex items-center gap-2">
                <MessageSquare className="h-4 w-4" /> Mobile OTP
              </TabsTrigger>
            </TabsList>

            <TabsContent value="app" className="space-y-6 animate-in slide-in-from-left-2 duration-300">
              {step === 'setup' ? (
                <>
                  <div className="space-y-4">
                    <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                      <Smartphone className="h-5 w-5 text-primary" />
                      <div className="text-sm">
                        <p className="font-medium text-foreground">Step 1: Install an authenticator app</p>
                        <p className="text-muted-foreground">Google Authenticator, Authy, or similar</p>
                      </div>
                    </div>

                    <div className="p-4 rounded-lg bg-muted/50 space-y-3">
                      <p className="text-sm font-medium text-foreground">Step 2: Scan QR code or enter key manually</p>

                      {/* QR Code */}
                      <div className="aspect-square max-w-[180px] mx-auto bg-card rounded-lg border border-border flex items-center justify-center overflow-hidden">
                        {qrCodeData ? (
                          <img src={qrCodeData} alt="2FA QR Code" className="w-full h-full object-contain" />
                        ) : (
                          <div className="text-center p-4">
                            <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto" />
                          </div>
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        <Input value={secretKey} readOnly className="font-mono text-sm" />
                        <Button variant="outline" size="icon" onClick={handleCopy}>
                          {copied ? <Check className="h-4 w-4 text-success" /> : <Copy className="h-4 w-4" />}
                        </Button>
                      </div>
                    </div>
                  </div>
                  <Button onClick={() => setStep('verify')} className="w-full" disabled={!secretKey}>
                    Continue to Verification
                  </Button>
                </>
              ) : (
                <VerifyStep
                  onBack={() => setStep('setup')}
                  onVerify={handleVerify}
                  code={verificationCode}
                  setCode={setVerificationCode}
                  isLoading={isLoading}
                />
              )}
            </TabsContent>

            <TabsContent value="sms" className="space-y-6 animate-in slide-in-from-right-2 duration-300">
              {step === 'setup' ? (
                <div className="space-y-4">
                  <div className="p-4 rounded-lg bg-muted/50">
                    <p className="text-sm font-medium text-foreground mb-2">Enter your mobile number</p>
                    <p className="text-xs text-muted-foreground mb-4">We will send a one-time verification code.</p>
                    <Input
                      placeholder="+1 (555) 000-0000"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      type="tel"
                    />
                  </div>
                  <Button onClick={initSmsSetup} className="w-full" disabled={isLoading || !phoneNumber}>
                    {isLoading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                    Send Verification Code
                  </Button>
                </div>
              ) : (
                <VerifyStep
                  onBack={() => setStep('setup')}
                  onVerify={handleVerify}
                  code={verificationCode}
                  setCode={setVerificationCode}
                  isLoading={isLoading}
                />
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

const VerifyStep = ({ onBack, onVerify, code, setCode, isLoading }: any) => (
  <div className="space-y-4">
    <div className="p-4 rounded-lg bg-muted/50">
      <p className="text-sm text-muted-foreground mb-4">
        Enter the 6-digit code to complete setup.
      </p>
      <div className="space-y-2">
        <Label htmlFor="code">Verification Code</Label>
        <Input
          id="code"
          value={code}
          onChange={(e) => setCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
          placeholder="000000"
          className="text-center text-2xl font-mono tracking-widest"
          maxLength={6}
        />
      </div>
    </div>
    <div className="flex gap-2">
      <Button variant="outline" onClick={onBack} className="flex-1">Back</Button>
      <Button onClick={onVerify} disabled={isLoading} className="flex-1">
        {isLoading ? <><Loader2 className="h-4 w-4 animate-spin mr-2" />Verifying...</> : 'Enable 2FA'}
      </Button>
    </div>
  </div>
);

export default Setup2FA;
