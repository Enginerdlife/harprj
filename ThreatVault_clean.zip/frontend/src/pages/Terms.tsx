import React from 'react';
import PublicLayout from '@/components/layout/PublicLayout';
import { Gavel, ShieldAlert, FileText, Scale } from 'lucide-react';

const Terms: React.FC = () => {
    return (
        <PublicLayout>
            <div className="container py-24 md:py-32 max-w-4xl mx-auto">
                <div className="flex items-center gap-3 mb-8">
                    <div className="h-12 w-12 bg-slate-900 rounded-2xl flex items-center justify-center shadow-lg">
                        <Scale className="h-6 w-6 text-white" />
                    </div>
                    <div>
                        <h1 className="text-4xl font-black text-slate-900 tracking-tight">Terms of Service</h1>
                        <p className="text-slate-500 font-bold uppercase tracking-widest text-[10px]">Governance & Operational Protocol</p>
                    </div>
                </div>

                <div className="prose prose-slate max-w-none space-y-10">
                    <section className="space-y-4">
                        <h2 className="text-2xl font-black text-slate-900 flex items-center gap-2">
                            <ShieldAlert className="h-5 w-5 text-indigo-600" />
                            1. Acceptable Strategic Use
                        </h2>
                        <p className="text-slate-600 leading-relaxed font-medium">
                            ThreatVault is designed for the secure storage and transmission of legitimate sensitive assets. Users are strictly prohibited from using the platform for transporting illicit materials, malware, or data obtained through illegal means.
                        </p>
                    </section>

                    <section className="space-y-4">
                        <h2 className="text-2xl font-black text-slate-900">2. Security Responsibility</h2>
                        <p className="text-slate-600 leading-relaxed font-medium">
                            Because ThreatVault is a **Zero-Knowledge** platform, we cannot recover lost master keys or passwords. The technical responsibility for key management and MFA device security lies solely with the user. Loss of access credentials results in permanent, irretrievable data loss for that specific account.
                        </p>
                    </section>

                    <section className="space-y-4">
                        <h2 className="text-2xl font-black text-slate-900">3. Infrastructure Availability</h2>
                        <p className="text-slate-600 leading-relaxed font-medium">
                            We leverage Enterprise-grade cloud infrastructure (Firebase) to ensure high availability. Our 99.9% uptime SLA applies to high-tier professional profiles.
                        </p>
                    </section>

                    <section className="space-y-4 p-8 bg-indigo-50 border border-indigo-100 rounded-[2rem]">
                        <h2 className="text-2xl font-black text-slate-900 flex items-center gap-2">
                            <FileText className="h-5 w-5 text-indigo-600" />
                            Legal Jurisdiction
                        </h2>
                        <p className="text-slate-700 leading-relaxed font-bold">
                            These terms are governed by the laws of intellectual property and digital security. Any disputes arising from the use of this secure tunnel will be resolved through mandatory arbitration.
                        </p>
                    </section>

                    <div className="pt-10 border-t border-slate-100">
                        <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">Legal Document Ref: TV-TOS-2023-A</p>
                    </div>
                </div>
            </div>
        </PublicLayout>
    );
};

export default Terms;
