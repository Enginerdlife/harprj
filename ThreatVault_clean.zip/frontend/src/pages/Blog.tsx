import React from 'react';
import PublicLayout from '@/components/layout/PublicLayout';
import { ArrowRight } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const Blog: React.FC = () => {
    const posts = [
        {
            title: 'The Future of Zero-Knowledge Encryption',
            date: 'Jan 24, 2024',
            category: 'Security',
            excerpt: 'Exploring why server-side master keys are a thing of the past and how client-side hashing is changing the industry.',
        },
        {
            title: 'Demystifying AES-256-GCM',
            date: 'Jan 15, 2024',
            category: 'Technical',
            excerpt: 'A deep dive into the encryption standard that powers Threatvault.',
        },
        {
            title: 'MFA: Why SMS OTP Isn’t Enough',
            date: 'Jan 10, 2024',
            category: 'Best Practices',
            excerpt: 'Comparing QR-based authenticators with SMS and why we mandate dual-layer protection for admins.',
        },
    ];

    return (
        <PublicLayout>
            <div className="container py-24 md:py-32">
                <div className="max-w-3xl mb-16">
                    <h1 className="text-5xl font-black text-slate-900 mb-6 tracking-tight">Intelligence Feed</h1>
                    <p className="text-xl text-slate-500 font-medium">Stay updated with the latest in cryptographic tunneling and enterprise security protocols.</p>
                </div>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {posts.map((post, index) => (
                        <Card key={index} className="rounded-[2.5rem] border-slate-100 hover:border-indigo-500/30 transition-all group overflow-hidden shadow-sm hover:shadow-xl">
                            <div className="h-48 bg-slate-900 relative">
                                <div className="absolute inset-0 bg-indigo-600/20 group-hover:bg-indigo-600/10 transition-colors" />
                                <div className="absolute top-6 left-6">
                                    <span className="px-3 py-1 bg-white/10 backdrop-blur-md rounded-full text-[10px] font-black text-white uppercase tracking-widest">{post.category}</span>
                                </div>
                            </div>
                            <CardContent className="p-8">
                                <p className="text-xs font-bold text-slate-400 mb-2 uppercase tracking-tight">{post.date}</p>
                                <h3 className="text-xl font-black text-slate-900 mb-4 group-hover:text-indigo-600 transition-colors">{post.title}</h3>
                                <p className="text-slate-500 font-medium text-sm leading-relaxed mb-6">{post.excerpt}</p>
                                <Button variant="ghost" className="p-0 h-auto font-black text-indigo-600 hover:text-indigo-700 hover:bg-transparent flex gap-2 group/btn">
                                    Read Analysis
                                    <ArrowRight className="h-4 w-4 transition-transform group-hover/btn:translate-x-1" />
                                </Button>
                            </CardContent>
                        </Card>
                    ))}
                </div>
            </div>
        </PublicLayout>
    );
};

export default Blog;
