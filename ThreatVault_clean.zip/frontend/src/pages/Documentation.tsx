import React from 'react';
import { Book, Code, Shield, Key, FileText, Users, Terminal, Lock } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import PublicLayout from '@/components/layout/PublicLayout';

const Documentation: React.FC = () => {
  return (
    <PublicLayout>
      <section className="py-12 md:py-20">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h1 className="text-4xl font-bold text-foreground mb-4">Documentation</h1>
              <p className="text-lg text-muted-foreground">
                Complete guide to ThreatVault's API, security features, and integration options.
              </p>
            </div>

            <Tabs defaultValue="getting-started" className="w-full">
              <TabsList className="grid w-full grid-cols-4 mb-8">
                <TabsTrigger value="getting-started">Getting Started</TabsTrigger>
                <TabsTrigger value="api">API Reference</TabsTrigger>
                <TabsTrigger value="security">Security</TabsTrigger>
                <TabsTrigger value="roles">Roles & Access</TabsTrigger>
              </TabsList>

              <TabsContent value="getting-started" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Book className="h-5 w-5 text-primary" />
                      Quick Start Guide
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="font-semibold text-foreground mb-2">1. Create an Account</h4>
                      <p className="text-muted-foreground">
                        Sign up with your email or Google account. Select your role and complete
                        employee verification if required.
                      </p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground mb-2">2. Enable 2FA</h4>
                      <p className="text-muted-foreground">
                        For non-student roles, two-factor authentication is required. Set up
                        your authenticator app during onboarding.
                      </p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground mb-2">3. Upload Your First File</h4>
                      <p className="text-muted-foreground">
                        Files are encrypted in your browser before upload. Drag and drop or
                        click to select files.
                      </p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground mb-2">4. Share Securely</h4>
                      <p className="text-muted-foreground">
                        Generate time-limited share links with customizable expiration periods.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="api" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Code className="h-5 w-5 text-primary" />
                      API Reference
                    </CardTitle>
                    <CardDescription>RESTful API endpoints for ThreatVault integration</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      <div>
                        <h4 className="font-semibold text-foreground mb-2 flex items-center gap-2">
                          <Terminal className="h-4 w-4" />
                          Authentication
                        </h4>
                        <div className="bg-muted rounded-lg p-4 font-mono text-sm">
                          <p className="text-primary">POST /api/auth/login</p>
                          <p className="text-muted-foreground">{"{ email, password, role, employeeId? }"}</p>
                        </div>
                      </div>
                      <div>
                        <h4 className="font-semibold text-foreground mb-2 flex items-center gap-2">
                          <FileText className="h-4 w-4" />
                          File Upload
                        </h4>
                        <div className="bg-muted rounded-lg p-4 font-mono text-sm">
                          <p className="text-primary">POST /api/files/upload</p>
                          <p className="text-muted-foreground">FormData: encryptedFile, iv, keyHash</p>
                        </div>
                      </div>
                      <div>
                        <h4 className="font-semibold text-foreground mb-2 flex items-center gap-2">
                          <Key className="h-4 w-4" />
                          Create Share
                        </h4>
                        <div className="bg-muted rounded-lg p-4 font-mono text-sm">
                          <p className="text-primary">POST /api/shares</p>
                          <p className="text-muted-foreground">{"{ fileId, recipientEmail, expiresIn }"}</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="security" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Shield className="h-5 w-5 text-primary" />
                      Security Architecture
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div>
                      <h4 className="font-semibold text-foreground mb-2 flex items-center gap-2">
                        <Lock className="h-4 w-4" />
                        Client-Side Encryption
                      </h4>
                      <p className="text-muted-foreground mb-2">
                        ThreatVault uses AES-256-GCM encryption performed entirely in your browser.
                        Your encryption keys never leave your device.
                      </p>
                      <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1">
                        <li>256-bit AES keys generated client-side</li>
                        <li>Unique IV for each encryption operation</li>
                        <li>Zero-knowledge server architecture</li>
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground mb-2">Immutable Audit Logs</h4>
                      <p className="text-muted-foreground mb-2">
                        All activities are logged with SHA-256 hash chains ensuring tamper-evidence.
                      </p>
                      <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1">
                        <li>Each log entry contains hash of previous entry</li>
                        <li>Forward integrity prevents retroactive modification</li>
                        <li>Complete chain verification available</li>
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground mb-2">Threat Detection</h4>
                      <p className="text-muted-foreground mb-2">
                        Real-time monitoring detects and alerts on suspicious activities.
                      </p>
                      <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1">
                        <li>Unusual IP address detection</li>
                        <li>Failed authentication attempt tracking</li>
                        <li>Abnormal download frequency alerts</li>
                        <li>Geographic anomaly detection</li>
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="roles" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Users className="h-5 w-5 text-primary" />
                      Role-Based Access Control
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {[
                        { role: 'Student', access: 'Limited access, auto-activated, no 2FA required' },
                        { role: 'Employee', access: 'Standard access, requires verification and approval' },
                        { role: 'Manager', access: 'Team oversight, file management, member viewing' },
                        { role: 'Administrator', access: 'Full system access, user approval, security settings' },
                        { role: 'IT Support', access: 'Technical support access, system diagnostics' },
                        { role: 'Auditor', access: 'Read-only access to audit logs and compliance reports' },
                        { role: 'Compliance Officer', access: 'Compliance monitoring, policy enforcement' },
                        { role: 'Security Analyst', access: 'Security alerts, threat monitoring, incident response' },
                        { role: 'HR', access: 'User management, employee verification, approvals' },
                      ].map((item, index) => (
                        <div key={index} className="flex items-start gap-4 p-3 rounded-lg bg-muted/50">
                          <div className="font-semibold text-foreground min-w-[140px]">{item.role}</div>
                          <div className="text-muted-foreground">{item.access}</div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </section>
    </PublicLayout>
  );
};

export default Documentation;
