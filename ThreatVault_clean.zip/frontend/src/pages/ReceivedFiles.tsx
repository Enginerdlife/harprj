import React from 'react';
import { Download, User, Clock, Lock, Eye, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import DashboardLayout from '@/components/layout/DashboardLayout';
import { toast } from 'sonner';

import { sharesAPI } from '@/lib/api';
import { useNavigate } from 'react-router-dom';

const ReceivedFiles: React.FC = () => {
  const [receivedFiles, setReceivedFiles] = React.useState<any[]>([]);
  const [isLoading, setIsLoading] = React.useState(true);
  const [shareCode, setShareCode] = React.useState('');
  const navigate = useNavigate();

  const fetchReceived = async () => {
    try {
      setIsLoading(true);
      const response = await sharesAPI.getMyShares();
      setReceivedFiles(response.data.data || []);
    } catch (error) {
      console.error('Failed to fetch received files:', error);
    } finally {
      setIsLoading(false);
    }
  };

  React.useEffect(() => {
    fetchReceived();
  }, []);

  const handleManualReceive = () => {
    if (!shareCode.trim()) return;
    navigate(`/share/${shareCode.trim()}`);
  };

  const handleDownload = (shareId: string) => {
    navigate(`/share/${shareId}`);
  };

  const availableFiles = receivedFiles;
  const expiredFiles = []; // Backend currently filters out expired ones

  return (
    <DashboardLayout>
      <div className="space-y-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Received Files</h1>
            <p className="text-muted-foreground mt-1">
              Files shared with you by others
            </p>
          </div>

          <div className="flex items-center gap-2 max-w-sm w-full">
            <div className="relative flex-1">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="Paste Share Code..."
                className="w-full pl-10 pr-4 py-2 bg-background border border-input rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
                value={shareCode}
                onChange={(e) => setShareCode(e.target.value)}
              />
            </div>
            <Button onClick={handleManualReceive} disabled={!shareCode}>
              Receive
            </Button>
          </div>
        </div>

        {/* Available Files */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold text-foreground">
            Available ({availableFiles.length})
          </h2>

          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : availableFiles.length === 0 ? (
            <Card>
              <CardContent className="py-8 text-center text-muted-foreground">
                No files available in your inbox
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {availableFiles.map((share) => (
                <Card key={share.id} className="hover:border-primary/30 transition-colors">
                  <CardContent className="p-4">
                    <div className="flex flex-col md:flex-row md:items-center gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <Lock className="h-4 w-4 text-emerald-500" />
                          <h3 className="font-medium text-foreground truncate">
                            {share.file?.name}
                          </h3>
                          <Badge className="bg-emerald-50 text-emerald-600 border-emerald-100">
                            Available
                          </Badge>
                        </div>
                        <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <User className="h-3 w-3" />
                            Sender ID: {share.owner_id.substring(0, 8)}...
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            Expires: {new Date(share.expires_at).toLocaleDateString()}
                          </span>
                          <span>{(share.file?.size / 1024).toFixed(1)} KB</span>
                        </div>
                      </div>
                      <Button onClick={() => handleDownload(share.id)}>
                        <Eye className="h-4 w-4 mr-2" />
                        Access File
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>

        {/* Expired Files */}
        {expiredFiles.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-foreground">
              Expired ({expiredFiles.length})
            </h2>
            <div className="space-y-3">
              {expiredFiles.map((file) => (
                <Card key={file.id} className="opacity-60">
                  <CardContent className="p-4">
                    <div className="flex flex-col md:flex-row md:items-center gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-medium text-foreground truncate">
                            {file.fileName}
                          </h3>
                          <Badge variant="secondary">Expired</Badge>
                        </div>
                        <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <User className="h-3 w-3" />
                            {file.sender}
                          </span>
                          <span>Received: {file.receivedAt}</span>
                        </div>
                      </div>
                      <Button variant="outline" disabled>
                        <Download className="h-4 w-4 mr-2" />
                        Expired
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
};

export default ReceivedFiles;
