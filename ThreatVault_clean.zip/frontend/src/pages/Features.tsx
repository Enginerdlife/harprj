import React from 'react';
import { Link } from 'react-router-dom';
import {
  Shield,
  Lock,
  Key,
  FileCheck,
  Users,
  Activity,
  Eye,
  AlertTriangle,
  Clock,
  Globe,
  Fingerprint,
  Database,
  ArrowRight,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import PublicLayout from '@/components/layout/PublicLayout';

const Features: React.FC = () => {
  const securityFeatures = [
    {
      icon: Lock,
      title: 'AES-256-GCM Encryption',
      description: 'Files are encrypted in your browser using military-grade AES-256-GCM encryption before upload. Even we cannot read your files.',
      details: ['Client-side encryption', 'Zero-knowledge architecture', 'Secure key management'],
    },
    {
      icon: Key,
      title: 'Time-Limited Secure Links',
      description: 'Generate share links that automatically expire. Revoke access at any time with immediate effect.',
      details: ['Configurable expiration', 'One-click revocation', 'Access count limits'],
    },
    {
      icon: FileCheck,
      title: 'Immutable Audit Logs',
      description: 'SHA-256 hash chain ensures complete integrity of all access logs. Tamper-evident by design.',
      details: ['Hash-chained entries', 'Forward integrity', 'Complete traceability'],
    },
    {
      icon: AlertTriangle,
      title: 'Threat Detection',
      description: 'Real-time monitoring detects suspicious activities including unusual IPs, failed attempts, and anomalous downloads.',
      details: ['Unusual IP detection', 'Brute force protection', 'Anomaly alerts'],
    },
    {
      icon: Eye,
      title: 'Complete Access History',
      description: 'Track every access to your files: who, when, from where, and what action was performed.',
      details: ['IP logging', 'Geo-location tracking', 'Action timestamps'],
    },
    {
      icon: Users,
      title: 'Role-Based Access Control',
      description: 'Enterprise-grade RBAC with employee verification, department-based permissions, and approval workflows.',
      details: ['9 built-in roles', 'Custom permissions', 'Approval workflows'],
    },
  ];

  const complianceFeatures = [
    {
      icon: Database,
      title: 'Data Residency',
      description: 'Choose where your data is stored to meet regional compliance requirements.',
    },
    {
      icon: Clock,
      title: 'Retention Policies',
      description: 'Automated data retention and deletion policies for regulatory compliance.',
    },
    {
      icon: Globe,
      title: 'GDPR Compliant',
      description: 'Full compliance with GDPR, CCPA, and other privacy regulations.',
    },
    {
      icon: Fingerprint,
      title: 'Multi-Factor Auth',
      description: 'Mandatory 2FA for sensitive roles with multiple authentication options.',
    },
  ];

  return (
    <PublicLayout>
      {/* Hero */}
      <section className="py-20 md:py-32 relative overflow-hidden">
        <div className="absolute inset-0 gradient-hero" />
        <div className="container relative">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
              Enterprise Security Features
            </h1>
            <p className="text-lg text-muted-foreground mb-8">
              ThreatVault provides comprehensive security features designed for organizations
              that handle sensitive data and require complete visibility and control.
            </p>
          </div>
        </div>
      </section>

      {/* Main Features */}
      <section className="py-20 bg-muted/30">
        <div className="container">
          <div className="grid gap-8">
            {securityFeatures.map((feature, index) => (
              <Card
                key={index}
                className="overflow-hidden animate-fade-in"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="grid md:grid-cols-3 gap-6">
                  <CardHeader className="md:col-span-1 bg-primary/5">
                    <div className="h-14 w-14 rounded-xl gradient-primary flex items-center justify-center mb-4">
                      <feature.icon className="h-7 w-7 text-primary-foreground" />
                    </div>
                    <CardTitle className="text-xl">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="md:col-span-2 flex flex-col justify-center py-6">
                    <CardDescription className="text-base mb-4">
                      {feature.description}
                    </CardDescription>
                    <ul className="grid sm:grid-cols-3 gap-2">
                      {feature.details.map((detail, i) => (
                        <li key={i} className="flex items-center gap-2 text-sm text-foreground">
                          <div className="h-1.5 w-1.5 rounded-full bg-primary" />
                          {detail}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Compliance Section */}
      <section className="py-20">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">
              Compliance & Governance
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Meet regulatory requirements with built-in compliance features.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {complianceFeatures.map((feature, index) => (
              <Card key={index} className="text-center p-6">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <feature.icon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">{feature.title}</h3>
                <p className="text-sm text-muted-foreground">{feature.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 gradient-primary">
        <div className="container text-center">
          <h2 className="text-3xl font-bold text-primary-foreground mb-4">
            Experience Enterprise Security
          </h2>
          <p className="text-primary-foreground/80 mb-8 max-w-xl mx-auto">
            Start your free trial today and see how ThreatVault can protect your organization.
          </p>
          <Button asChild variant="secondary" size="lg">
            <Link to="/signup">
              Start Free Trial
              <ArrowRight className="h-4 w-4 ml-2" />
            </Link>
          </Button>
        </div>
      </section>
    </PublicLayout>
  );
};

export default Features;
