import React, { useState, useRef } from 'react';
import {
  Upload as UploadIcon,
  File,
  X,
  Lock,
  Shield,
  Check,
  AlertCircle,
  Loader2,
  Eye,
  EyeOff
} from 'lucide-react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { useFiles } from '@/contexts/FileContext';
import {
  deriveKeyFromPassword,
  encryptFile,
  arrayBufferToBase64,
  uint8ArrayToBase64
} from '@/lib/encryption';
import { toast } from 'sonner';
import DashboardLayout from '@/components/layout/DashboardLayout';

const Upload: React.FC = () => {
  const { uploadFile } = useFiles();
  const [dragActive, setDragActive] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [encryptionPassword, setEncryptionPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'encrypting' | 'uploading' | 'success' | 'error'>('idle');
  const inputRef = useRef<HTMLInputElement>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setSelectedFile(e.dataTransfer.files[0]);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0]);
    }
  };

  const removeFile = () => {
    setSelectedFile(null);
    setUploadStatus('idle');
    setUploadProgress(0);
  };

  const handleUpload = async () => {
    if (!selectedFile || !encryptionPassword) return;

    setIsUploading(true);
    setUploadStatus('encrypting');
    setUploadProgress(10);

    try {
      // 1. Generate Salt
      const salt = window.crypto.getRandomValues(new Uint8Array(16));

      // 2. Derive Key from Password
      const key = await deriveKeyFromPassword(encryptionPassword, salt);
      setUploadProgress(30);

      // 3. Encrypt File
      const { encryptedData, iv } = await encryptFile(selectedFile, key);
      setUploadStatus('uploading');
      setUploadProgress(60);

      // 4. Prepare Payload
      const payload = {
        name: selectedFile.name,
        size: selectedFile.size,
        type: selectedFile.type,
        iv: uint8ArrayToBase64(iv),
        salt: uint8ArrayToBase64(salt),
        encryptedData: arrayBufferToBase64(encryptedData),
        encryptionPassword: encryptionPassword // For backend verification hash
      };

      // 5. Send to Server
      await uploadFile(payload);

      setUploadStatus('success');
      setUploadProgress(100);
      toast.success('File uploaded and encrypted successfully!');

      // Reset after success
      setTimeout(() => {
        removeFile();
        setEncryptionPassword('');
        setUploadStatus('idle');
      }, 2000);

    } catch (error: any) {
      console.error('Upload failed:', error);
      setUploadStatus('error');
      toast.error(error?.message || 'Failed to encrypt or upload file');
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <DashboardLayout>
      <div className="container mx-auto max-w-4xl py-12 px-4 animate-in fade-in slide-in-from-bottom-4 duration-700">
        <div className="flex flex-col gap-8">
          <div className="space-y-2">
            <h1 className="text-4xl font-bold tracking-tight bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              Secure File Vault
            </h1>
            <p className="text-slate-500 text-lg">
              Upload and encrypt your most sensitive threats and research.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
            {/* Main Upload Area */}
            <div className="lg:col-span-3 space-y-6">
              <Card className={`relative overflow-hidden border-2 border-dashed transition-all duration-300 ${dragActive ? 'border-primary bg-primary/5 scale-[1.01]' : 'border-slate-200 bg-white hover:border-slate-300'
                } ${selectedFile ? 'border-indigo-200 bg-indigo-50/10' : ''}`}>
                <CardContent className="p-0">
                  <form
                    onDragEnter={handleDrag}
                    onDragLeave={handleDrag}
                    onDragOver={handleDrag}
                    onDrop={handleDrop}
                    className="relative min-h-[400px] flex flex-col items-center justify-center p-12 text-center"
                  >
                    <Input
                      ref={inputRef}
                      type="file"
                      className="hidden"
                      onChange={handleChange}
                    />

                    {!selectedFile ? (
                      <div className="space-y-6">
                        <div className="mx-auto w-20 h-20 rounded-full bg-blue-50 flex items-center justify-center shadow-inner group">
                          <UploadIcon className="w-10 h-10 text-blue-500 transition-transform group-hover:-translate-y-1" />
                        </div>
                        <div className="space-y-2">
                          <p className="text-xl font-semibold text-slate-800">
                            Drop files here or click to browse
                          </p>
                          <p className="text-sm text-slate-500">
                            Maximum file size: 50MB. All files are encrypted client-side.
                          </p>
                        </div>
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => inputRef.current?.click()}
                          className="rounded-full px-8 border-slate-300 hover:bg-slate-50"
                        >
                          Select File
                        </Button>
                      </div>
                    ) : (
                      <div className="w-full space-y-8 animate-in zoom-in-95">
                        <div className="bg-white p-6 rounded-2xl shadow-sm border border-indigo-100 mx-auto max-w-md relative">
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            className="absolute -top-3 -right-3 h-8 w-8 rounded-full bg-white shadow-md border"
                            onClick={removeFile}
                            disabled={isUploading}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                          <div className="flex items-center gap-4">
                            <div className="h-14 w-14 rounded-xl bg-indigo-50 flex items-center justify-center">
                              <File className="h-8 w-8 text-indigo-600" />
                            </div>
                            <div className="text-left overflow-hidden">
                              <p className="font-semibold text-slate-900 truncate">{selectedFile.name}</p>
                              <p className="text-sm text-slate-500">
                                {(selectedFile.size / (1024 * 1024)).toFixed(2)} MB
                              </p>
                            </div>
                          </div>
                        </div>

                        {uploadStatus !== 'idle' && (
                          <div className="space-y-3 px-6">
                            <div className="flex justify-between text-sm font-medium">
                              <span className="text-slate-600">
                                {uploadStatus === 'encrypting' ? 'Performing AES-256 Encryption...' :
                                  uploadStatus === 'uploading' ? 'Transferring Secure Payload...' :
                                    uploadStatus === 'success' ? 'Ready!' : 'Processing...'}
                              </span>
                              <span className="text-indigo-600 font-bold">{uploadProgress}%</span>
                            </div>
                            <Progress value={uploadProgress} className="h-2 bg-indigo-50" />
                          </div>
                        )}
                      </div>
                    )}
                  </form>
                </CardContent>
              </Card>
            </div>

            {/* Security Panel */}
            <div className="lg:col-span-2 space-y-6">
              <Card className="border-slate-200 bg-white shadow-sm overflow-hidden">
                <div className="bg-slate-900 text-white p-5 flex items-center gap-3">
                  <Shield className="w-5 h-5 text-emerald-400" />
                  <h3 className="font-bold">Security Settings</h3>
                </div>
                <CardContent className="p-6 space-y-6">
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-sm font-semibold text-slate-700 flex items-center gap-2">
                        <Lock className="w-3.5 h-3.5" />
                        Encryption Password
                      </label>
                      <div className="relative">
                        <Input
                          type={showPassword ? 'text' : 'password'}
                          placeholder="Enter a strong password..."
                          value={encryptionPassword}
                          onChange={(e) => setEncryptionPassword(e.target.value)}
                          className="bg-slate-50 border-slate-200 focus:ring-indigo-500 h-10 pr-12"
                          disabled={isUploading || uploadStatus === 'success'}
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-indigo-600"
                          aria-label={showPassword ? 'Hide password' : 'Show password'}
                          disabled={isUploading || uploadStatus === 'success'}
                        >
                          {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                        </button>
                      </div>
                      <p className="text-xs text-slate-500 italic">
                        This password is required for decryption. It is never stored.
                      </p>
                      <div className="flex items-center gap-2 mt-2 text-rose-600 bg-rose-50 p-3 rounded-lg border border-rose-100">
                        <AlertCircle className="w-5 h-5 shrink-0" />
                        <p className="text-xs font-bold leading-tight">
                          IMPORTANT: Password should be remembered. If it is lost, the file can't be re-created or decrypted.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-slate-100">
                    <Button
                      className="w-full rounded-lg h-12 text-md font-bold transition-all shadow-md group overflow-hidden relative"
                      disabled={!selectedFile || !encryptionPassword || isUploading || uploadStatus === 'success'}
                      onClick={handleUpload}
                    >
                      <span className="relative z-10 flex items-center justify-center gap-2">
                        {isUploading ? (
                          <Loader2 className="w-5 h-5 animate-spin" />
                        ) : uploadStatus === 'success' ? (
                          <Check className="w-5 h-5" />
                        ) : (
                          <>
                            <Lock className="w-4 h-4" />
                            Encrypt & Upload
                          </>
                        )}
                      </span>
                    </Button>
                  </div>

                  <div className="space-y-4 pt-2">
                    <div className="flex gap-3 text-xs leading-relaxed">
                      <AlertCircle className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                      <p className="text-slate-500">
                        Files are encrypted on your machine using <strong>AES-256-GCM</strong>.
                        Only those with the password can read the contents.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="bg-emerald-50 border border-emerald-100 rounded-xl p-4 flex items-start gap-3">
                <Check className="w-5 h-5 text-emerald-600 mt-1" />
                <div>
                  <p className="text-sm font-bold text-emerald-900">Zero Trust Storage</p>
                  <p className="text-xs text-emerald-700">
                    Your raw data never touches our server. Only the encrypted ciphertext is stored.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}

export default Upload;
