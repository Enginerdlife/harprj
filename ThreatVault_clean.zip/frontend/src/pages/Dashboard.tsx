import React from 'react';
import { Link } from 'react-router-dom';
import {
  FileText,
  Upload,
  Share2,
  Download,
  Shield,
  AlertTriangle,
  TrendingUp,
  Clock,
  ArrowRight,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import DashboardLayout from '@/components/layout/DashboardLayout';
import StatsCard from '@/components/shared/StatsCard';
import SuspiciousAlertCard from '@/components/shared/SuspiciousAlertCard';
import { useAuth } from '@/contexts/AuthContext';
import { useFiles } from '@/contexts/FileContext';

const Dashboard: React.FC = () => {
  const { user, hasRole } = useAuth();
  const { files } = useFiles();

  const stats = [
    { title: 'Total Files', value: files.length, icon: FileText, variant: 'primary' as const },
    { title: 'Shared Files', value: 0, icon: Share2, variant: 'default' as const },
    { title: 'Active Shares', value: 0, icon: Clock, variant: 'success' as const },
    { title: 'System Security', value: '100%', icon: Shield, variant: 'default' as const },
  ];

  const recentActivity = files.slice(0, 5).map(f => ({
    file: f.name,
    action: 'Successfully Encrypted',
    time: new Date(f.createdAt).toLocaleDateString()
  }));

  const alerts = [];

  const showSecurityAlerts = hasRole(['administrator', 'security_analyst']);

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
            <p className="text-muted-foreground mt-1">
              Welcome back, {user?.name}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <Button asChild variant="outline">
              <Link to="/received">
                <Download className="h-4 w-4 mr-2" />
                Receive File
              </Link>
            </Button>
            <Button asChild>
              <Link to="/upload">
                <Upload className="h-4 w-4 mr-2" />
                Upload File
              </Link>
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((stat, index) => (
            <StatsCard
              key={index}
              title={stat.title}
              value={stat.value}
              icon={stat.icon}
              variant={stat.variant}
            />
          ))}
        </div>

        {/* Security Alerts */}
        {showSecurityAlerts && alerts.length > 0 && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold text-foreground flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-warning" />
                Security Alerts
              </h2>
              <Button asChild variant="ghost" size="sm">
                <Link to="/admin/suspicious">
                  View All
                  <ArrowRight className="h-4 w-4 ml-1" />
                </Link>
              </Button>
            </div>
            {alerts.map((alert) => (
              <SuspiciousAlertCard
                key={alert.id}
                {...alert}
                onDismiss={() => { }}
                onInvestigate={() => { }}
              />
            ))}
          </div>
        )}

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Recent Activity */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-primary" />
                Recent Activity
              </CardTitle>
              <CardDescription>Your latest file operations</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentActivity.map((item, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between py-2 border-b border-border last:border-0"
                  >
                    <div className="flex items-center gap-3">
                      <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center">
                        <FileText className="h-4 w-4 text-primary" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-foreground">{item.file}</p>
                        <p className="text-xs text-muted-foreground">{item.action}</p>
                      </div>
                    </div>
                    <span className="text-xs text-muted-foreground">{item.time}</span>
                  </div>
                ))}
              </div>
              <Button asChild variant="ghost" className="w-full mt-4">
                <Link to="/activity-logs">View All Activity</Link>
              </Button>
            </CardContent>
          </Card>

          {/* Platform Updates */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-primary" />
                Platform Updates
              </CardTitle>
              <CardDescription>Latest system notifications</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="flex gap-3">
                  <div className="h-8 w-8 rounded-lg bg-success/10 flex items-center justify-center flex-shrink-0">
                    <Shield className="h-4 w-4 text-success" />
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-foreground">Security Patch Applied</h4>
                    <p className="text-xs text-muted-foreground mt-1">
                      System wide security update has been successfully deployed.
                    </p>
                    <span className="text-xs text-muted-foreground mt-2 block">2 hours ago</span>
                  </div>
                </div>
                <div className="flex gap-3">
                  <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <TrendingUp className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-foreground">New Features Available</h4>
                    <p className="text-xs text-muted-foreground mt-1">
                      Check out the new advanced sharing controls in your settings.
                    </p>
                    <span className="text-xs text-muted-foreground mt-2 block">1 day ago</span>
                  </div>
                </div>
              </div>
              <Button asChild variant="outline" className="w-full mt-2">
                <Link to="/documentation">View Release Notes</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default Dashboard;
