import React from 'react';
import { Link } from 'react-router-dom';
import {
  Lock,
  Users,
  Activity,
  ArrowRight,
  CheckCircle,
  Vault,
  ShieldAlert,
  Fingerprint,
  History
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import PublicLayout from '@/components/layout/PublicLayout';
import SecurityVisualization from '@/components/shared/SecurityVisualization';

const Index: React.FC = () => {
  console.log("[Index] Rendering landing page");
  const features = [
    {
      icon: Lock,
      title: 'No Server-Side Master Keys',
      description: 'Zero-knowledge architecture. Your encryption keys never touch our servers. Only you hold the master key.',
    },
    {
      icon: Fingerprint,
      title: 'Advanced MFA Protocol',
      description: 'Mandatory Multi-Factor Authentication via QR and Mobile OTP for all administrative and high-risk operations.',
    },
    {
      icon: History,
      title: 'Audit-Friendly Tracking',
      description: 'Real-time, immutable activity logs capturing every view, download, and share attempt with full IP context.',
    },
    {
      icon: ShieldAlert,
      title: 'Military-Grade Tunneling',
      description: 'End-to-end encrypted tunnels (AES-256-GCM) established for every file share with automatic expiration.',
    },
    {
      icon: Users,
      title: 'Role-Based Access Control',
      description: 'Tiered permissions system ensuring that only verified personnel can access or share sensitive payloads.',
    },
    {
      icon: Vault,
      title: 'Immutable Storage',
      description: 'Secure secondary storage in Firebase Firestore with SHA-256 integrity verification for every asset.',
    },
  ];

  const benefits = [
    'Zero-Knowledge Architecture',
    'Mandatory Admin MFA (QR/SMS)',
    'Full Audit Activity Logs',
    'AES-256-GCM Encryption',
    'Automated Link Expiry',
    'Instant Access Revocation',
  ];

  return (
    <PublicLayout>
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-blue-50 text-slate-900 dark:bg-slate-950 dark:text-white">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,hsl(var(--primary)/0.1),transparent_50%)]" />

        <div className="container relative pt-20 pb-24 md:pt-32 md:pb-40">
          <div className="max-w-4xl mx-auto text-center animate-in fade-in slide-in-from-bottom-8 duration-1000">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-indigo-500/10 border border-indigo-500/20 mb-8 backdrop-blur-sm">
              <ShieldAlert className="h-4 w-4 text-indigo-400" />
              <span className="text-xs font-black uppercase tracking-widest text-indigo-300">Defense-Grade File Security</span>
            </div>

            <h1 className="text-5xl md:text-7xl font-black mb-8 leading-[1.1] tracking-tighter">
              Secure Your Assets with
              <span className="block bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-800 bg-clip-text text-transparent italic">Zero-Knowledge Defense</span>
            </h1>

            <p className="text-lg md:text-xl text-slate-600 mb-10 max-w-2xl mx-auto font-medium">
              Threatvault establishes immutable, end-to-end encrypted tunnels for mission-critical payloads. No master keys, no backdoors, total transparency.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
              <Button asChild className="h-16 px-10 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-lg shadow-2xl shadow-indigo-500/20 group">
                <Link to="/signup" className="flex items-center gap-2">
                  Establish Secure Profile
                  <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
                </Link>
              </Button>
              <Button asChild variant="outline" className="h-16 px-10 rounded-2xl border-slate-200 text-slate-600 hover:bg-slate-100 dark:border-white/10 dark:text-white dark:hover:bg-white/5 font-bold text-lg">
                <Link to="/features">Review Protocols</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 md:py-32 bg-white">
        <div className="container">
          <div className="text-center mb-16 md:mb-24">
            <h2 className="text-4xl md:text-5xl font-black text-slate-900 mb-6 tracking-tight">
              Mission-Critical Security
            </h2>
            <p className="text-lg text-slate-500 max-w-2xl mx-auto font-medium">
              Engineered for organizations that prioritize zero-trust architecture and absolute data sovereignty.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className="group p-8 rounded-[2.5rem] bg-slate-50 border border-slate-100 hover:border-indigo-500/30 hover:shadow-2xl hover:shadow-indigo-500/5 transition-all duration-500"
              >
                <div className="h-14 w-14 rounded-2xl bg-white shadow-lg flex items-center justify-center mb-6 group-hover:scale-110 group-hover:bg-indigo-600 transition-all duration-500">
                  <feature.icon className="h-7 w-7 text-indigo-600 group-hover:text-white transition-colors" />
                </div>
                <h3 className="text-xl font-black text-slate-900 mb-3">{feature.title}</h3>
                <p className="text-slate-500 leading-relaxed font-medium">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-24 md:py-32 bg-slate-50 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-slate-900/5 -skew-x-12 translate-x-1/2" />
        <div className="container relative">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-8">
              <h2 className="text-4xl md:text-5xl font-black text-slate-900 leading-tight">
                Architected for Total <br className="hidden md:block" />
                <span className="text-indigo-600">Privacy Sovereignty</span>
              </h2>
              <p className="text-lg text-slate-500 font-medium">
                Traditional platforms hold the keys to your kingdom. Threatvault hands them back. Our zero-knowledge protocol ensures only you can decrypt what you share.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {benefits.map((benefit, index) => (
                  <div key={index} className="flex items-center gap-3 p-4 bg-white rounded-2xl border border-slate-100 shadow-sm">
                    <CheckCircle className="h-5 w-5 text-indigo-600 flex-shrink-0" />
                    <span className="text-slate-700 font-bold text-sm tracking-tight">{benefit}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="relative">
              <div className="aspect-square rounded-[3rem] bg-slate-900 p-12 flex items-center justify-center overflow-hidden shadow-2xl">
                <SecurityVisualization />
              </div>
              <div className="absolute -bottom-8 -left-8 p-6 rounded-[2rem] bg-white border border-slate-100 shadow-2xl animate-in zoom-in duration-700">
                <div className="flex items-center gap-3 mb-2">
                  <Activity className="h-5 w-5 text-indigo-600" />
                  <p className="text-sm font-black text-slate-900 uppercase tracking-widest">Live Monitoring</p>
                </div>
                <p className="text-3xl font-black text-indigo-600 font-mono">100%</p>
                <p className="text-xs text-slate-400 font-bold font-mono">Uptime Encryption SLA</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 md:py-32 relative">
        <div className="container relative overflow-hidden rounded-[3rem] bg-indigo-600 px-8 py-16 md:p-24 text-center">
          <div className="absolute top-0 right-0 h-64 w-64 bg-white/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
          <div className="absolute bottom-0 left-0 h-64 w-64 bg-indigo-400/20 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2" />

          <h2 className="text-4xl md:text-5xl font-black text-white mb-6">
            Ready to Secure Your Future?
          </h2>
          <p className="text-lg text-indigo-100 mb-10 max-w-2xl mx-auto font-medium">
            Start protecting your sensitive documents and establishing cryptographically secure tunnels today.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
            <Button asChild className="h-16 px-10 rounded-2xl bg-white text-indigo-600 hover:bg-indigo-50 font-bold text-lg shadow-xl shadow-indigo-900/20">
              <Link to="/signup" className="flex items-center gap-2">
                Launch Secure Vault
                <ArrowRight className="h-5 w-5" />
              </Link>
            </Button>
            <Button asChild variant="ghost" className="h-16 px-10 rounded-2xl text-white hover:bg-white/10 font-bold text-lg">
              <Link to="/documentation">View Protocols</Link>
            </Button>
          </div>
        </div>
      </section>
    </PublicLayout>
  );
};

export default Index;
