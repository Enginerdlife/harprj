import React from 'react';
import { Link } from 'react-router-dom';
import {
    Shield,
    Upload,
    FileText,
    Clock,
    ArrowRight,
    Users,
    Activity
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import DashboardLayout from '@/components/layout/DashboardLayout';
import { useAuth } from '@/contexts/AuthContext';
import { useFiles } from '@/contexts/FileContext';

const Home: React.FC = () => {
    const { user } = useAuth();
    const { files } = useFiles();

    return (
        <DashboardLayout>
            <div className="space-y-8 animate-in fade-in duration-500">
                {/* Hero / Welcome */}
                <div className="relative overflow-hidden rounded-[2.5rem] bg-indigo-600 p-8 md:p-12 text-white shadow-2xl shadow-indigo-200">
                    <div className="absolute top-0 right-0 p-8 opacity-10">
                        <Shield className="h-48 w-48" />
                    </div>
                    <div className="relative z-10 max-w-2xl">
                        <h1 className="text-4xl md:text-5xl font-black mb-4 tracking-tight">
                            Welcome back, <br />
                            <span className="text-indigo-200">{user?.name}</span>
                        </h1>
                        <p className="text-indigo-100 text-lg font-medium mb-8">
                            Your secure vault is active and monitored. You have {files.length} protected documents currently stored in our zero-knowledge infrastructure.
                        </p>
                        <div className="flex flex-wrap gap-4">
                            <Button asChild className="bg-white text-indigo-600 hover:bg-indigo-50 font-bold px-8 h-12 rounded-xl">
                                <Link to="/upload">
                                    <Upload className="h-4 w-4 mr-2" />
                                    Upload New Payload
                                </Link>
                            </Button>
                            <Button asChild variant="ghost" className="text-white hover:bg-white/10 font-bold px-8 h-12 rounded-xl border border-white/20">
                                <Link to="/my-files">Browse Vault</Link>
                            </Button>
                        </div>
                    </div>
                </div>

                {/* Quick Stats Summary */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <Card className="border-none shadow-xl rounded-[2rem] bg-white">
                        <CardHeader className="pb-2">
                            <CardTitle className="text-sm font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                                <Activity className="h-4 w-4 text-indigo-500" />
                                System Health
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-3xl font-black text-slate-900 leading-none">100%</p>
                            <p className="text-xs text-emerald-500 font-bold mt-2">All protocols operational</p>
                        </CardContent>
                    </Card>
                    <Card className="border-none shadow-xl rounded-[2rem] bg-white">
                        <CardHeader className="pb-2">
                            <CardTitle className="text-sm font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                                <FileText className="h-4 w-4 text-indigo-500" />
                                Secure Files
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-3xl font-black text-slate-900 leading-none">{files.length}</p>
                            <p className="text-xs text-slate-400 font-bold mt-2">Encrypted with AES-256</p>
                        </CardContent>
                    </Card>
                    <Card className="border-none shadow-xl rounded-[2rem] bg-white">
                        <CardHeader className="pb-2">
                            <CardTitle className="text-sm font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                                <Users className="h-4 w-4 text-indigo-500" />
                                Trust Level
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-3xl font-black text-slate-900 leading-none">High</p>
                            <p className="text-xs text-indigo-500 font-bold mt-2">Zero-knowledge active</p>
                        </CardContent>
                    </Card>
                </div>

                {/* Main Content Areas */}
                <div className="grid lg:grid-cols-2 gap-8">
                    {/* Recent Files */}
                    <Card className="border-none shadow-xl rounded-[2.5rem] bg-white overflow-hidden">
                        <CardHeader className="px-8 pt-8">
                            <div className="flex items-center justify-between">
                                <CardTitle className="flex items-center gap-2 text-2xl font-black">
                                    <Clock className="h-6 w-6 text-indigo-600" />
                                    Recent Activity
                                </CardTitle>
                                <Button asChild variant="ghost" size="sm" className="font-bold text-indigo-600">
                                    <Link to="/activity-logs">View All</Link>
                                </Button>
                            </div>
                        </CardHeader>
                        <CardContent className="p-8 pt-4">
                            <div className="space-y-4">
                                {files.slice(0, 4).length > 0 ? (
                                    files.slice(0, 4).map((f, i) => (
                                        <div key={i} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl group hover:bg-indigo-50 transition-colors">
                                            <div className="flex items-center gap-4">
                                                <div className="h-10 w-10 bg-white rounded-xl flex items-center justify-center shadow-sm">
                                                    <FileText className="h-5 w-5 text-indigo-600" />
                                                </div>
                                                <div>
                                                    <p className="text-sm font-black text-slate-900 group-hover:text-indigo-900">{f.name}</p>
                                                    <p className="text-[10px] text-slate-400 font-bold uppercase">{new Date(f.createdAt).toLocaleDateString()}</p>
                                                </div>
                                            </div>
                                            <Button size="icon" variant="ghost" className="rounded-full">
                                                <ArrowRight className="h-4 w-4" />
                                            </Button>
                                        </div>
                                    ))
                                ) : (
                                    <div className="py-12 text-center">
                                        <p className="text-slate-400 font-medium">No recent documents found.</p>
                                    </div>
                                )}
                            </div>
                        </CardContent>
                    </Card>

                    {/* Quick Launch */}
                    <Card className="border-none shadow-xl rounded-[2.5rem] bg-indigo-900 text-white overflow-hidden">
                        <CardHeader className="px-8 pt-8">
                            <CardTitle className="text-2xl font-black">Quick Toolbox</CardTitle>
                            <CardDescription className="text-indigo-300">Fast access to vault operations</CardDescription>
                        </CardHeader>
                        <CardContent className="p-8 pt-4 grid grid-cols-2 gap-4">
                            <Button asChild className="h-24 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/10 flex flex-col gap-2">
                                <Link to="/upload">
                                    <Upload className="h-6 w-6" />
                                    <span className="font-bold text-xs uppercase tracking-widest">Share File</span>
                                </Link>
                            </Button>
                            <Button asChild className="h-24 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/10 flex flex-col gap-2">
                                <Link to="/my-files">
                                    <FileText className="h-6 w-6" />
                                    <span className="font-bold text-xs uppercase tracking-widest">Manage</span>
                                </Link>
                            </Button>
                            <Button asChild className="h-24 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/10 flex flex-col gap-2">
                                <Link to="/security">
                                    <Shield className="h-6 w-6" />
                                    <span className="font-bold text-xs uppercase tracking-widest">Security</span>
                                </Link>
                            </Button>
                            <Button asChild className="h-24 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/10 flex flex-col gap-2">
                                <Link to="/profile">
                                    <Activity className="h-6 w-6" />
                                    <span className="font-bold text-xs uppercase tracking-widest">Profile</span>
                                </Link>
                            </Button>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </DashboardLayout>
    );
};

export default Home;
