import React from 'react';
import { Link } from 'react-router-dom';
import {
  FileText,
  Share2,
  Download,
  Lock,
  Upload,
  Shield,
  Activity,
  ArrowRight,
  FolderOpen
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import DashboardLayout from '@/components/layout/DashboardLayout';
import StatsCard from '@/components/shared/StatsCard';
import { useFiles } from '@/contexts/FileContext';

const Overview: React.FC = () => {
  const { files } = useFiles();

  const stats = [
    {
      title: 'Total Encrypted Files',
      value: files.length.toString(),
      description: 'Files secured with AES-256',
      icon: Lock,
      variant: 'primary' as const,
    },
    {
      title: 'Files Shared',
      value: '0',
      description: 'Active share links',
      icon: Share2,
      variant: 'success' as const,
    },
    {
      title: 'Files Received',
      value: '0',
      description: 'From other users',
      icon: Download,
      variant: 'warning' as const,
    },
    {
      title: 'My Files',
      value: files.length.toString(),
      description: 'In your vault',
      icon: FolderOpen,
      variant: 'default' as const,
    },
  ];



  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-foreground">Overview</h1>
          <p className="text-muted-foreground mt-1">
            Your secure file sharing statistics and quick actions
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((stat, index) => (
            <StatsCard
              key={index}
              title={stat.title}
              value={stat.value}
              description={stat.description}
              icon={stat.icon}
              variant={stat.variant}
            />
          ))}
        </div>

        {/* System Health */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5 text-primary" />
              System Health
            </CardTitle>
            <CardDescription>
              Real-time monitoring of system performance
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">System Uptime</span>
                  <span className="text-success font-medium">99.99%</span>
                </div>
                <div className="h-2 bg-secondary rounded-full overflow-hidden">
                  <div className="h-full bg-success w-[99.9%]" />
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">API Status</span>
                  <span className="text-success font-medium">Operational</span>
                </div>
                <div className="h-2 bg-secondary rounded-full overflow-hidden">
                  <div className="h-full bg-success w-full" />
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Last Backup</span>
                  <span className="text-foreground font-medium">15 min ago</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <div className="h-1.5 w-1.5 rounded-full bg-success" />
                  Encrypted & Secure
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* File Activity Summary */}
        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="h-5 w-5 text-primary" />
                Encryption Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Total Storage Used</span>
                  <span className="font-medium text-foreground">
                    {(files.reduce((total, f) => total + f.size, 0) / (1024 * 1024 * 1024)).toFixed(2)} GB
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Encrypted Files</span>
                  <span className="font-medium text-success">{files.length} {files.length === 1 ? 'file' : 'files'}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Encryption Standard</span>
                  <span className="font-medium text-foreground">AES-256-GCM</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Last Upload</span>
                  <span className="font-medium text-foreground">Never</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Share2 className="h-5 w-5 text-primary" />
                Sharing Activity
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Active Shares</span>
                  <span className="font-medium text-foreground">0 links</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Expiring Soon</span>
                  <span className="font-medium text-warning">0 links</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Total Downloads</span>
                  <span className="font-medium text-foreground">0</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Files Received</span>
                  <span className="font-medium text-foreground">0 files</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default Overview;
