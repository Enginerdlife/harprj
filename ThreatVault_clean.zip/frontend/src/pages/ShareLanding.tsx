import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
    Lock,
    FileText,
    Download,
    AlertTriangle,
    Loader2,
    ShieldCheck,
    ShieldAlert,
    Fingerprint
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import {
    deriveKeyFromPassword,
    decryptFile,
    base64ToArrayBuffer,
    base64ToUint8Array
} from '@/lib/encryption';
import { sharesAPI } from '@/lib/api';
import { toast } from 'sonner';
import { EncryptedFile } from '@/contexts/FileContext';

const ShareLanding: React.FC = () => {
    const { shareId } = useParams<{ shareId: string }>();
    const [status, setStatus] = useState<'loading' | 'valid' | 'invalid' | 'expired' | 'revoked'>('loading');
    const [file, setFile] = useState<EncryptedFile | null>(null);
    const [password, setPassword] = useState('');
    const [isUnlocking, setIsUnlocking] = useState(false);
    const [decryptedUrl, setDecryptedUrl] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchShare = async () => {
            if (!shareId) return;

            try {
                const response = await sharesAPI.getShareDetails(shareId);
                const share = response.data.data;

                if (!share) {
                    setStatus('invalid');
                    return;
                }

                if (share.status === 'revoked') {
                    setStatus('revoked');
                    return;
                }

                // Handle both CamelCase and snake_case from API
                const expiresAt = share.expires_at || share.expiresAt;
                if (expiresAt && new Date(expiresAt) < new Date()) {
                    setStatus('expired');
                    return;
                }

                if (!share.file) {
                    setStatus('invalid');
                    return;
                }

                setFile(share.file);
                setStatus('valid');

            } catch (err: any) {
                console.error("Failed to fetch share:", err);
                if (err.response?.status === 410) {
                    setStatus('expired');
                } else if (err.response?.status === 404) {
                    setStatus('invalid');
                } else {
                    setStatus('invalid');
                }
            }
        };

        fetchShare();
    }, [shareId]);

    const handleUnlock = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!file || !password || !shareId) return;

        setIsUnlocking(true);
        setError(null);

        try {
            if (!file.salt || !file.iv) {
                throw new Error('This shared file is missing cryptographic metadata.');
            }

            // 1. Derive key from password
            const salt = base64ToUint8Array(file.salt);
            const key = await deriveKeyFromPassword(password, salt);

            // 2. Fetch the actual encrypted data
            const response = await sharesAPI.downloadSharedFile(shareId);
            const payload = response.data.data;

            if (!payload || !payload.encryptedData) {
                throw new Error('Secure payload transition failed. Please try again.');
            }

            // 3. Decrypt
            const encryptedData = base64ToArrayBuffer(payload.encryptedData);
            const iv = base64ToUint8Array(payload.iv || file.iv);

            const decryptedData = await decryptFile(encryptedData, key, iv);

            // 4. Success
            const blob = new Blob([decryptedData], { type: file.type });
            const url = URL.createObjectURL(blob);
            setDecryptedUrl(url);
            toast.success('Decryption successful. Secure tunnel established.');

        } catch (err: any) {
            console.error('[ShareLanding] Unlock failed:', err);
            setError('Access Denied: Incorrect password or corrupted payload.');
            toast.error('Authentication failed');
        } finally {
            setIsUnlocking(false);
        }
    };

    if (status === 'loading') {
        return (
            <div className="min-h-screen flex flex-col items-center justify-center bg-slate-50 gap-4">
                <div className="relative">
                    <Loader2 className="h-12 w-12 animate-spin text-indigo-600" />
                    <div className="absolute inset-0 h-12 w-12 rounded-full border-4 border-indigo-100/50" />
                </div>
                <p className="text-slate-500 font-medium animate-pulse">Authenticating secure link...</p>
            </div>
        );
    }

    if (status === 'invalid' || status === 'expired' || status === 'revoked') {
        return (
            <div className="min-h-screen flex items-center justify-center bg-slate-50 p-6">
                <Card className="w-full max-w-md border-none shadow-2xl rounded-3xl overflow-hidden animate-in zoom-in-95">
                    <div className="bg-rose-600 p-8 flex justify-center">
                        <div className="bg-white/20 p-4 rounded-full backdrop-blur-md">
                            <ShieldAlert className="h-12 w-12 text-white" />
                        </div>
                    </div>
                    <CardHeader className="text-center pt-8">
                        <CardTitle className="text-2xl font-black text-slate-900">Access Restricted</CardTitle>
                        <CardDescription className="text-slate-500 text-lg mt-2">
                            {status === 'invalid' && 'This link is no longer valid or has been purged.'}
                            {status === 'expired' && 'The security certificate for this link has expired.'}
                            {status === 'revoked' && 'Access has been manually revoked by the sender.'}
                        </CardDescription>
                    </CardHeader>
                    <CardFooter className="pb-8 justify-center">
                        <Button asChild variant="outline" className="rounded-xl px-8 h-12 border-slate-200 text-slate-600 hover:bg-slate-50">
                            <Link to="/">Exit Secure Zone</Link>
                        </Button>
                    </CardFooter>
                </Card>
            </div>
        );
    }

    return (
        <div className="min-h-screen flex items-center justify-center bg-slate-50 p-6 selection:bg-indigo-100">
            <Card className="w-full max-w-2xl border-none shadow-2xl rounded-[2.5rem] overflow-hidden bg-white animate-in fade-in slide-in-from-bottom-8 duration-700">
                <div className="bg-slate-900 px-10 py-8 relative">
                    <div className="absolute top-0 right-0 p-8 opacity-10">
                        <ShieldCheck className="h-32 w-32 text-indigo-400" />
                    </div>

                    <div className="relative z-10 flex flex-col gap-4">
                        <div className="flex items-center gap-3">
                            <div className="bg-indigo-500/20 p-2.5 rounded-2xl backdrop-blur-sm border border-white/5">
                                <Fingerprint className="h-6 w-6 text-indigo-400" />
                            </div>
                            <span className="text-indigo-300 font-bold uppercase tracking-[0.2em] text-xs">End-to-End Encrypted</span>
                        </div>
                        <h1 className="text-3xl font-black text-white pr-20 leading-tight">
                            {decryptedUrl ? file?.name : 'Secure Document Transfer'}
                        </h1>
                    </div>
                </div>

                <CardContent className="p-10">
                    {!decryptedUrl ? (
                        <div className="space-y-8">
                            <div className="space-y-2">
                                <h2 className="text-xl font-bold text-slate-900">Unlock Requested Payload</h2>
                                <p className="text-slate-500 leading-relaxed">
                                    The sender has protected this document with AES-256-GCM encryption.
                                    Please enter the unique shared password to begin decryption.
                                </p>
                            </div>

                            <form onSubmit={handleUnlock} className="space-y-6">
                                <div className="space-y-3">
                                    <Input
                                        type="password"
                                        placeholder="••••••••••••"
                                        value={password}
                                        onChange={(e) => setPassword(e.target.value)}
                                        disabled={isUnlocking}
                                        className={`h-14 rounded-2xl bg-slate-50 border-slate-200 px-6 text-lg focus:ring-indigo-500 transition-all ${error ? 'border-rose-500 shadow-sm shadow-rose-50' : ''}`}
                                        autoFocus
                                    />
                                    {error && (
                                        <div className="bg-rose-50 text-rose-600 p-4 rounded-2xl border border-rose-100 flex items-center gap-3 animate-in slide-in-from-top-2">
                                            <AlertTriangle className="h-5 w-5 shrink-0" />
                                            <p className="font-semibold text-sm">{error}</p>
                                        </div>
                                    )}
                                </div>
                                <Button
                                    type="submit"
                                    className="w-full h-14 rounded-2xl text-lg font-bold shadow-xl shadow-indigo-100 bg-indigo-600 hover:bg-indigo-700 transition-all hover:scale-[1.01]"
                                    disabled={isUnlocking || !password}
                                >
                                    {isUnlocking ? (
                                        <div className="flex items-center gap-3">
                                            <Loader2 className="h-5 w-5 animate-spin" />
                                            Performing Bit-Shifting...
                                        </div>
                                    ) : (
                                        <div className="flex items-center gap-2">
                                            <Lock className="h-5 w-5" />
                                            Unlock & Authenticate
                                        </div>
                                    )}
                                </Button>
                            </form>
                        </div>
                    ) : (
                        <div className="space-y-8 animate-in fade-in zoom-in-95 duration-500">
                            <div className="bg-slate-50 rounded-[2rem] border border-slate-200 overflow-hidden shadow-inner p-4 min-h-[300px] flex items-center justify-center">
                                {file?.type.startsWith('image/') ? (
                                    <img
                                        src={decryptedUrl}
                                        alt={file.name}
                                        className="max-h-[400px] object-contain rounded-xl shadow-2xl animate-in zoom-in-95 duration-500"
                                    />
                                ) : file?.type === 'application/pdf' ? (
                                    <iframe src={decryptedUrl} className="w-full h-[500px] rounded-xl border-none shadow-sm" title="PDF Preview" />
                                ) : (
                                    <div className="py-16 flex flex-col items-center text-center gap-6">
                                        <div className="h-24 w-24 bg-white shadow-lg border border-slate-100 rounded-[2rem] flex items-center justify-center">
                                            <FileText className="h-10 w-10 text-indigo-500" />
                                        </div>
                                        <div className="space-y-2">
                                            <p className="font-black text-2xl text-slate-900">{file?.name}</p>
                                            <p className="text-slate-500 font-medium uppercase tracking-widest text-xs px-3 py-1 bg-slate-100 rounded-full inline-block">
                                                {file?.type?.split('/')[1] || 'Document'}
                                            </p>
                                        </div>
                                    </div>
                                )}
                            </div>

                            <div className="flex flex-col sm:flex-row gap-4">
                                <Button asChild className="h-14 rounded-2xl flex-1 text-lg font-bold bg-indigo-600 hover:bg-indigo-700 shadow-xl shadow-indigo-100 group">
                                    <a href={decryptedUrl} download={file?.name}>
                                        <Download className="h-5 w-5 mr-3 transition-transform group-hover:translate-y-0.5" />
                                        Save Securely
                                    </a>
                                </Button>
                                <Button asChild variant="outline" className="h-14 px-8 rounded-2xl border-slate-200 text-slate-600 hover:bg-slate-50 font-bold">
                                    <Link to="/">Dashboard</Link>
                                </Button>
                            </div>
                        </div>
                    )}
                </CardContent>

                <CardFooter className="px-10 pb-10 flex justify-center border-t border-slate-50 pt-8 mt-2">
                    <div className="flex items-center gap-2 text-slate-400 text-sm font-medium">
                        <ShieldCheck className="h-4 w-4 text-emerald-500" />
                        Verified Secure Transfer by Threatvault
                    </div>
                </CardFooter>
            </Card>
        </div>
    );
};

export default ShareLanding;
