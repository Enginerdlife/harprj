import React, { useState } from 'react';
import {
  ExternalLink,
  Clock,
  Trash2,
  Copy,
  Check,
  Eye,
  Plus,
  QrCode,
  Share2,
  History,
  Shield,
  Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription
} from '@/components/ui/dialog';
import DashboardLayout from '@/components/layout/DashboardLayout';
import ShareModal from '@/components/shared/ShareModal';
import FileSelectionModal from '@/components/shared/FileSelectionModal';
import { cn, getPublicAppUrl } from '@/lib/utils';
import { toast } from 'sonner';
import { useFiles, EncryptedFile } from '@/contexts/FileContext';
import { useNavigate } from 'react-router-dom';
import { authAPI, logsAPI } from '@/lib/api';
import { useEffect } from 'react';

const MyShares: React.FC = () => {
  const navigate = useNavigate();
  const { shares, revokeShare, createShare } = useFiles();
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Modal States
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [isFileSelectorOpen, setIsFileSelectorOpen] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<EncryptedFile[]>([]);
  const [isQRModalOpen, setIsQRModalOpen] = useState(false);
  const [qrLoading, setQrLoading] = useState(false);
  const [qrCodeData, setQrCodeData] = useState<{ qrCode: string; code: string; expiresAt: string } | null>(null);
  const [transactionLogs, setTransactionLogs] = useState<any[]>([]);
  const [logsLoading, setLogsLoading] = useState(true);

  // Fetch share transaction logs
  useEffect(() => {
    const fetchLogs = async () => {
      try {
        const response = await logsAPI.getAllLogs();
        const allLogs = response.data.data || [];
        // Filter for FILE_SHARED actions
        const shareLogs = allLogs.filter((log: any) => log.action === 'FILE_SHARED');
        setTransactionLogs(shareLogs);
      } catch (error) {
        console.error('Failed to fetch transaction logs:', error);
      } finally {
        setLogsLoading(false);
      }
    };
    fetchLogs();
  }, []);

  const handleCopyLink = async (id: string, e: React.MouseEvent) => {
    e.preventDefault();
    await navigator.clipboard.writeText(`${window.location.origin}/share/${id}`);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
    toast.success('Share link copied to clipboard.');
  };

  const handleRevoke = (id: string, fileName: string) => {
    revokeShare(id);
    toast.success(`Access to ${fileName} has been revoked.`);
  };

  const handleGenerateQR = async () => {
    setQrLoading(true);
    setIsQRModalOpen(true);
    try {
      const response = await authAPI.getQRCode();
      setQrCodeData(response.data.data);
    } catch (error) {
      toast.error('Failed to generate secure QR.');
      setIsQRModalOpen(false);
    } finally {
      setQrLoading(false);
    }
  };

  const scrollToHistory = () => {
    const element = document.getElementById('share-history');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-emerald-500/10 text-emerald-600 border-emerald-500/20">Active</Badge>;
      case 'expired':
        return <Badge variant="secondary">Expired</Badge>;
      case 'revoked':
        return <Badge variant="destructive" className="bg-rose-500/10 text-rose-600 border-rose-500/20">Revoked</Badge>;
      default:
        return null;
    }
  };

  const activeShares = shares.filter((s: any) => s.status === 'active');
  const inactiveShares = shares.filter((s: any) => s.status !== 'active');

  return (
    <DashboardLayout>
      <div className="space-y-8 max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <h1 className="text-4xl font-black text-slate-900 tracking-tight">Shared Assets</h1>
            <p className="text-slate-500 mt-1 font-medium">
              Monitor and control secure access tunnels to your encrypted files.
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-slate-400">
            <Shield className="h-4 w-4 text-indigo-500" />
            Zero-Knowledge Sharing Protocol
          </div>
        </div>

        {/* ACTION TOOLBAR - MANDATED BUTTONS */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 p-2 bg-slate-100 rounded-[2rem] border border-slate-200 shadow-inner">
          <Button
            className="h-16 rounded-[1.5rem] bg-indigo-600 hover:bg-indigo-700 shadow-lg shadow-indigo-100 flex gap-3 font-bold text-base"
            onClick={() => navigate('/upload')}
          >
            <Plus className="h-5 w-5" />
            Upload Encrypted File
          </Button>

          <Button
            variant="secondary"
            className="h-16 rounded-[1.5rem] bg-white hover:bg-slate-50 text-slate-900 border-none shadow-md flex gap-3 font-bold text-base"
            onClick={handleGenerateQR}
          >
            <QrCode className="h-5 w-5 text-indigo-600" />
            Generate Share QR
          </Button>

          <Button
            variant="secondary"
            className="h-16 rounded-[1.5rem] bg-white hover:bg-slate-50 text-slate-900 border-none shadow-md flex gap-3 font-bold text-base"
            onClick={() => setIsFileSelectorOpen(true)}
          >
            <Share2 className="h-5 w-5 text-indigo-600" />
            Select a file to share
          </Button>

          <Button
            variant="secondary"
            className="h-16 rounded-[1.5rem] bg-white hover:bg-slate-50 text-slate-900 border-none shadow-md flex gap-3 font-bold text-base"
            onClick={scrollToHistory}
          >
            <History className="h-5 w-5 text-indigo-600" />
            View Shared History
          </Button>
        </div>

        {/* Active Shares */}
        <div className="space-y-6">
          <div className="flex items-center gap-3">
            <h2 className="text-2xl font-black text-slate-900">
              Active Shares
            </h2>
            <Badge className="bg-indigo-600 text-white border-none rounded-full px-3">{activeShares.length}</Badge>
          </div>

          {activeShares.length === 0 ? (
            <Card className="border-dashed border-2 bg-slate-50/50 rounded-[2rem]">
              <CardContent className="py-20 text-center space-y-4">
                <div className="h-16 w-16 bg-slate-100 rounded-3xl flex items-center justify-center mx-auto">
                  <ExternalLink className="h-8 w-8 text-slate-300" />
                </div>
                <div className="space-y-1">
                  <p className="text-xl font-bold text-slate-900">No active secure links</p>
                  <p className="text-slate-500 text-sm">Use the toolbar above to share files securely.</p>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {activeShares.map((share: any) => (
                <Card key={share.id} className="group border-none shadow-lg hover:shadow-xl transition-all rounded-[2rem] overflow-hidden bg-white">
                  <CardContent className="p-6 space-y-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="space-y-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <h3 className="font-black text-lg text-slate-900 truncate">
                            {share.fileName}
                          </h3>
                          {getStatusBadge(share.status)}
                        </div>
                        <p className="text-sm text-slate-500 font-medium truncate italic">{share.recipient}</p>
                      </div>
                      <div className="h-10 w-10 bg-indigo-50 rounded-xl flex items-center justify-center text-indigo-600 shrink-0">
                        <Shield className="h-5 w-5" />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 py-2 border-y border-slate-50">
                      <div className="space-y-0.5">
                        <p className="text-[10px] uppercase font-black text-slate-400 tracking-widest">Access Count</p>
                        <p className="text-lg font-bold text-slate-900">{share.accessCount}</p>
                      </div>
                      <div className="space-y-0.5">
                        <p className="text-[10px] uppercase font-black text-slate-400 tracking-widest">Expiry Date</p>
                        <p className="text-lg font-bold text-emerald-600">{new Date(share.expiresAt).toLocaleDateString()}</p>
                      </div>
                    </div>

                    <div className="flex gap-2 pt-2">
                      <Button
                        variant="ghost"
                        className="flex-1 h-12 rounded-xl bg-slate-50 hover:bg-indigo-50 text-slate-600 hover:text-indigo-600 font-bold"
                        onClick={() => window.open(`/share/${share.id}`, '_blank')}
                      >
                        <Eye className="h-4 w-4 mr-2" />
                        Preview
                      </Button>
                      <Button
                        variant="ghost"
                        className="flex-1 h-12 rounded-xl bg-slate-50 hover:bg-indigo-50 text-slate-600 hover:text-indigo-600 font-bold"
                        onClick={(e) => handleCopyLink(share.id, e)}
                      >
                        {copiedId === share.id ? (
                          <Check className="h-4 w-4 mr-2" />
                        ) : (
                          <Copy className="h-4 w-4 mr-2" />
                        )}
                        Copy
                      </Button>
                      <Button
                        variant="ghost"
                        className="h-12 w-12 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 shrink-0"
                        onClick={() => handleRevoke(share.id, share.fileName)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>

        {/* Transaction History - Detailed Audit Logs */}
        <div id="share-history" className="space-y-6 pt-8 border-t border-slate-100">
          <div className="flex items-center gap-3">
            <h2 className="text-2xl font-black text-slate-900">
              Share Transaction History
            </h2>
            <Badge variant="outline" className="border-indigo-200 text-indigo-600 rounded-full px-3 bg-indigo-50">{transactionLogs.length}</Badge>
          </div>

          {logsLoading ? (
            <div className="py-12 text-center">
              <Loader2 className="h-8 w-8 animate-spin text-indigo-600 mx-auto" />
              <p className="text-slate-500 mt-2 font-medium">Loading transaction history...</p>
            </div>
          ) : transactionLogs.length === 0 ? (
            <div className="py-8 text-center bg-slate-50/50 rounded-3xl border border-dashed border-slate-200">
              <p className="text-slate-400 font-medium">No share transactions recorded yet.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {transactionLogs.map((log: any) => (
                <div key={log.id} className="p-5 bg-white border border-slate-100 rounded-2xl hover:shadow-md transition-all">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 min-w-0 space-y-2">
                      <div className="flex items-center gap-2">
                        <div className="h-8 w-8 bg-indigo-50 rounded-lg flex items-center justify-center shrink-0">
                          <Share2 className="h-4 w-4 text-indigo-600" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="font-bold text-slate-900 truncate">
                            {log.file_name || 'Unknown File'}
                          </h3>
                          <p className="text-xs text-slate-500">
                            Shared to: <span className="font-semibold text-indigo-600">{log.recipient_email}</span>
                          </p>
                        </div>
                      </div>

                      <div className="bg-slate-50 rounded-xl p-3 grid grid-cols-2 gap-3">
                        <div>
                          <p className="text-[10px] uppercase font-black text-slate-400 tracking-widest mb-0.5">Date Sent</p>
                          <p className="text-sm font-bold text-slate-700">
                            {new Date(log.timestamp).toLocaleString()}
                          </p>
                        </div>
                        <div>
                          <p className="text-[10px] uppercase font-black text-slate-400 tracking-widest mb-0.5">Details</p>
                          <p className="text-sm font-medium text-slate-600 truncate">
                            {log.details || 'File shared successfully'}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 text-xs text-slate-400">
                        <Clock className="h-3 w-3" />
                        <span>Sent by {log.user_email}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Past Shares (Expired/Revoked) */}
        {inactiveShares.length > 0 && (
          <div className="space-y-6 pt-8 border-t border-slate-100">
            <div className="flex items-center gap-3">
              <h2 className="text-2xl font-black text-slate-900">
                Expired/Revoked Shares
              </h2>
              <Badge variant="outline" className="border-slate-200 text-slate-400 rounded-full px-3">{inactiveShares.length}</Badge>
            </div>
            <div className="space-y-3">
              {inactiveShares.map((share: any) => (
                <div key={share.id} className="p-4 bg-white border border-slate-100 rounded-2xl flex items-center justify-between group grayscale hover:grayscale-0 transition-all opacity-60 hover:opacity-100">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <h3 className="font-bold text-slate-700 truncate">
                        {share.fileName}
                      </h3>
                      {getStatusBadge(share.status)}
                    </div>
                    <div className="flex flex-wrap gap-4 text-xs text-slate-400 font-medium">
                      <span>Recipient: {share.recipient}</span>
                      <span>Verified: {new Date(share.createdAt).toLocaleDateString()}</span>
                      <span className="flex items-center gap-1">
                        <History className="h-3 w-3" />
                        {share.accessCount} Audited Accesses
                      </span>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-10 w-10 rounded-xl"
                    onClick={() => window.open(`/share/${share.id}`, '_blank')}
                  >
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* FILE SELECTION FLOW */}
      <FileSelectionModal
        isOpen={isFileSelectorOpen}
        onClose={() => setIsFileSelectorOpen(false)}
        onSelect={(files) => {
          setSelectedFiles(files);
          setIsFileSelectorOpen(false);
          setIsShareModalOpen(true);
        }}
      />

      <ShareModal
        isOpen={isShareModalOpen}
        onClose={() => {
          setIsShareModalOpen(false);
          setSelectedFiles([]);
        }}
        fileNames={selectedFiles.map(f => f.name)}
        onShare={async (email, expiresIn) => {
          if (selectedFiles.length === 0) throw new Error("No files selected");

          // Batch share logic
          const promises = selectedFiles.map(file => createShare(file.id, email, expiresIn));
          const results = await Promise.all(promises);

          const publicUrl = getPublicAppUrl();
          return `${publicUrl}/share/${results[0].id}`;
        }}
      />

      {/* QR MODAL INTEGRATION */}
      <Dialog open={isQRModalOpen} onOpenChange={setIsQRModalOpen}>
        <DialogContent className="sm:max-w-md rounded-[2rem] border-none shadow-2xl p-0 overflow-hidden bg-white">
          <DialogHeader className="bg-slate-900 p-8 text-center space-y-2">
            <div className="h-16 w-16 bg-indigo-500/20 rounded-3xl flex items-center justify-center mx-auto border border-white/5 backdrop-blur-sm">
              <QrCode className="h-8 w-8 text-indigo-400" />
            </div>
            <DialogTitle className="text-2xl font-black text-white">Dynamic Secure QR</DialogTitle>
            <DialogDescription className="text-slate-400 text-sm">
              Scan this time-limited code to establish a secure file access bridge.
            </DialogDescription>
          </DialogHeader>
          <div className="p-8 text-center space-y-6">
            {qrLoading ? (
              <div className="h-48 flex flex-col items-center justify-center gap-3">
                <Loader2 className="h-10 w-10 animate-spin text-indigo-600" />
                <p className="text-slate-500 font-bold uppercase tracking-widest text-xs">Generating Key...</p>
              </div>
            ) : qrCodeData ? (
              <div className="space-y-6 animate-in fade-in zoom-in-95 duration-500">
                <div className="bg-slate-50 p-6 rounded-[2.5rem] border-2 border-slate-100 inline-block shadow-inner">
                  <img src={qrCodeData.qrCode} alt="Secure Share QR" className="h-48 w-48 mix-blend-multiply" />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-center gap-2">
                    <Shield className="h-4 w-4 text-emerald-500" />
                    <span className="text-sm font-black text-slate-700 uppercase tracking-widest">Verification Link</span>
                  </div>
                  <p className="text-4xl font-black text-indigo-600 font-mono tracking-tighter">{qrCodeData.code}</p>
                </div>
                <div className="p-3 rounded-2xl bg-rose-50 border border-rose-100 inline-flex items-center gap-2">
                  <Clock className="h-4 w-4 text-rose-500" />
                  <span className="text-xs font-bold text-rose-600 uppercase">Expires: {new Date(qrCodeData.expiresAt).toLocaleTimeString()}</span>
                </div>
              </div>
            ) : null}
            <Button className="w-full h-14 rounded-2xl font-bold bg-slate-900" onClick={() => setIsQRModalOpen(false)}>
              Close Secure Tunnel
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
};

export default MyShares;
