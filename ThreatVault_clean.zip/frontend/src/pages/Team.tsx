import React from 'react';
import { Users, FileText, Share2, Activity, Mail } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import DashboardLayout from '@/components/layout/DashboardLayout';
import StatsCard from '@/components/shared/StatsCard';

const Team: React.FC = () => {
  const teamMembers = [];

  const teamStats = {
    totalFiles: teamMembers.reduce((acc, m) => acc + m.filesUploaded, 0),
    totalShares: teamMembers.reduce((acc, m) => acc + m.activeShares, 0),
    activeMembers: teamMembers.filter(m => m.lastActive.includes('hours')).length,
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Team Overview</h1>
          <p className="text-muted-foreground mt-1">
            Monitor your team's file sharing activity
          </p>
        </div>

        {/* Stats */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatsCard
            title="Team Members"
            value={teamMembers.length}
            icon={Users}
            variant="primary"
          />
          <StatsCard
            title="Total Files"
            value={teamStats.totalFiles}
            icon={FileText}
            variant="default"
          />
          <StatsCard
            title="Active Shares"
            value={teamStats.totalShares}
            icon={Share2}
            variant="success"
          />
          <StatsCard
            title="Active Today"
            value={teamStats.activeMembers}
            icon={Activity}
            variant="default"
          />
        </div>

        {/* Team Members */}
        <Card>
          <CardHeader>
            <CardTitle>Team Members</CardTitle>
            <CardDescription>Overview of your team's activity</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {teamMembers.map((member) => (
                <div
                  key={member.id}
                  className="flex flex-col md:flex-row md:items-center gap-4 p-4 rounded-lg bg-muted/50"
                >
                  <div className="flex items-center gap-4 flex-1">
                    <div className="h-12 w-12 rounded-full gradient-primary flex items-center justify-center">
                      <span className="text-lg font-bold text-primary-foreground">
                        {member.name.charAt(0)}
                      </span>
                    </div>
                    <div className="min-w-0">
                      <h3 className="font-medium text-foreground">{member.name}</h3>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Mail className="h-3 w-3" />
                        <span className="truncate">{member.email}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-4 text-sm">
                    <div className="text-center">
                      <p className="text-lg font-semibold text-foreground">{member.filesUploaded}</p>
                      <p className="text-xs text-muted-foreground">Files</p>
                    </div>
                    <div className="text-center">
                      <p className="text-lg font-semibold text-foreground">{member.activeShares}</p>
                      <p className="text-xs text-muted-foreground">Shares</p>
                    </div>
                    <div className="flex items-center">
                      <Badge variant="secondary" className="whitespace-nowrap">
                        {member.lastActive}
                      </Badge>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
};

export default Team;
