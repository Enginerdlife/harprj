import React from 'react';
import PublicLayout from '@/components/layout/PublicLayout';
import { Shield, Target, Code, Lock, Heart } from 'lucide-react';

const About: React.FC = () => {
    return (
        <PublicLayout>
            <div className="container py-24 md:py-32 max-w-5xl mx-auto">
                {/* Story Section */}
                <section className="space-y-12 mb-32">
                    <div className="text-center space-y-6">
                        <h1 className="text-5xl md:text-7xl font-black text-slate-900 tracking-tighter">The Mission Behind <br /> <span className="text-indigo-600">The Vault</span></h1>
                        <p className="text-xl text-slate-500 font-medium max-w-3xl mx-auto leading-relaxed">
                            Threatvault was born from a simple realization: in an era of constant surveillance and data breaches, organizations no longer own their data—they merely lease it from providers who hold the keys.
                        </p>
                    </div>

                    <div className="grid md:grid-cols-2 gap-10">
                        <div className="p-12 bg-white border border-slate-100 rounded-[3rem] shadow-sm hover:shadow-xl transition-all space-y-6">
                            <div className="h-14 w-14 bg-indigo-50 rounded-2xl flex items-center justify-center">
                                <Target className="h-7 w-7 text-indigo-600" />
                            </div>
                            <h2 className="text-2xl font-black text-slate-900">Our Vision</h2>
                            <p className="text-slate-500 font-medium leading-relaxed">
                                We envision a decentralized world where encryption is transparent, keys are local, and privacy is the default state of existence. Threatvault is the first step toward that reality.
                            </p>
                        </div>
                        <div className="p-12 bg-slate-900 text-white rounded-[3rem] shadow-2xl space-y-6">
                            <div className="h-14 w-14 bg-white/10 rounded-2xl flex items-center justify-center backdrop-blur-md">
                                <Shield className="h-7 w-7 text-white" />
                            </div>
                            <h2 className="text-2xl font-black">Our Values</h2>
                            <p className="text-slate-400 font-medium leading-relaxed">
                                Transparency, Integrity, and Sovereignty. We dont believe in backdoors, master keys, or "trust us" security. We believe in math and open protocols.
                            </p>
                        </div>
                    </div>
                </section>

                {/* Culture Section */}
                <section className="bg-slate-50 rounded-[4rem] p-12 md:p-24 space-y-16">
                    <div className="max-w-3xl space-y-6">
                        <h2 className="text-4xl font-black text-slate-900 tracking-tight">Rooted in Engineering Excellence</h2>
                        <p className="text-lg text-slate-500 font-medium leading-relaxed">
                            Our team consists of security researchers, cryptographers, and engineers who are passionate about building defense-grade software that's actually usable.
                        </p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                        <div className="space-y-4">
                            <Code className="h-8 w-8 text-indigo-600" />
                            <h3 className="text-xl font-black text-slate-900">Open Minded</h3>
                            <p className="text-sm text-slate-500 font-medium">We champion open protocols and peer-reviewed cryptographic standards.</p>
                        </div>
                        <div className="space-y-4">
                            <Lock className="h-8 w-8 text-indigo-600" />
                            <h3 className="text-xl font-black text-slate-900">Privacy Obsessed</h3>
                            <p className="text-sm text-slate-500 font-medium">If we can see your data, we have failed. We build to ensure we never can.</p>
                        </div>
                        <div className="space-y-4">
                            <Heart className="h-8 w-8 text-indigo-600" />
                            <h3 className="text-xl font-black text-slate-900">User Centric</h3>
                            <p className="text-sm text-slate-500 font-medium">Security shouldnt be hard to use. We obsess over making advanced tech intuitive.</p>
                        </div>
                    </div>
                </section>

                {/* Contact CTA */}
                <section className="mt-32 text-center space-y-8">
                    <h2 className="text-4xl font-black text-slate-900">Want to join the mission?</h2>
                    <div className="flex justify-center gap-4">
                        <div className="flex -space-x-4">
                            {[1, 2, 3, 4].map((i) => (
                                <div key={i} className="h-12 w-12 rounded-full border-4 border-white bg-slate-200" />
                            ))}
                        </div>
                        <div className="flex flex-col items-start justify-center">
                            <p className="text-sm font-black text-slate-900">Join 50+ Engineers</p>
                            <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Bengaluru & Remote</p>
                        </div>
                    </div>
                </section>
            </div>
        </PublicLayout>
    );
};

export default About;
