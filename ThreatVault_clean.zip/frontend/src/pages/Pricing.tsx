import React from 'react';
import PublicLayout from '@/components/layout/PublicLayout';
import { Check, Shield, Zap, Crown, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Pricing: React.FC = () => {
    const plans = [
        {
            name: 'Security Researcher',
            price: '$0',
            description: 'Ideal for students and independent researchers testing the protocol.',
            features: [
                'Up to 5GB Encrypted Storage',
                'Standard MFA (Mobile OTP)',
                'Basic Activity Logs',
                'Client-Side Encryption',
                'Community Support',
            ],
            cta: 'Start Researching',
            highlight: false,
        },
        {
            name: 'Professional Defense',
            price: '$29',
            description: 'Advanced protection for individual professionals and sensitive assets.',
            features: [
                '50GB Encrypted Storage',
                'Mandatory QR + SMS MFA',
                'Enhanced Audit Trails',
                'Custom Link Expiration',
                'Establish 50 Secure Tunnels',
                'Priority Mail Support',
            ],
            cta: 'Uparade Defense',
            highlight: true,
        },
        {
            name: 'Enterprise Command',
            price: 'Custom',
            description: 'Complete data sovereignty for large scale organizations.',
            features: [
                'Unlimited Encrypted Storage',
                'Custom SSO Integration',
                'Full RBAC Governance',
                'White-label Secure Portals',
                'Immutable Compliance Exports',
                '24/7 Dedicated Security Analyst',
            ],
            cta: 'Contact Command',
            highlight: false,
        },
    ];

    return (
        <PublicLayout>
            <div className="container py-24 md:py-32">
                <div className="text-center max-w-3xl mx-auto mb-20 space-y-6">
                    <h1 className="text-5xl md:text-6xl font-black text-slate-900 tracking-tight">Invest in Sovereignty</h1>
                    <p className="text-xl text-slate-500 font-medium">Choose a defense-grade plan that fits your security requirements. No hidden backdoors, just pure encryption.</p>
                </div>

                <div className="grid lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
                    {plans.map((plan, index) => (
                        <div
                            key={index}
                            className={`relative p-10 rounded-[3rem] border-2 transition-all duration-500 group hover:translate-y-[-8px] ${plan.highlight
                                    ? 'bg-slate-900 border-indigo-500 shadow-2xl shadow-indigo-500/10 text-white translate-y-[-4px]'
                                    : 'bg-white border-slate-100 hover:border-indigo-500/20 text-slate-900 shadow-sm hover:shadow-xl'
                                }`}
                        >
                            {plan.highlight && (
                                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-indigo-600 text-white px-6 py-2 rounded-full text-xs font-black uppercase tracking-widest whitespace-nowrap shadow-xl">
                                    Most Deployed
                                </div>
                            )}

                            <div className="mb-8 space-y-2">
                                <h3 className="text-2xl font-black">{plan.name}</h3>
                                <div className="flex items-baseline gap-1">
                                    <span className="text-4xl font-black">{plan.price}</span>
                                    {plan.price !== 'Custom' && <span className={`${plan.highlight ? 'text-slate-400' : 'text-slate-400'} font-bold text-sm`}>/month</span>}
                                </div>
                                <p className={`text-sm font-medium leading-relaxed ${plan.highlight ? 'text-slate-400' : 'text-slate-500'}`}>
                                    {plan.description}
                                </p>
                            </div>

                            <div className="space-y-4 mb-10">
                                {plan.features.map((feature, fIndex) => (
                                    <div key={fIndex} className="flex items-center gap-3">
                                        <div className={`h-5 w-5 rounded-full flex items-center justify-center shrink-0 ${plan.highlight ? 'bg-indigo-500/20 text-indigo-400' : 'bg-indigo-50 text-indigo-600'}`}>
                                            <Check className="h-3 w-3" />
                                        </div>
                                        <span className="text-sm font-bold tracking-tight">{feature}</span>
                                    </div>
                                ))}
                            </div>

                            <Button
                                className={`w-full h-14 rounded-2xl font-bold text-base transition-all ${plan.highlight
                                        ? 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-lg shadow-indigo-600/20'
                                        : 'bg-slate-900 hover:bg-slate-800 text-white'
                                    }`}
                            >
                                {plan.cta}
                            </Button>
                        </div>
                    ))}
                </div>

                <div className="mt-24 p-12 bg-slate-50 border border-slate-100 rounded-[3rem] text-center max-w-4xl mx-auto space-y-6">
                    <Shield className="h-10 w-10 text-indigo-600 mx-auto" />
                    <h2 className="text-3xl font-black text-slate-900">Security Guarantee</h2>
                    <p className="text-slate-500 font-medium max-w-2xl mx-auto">
                        All plans include our core Zero-Knowledge architecture. We believe security shouldn't be a premium feature—it's a fundamental right. Upgrade to higher tiers for more storage, advanced auditing, and dedicated organizational controls.
                    </p>
                </div>
            </div>
        </PublicLayout>
    );
};

export default Pricing;
