import React, { useState } from 'react';
import { Check, X, User, Building2, Briefcase, Clock, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import DashboardLayout from '@/components/layout/DashboardLayout';
import { toast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';

const Approvals: React.FC = () => {
  const { canApprove } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [confirmDialog, setConfirmDialog] = useState<{
    open: boolean;
    action: 'approve' | 'reject';
    user: typeof pendingUsers[0] | null;
  }>({ open: false, action: 'approve', user: null });

  const pendingUsers: any[] = [];

  const filteredUsers = pendingUsers.filter(user =>
    user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleAction = (action: 'approve' | 'reject', user: typeof pendingUsers[0]) => {
    setConfirmDialog({ open: true, action, user });
  };

  const confirmAction = () => {
    if (!confirmDialog.user) return;
    
    const { action, user } = confirmDialog;
    
    toast({
      title: action === 'approve' ? 'User approved' : 'User rejected',
      description: `${user.name} has been ${action === 'approve' ? 'approved' : 'rejected'}.`,
    });
    
    setConfirmDialog({ open: false, action: 'approve', user: null });
  };

  const getRoleBadge = (role: string) => {
    const colors: Record<string, string> = {
      employee: 'bg-primary/20 text-primary',
      manager: 'bg-warning/20 text-warning',
      administrator: 'bg-destructive/20 text-destructive',
      security_analyst: 'bg-success/20 text-success',
    };
    return (
      <Badge className={colors[role] || 'bg-muted text-muted-foreground'}>
        {role.replace('_', ' ')}
      </Badge>
    );
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Pending Approvals</h1>
          <p className="text-muted-foreground mt-1">
            Review and approve user registration requests
          </p>
        </div>

        {/* Search */}
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search users..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Pending Users */}
        {filteredUsers.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <p className="text-muted-foreground">No pending approvals</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {filteredUsers.map((user) => (
              <Card key={user.id} className="hover:border-primary/30 transition-colors">
                <CardContent className="p-6">
                  <div className="flex flex-col lg:flex-row lg:items-center gap-6">
                    <div className="flex-1 space-y-4">
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="text-lg font-semibold text-foreground">
                              {user.name}
                            </h3>
                            {getRoleBadge(user.requestedRole)}
                          </div>
                          <p className="text-sm text-muted-foreground">{user.email}</p>
                        </div>
                        <div className="flex items-center gap-1 text-sm text-muted-foreground">
                          <Clock className="h-4 w-4" />
                          {user.signupDate}
                        </div>
                      </div>

                      <div className="grid sm:grid-cols-3 gap-4 p-4 rounded-lg bg-muted/50">
                        <div className="flex items-center gap-2">
                          <User className="h-4 w-4 text-muted-foreground" />
                          <div>
                            <p className="text-xs text-muted-foreground">Employee ID</p>
                            <p className="text-sm font-medium text-foreground">{user.employeeId}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Building2 className="h-4 w-4 text-muted-foreground" />
                          <div>
                            <p className="text-xs text-muted-foreground">Org Code</p>
                            <p className="text-sm font-medium text-foreground">{user.orgCode}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Briefcase className="h-4 w-4 text-muted-foreground" />
                          <div>
                            <p className="text-xs text-muted-foreground">Department</p>
                            <p className="text-sm font-medium text-foreground">{user.department}</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="flex gap-2 lg:flex-col">
                      <Button
                        onClick={() => handleAction('approve', user)}
                        disabled={!canApprove(user.requestedRole as any)}
                        className="flex-1 lg:flex-none"
                      >
                        <Check className="h-4 w-4 mr-2" />
                        Approve
                      </Button>
                      <Button
                        variant="destructive"
                        onClick={() => handleAction('reject', user)}
                        className="flex-1 lg:flex-none"
                      >
                        <X className="h-4 w-4 mr-2" />
                        Reject
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Confirmation Dialog */}
      <AlertDialog open={confirmDialog.open} onOpenChange={(open) => setConfirmDialog({ ...confirmDialog, open })}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {confirmDialog.action === 'approve' ? 'Approve User?' : 'Reject User?'}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {confirmDialog.action === 'approve'
                ? `This will approve ${confirmDialog.user?.name} as a ${confirmDialog.user?.requestedRole.replace('_', ' ')}. They will receive an email to set up 2FA.`
                : `This will reject ${confirmDialog.user?.name}'s registration request. They will be notified via email.`}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmAction}
              className={confirmDialog.action === 'reject' ? 'bg-destructive text-destructive-foreground hover:bg-destructive/90' : ''}
            >
              {confirmDialog.action === 'approve' ? 'Approve' : 'Reject'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </DashboardLayout>
  );
};

export default Approvals;
