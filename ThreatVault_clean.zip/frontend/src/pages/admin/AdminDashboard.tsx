import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Users, 
  Shield, 
  AlertTriangle, 
  Activity, 
  FileText, 
  UserCheck,
  Lock,
  TrendingUp,
  ArrowRight
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import DashboardLayout from '@/components/layout/DashboardLayout';
import StatsCard from '@/components/shared/StatsCard';

const AdminDashboard: React.FC = () => {
  const stats = [
    {
      title: 'Total Users',
      value: '0',
      description: 'Active platform users',
      icon: Users,
      variant: 'primary' as const,
    },
    {
      title: 'Pending Approvals',
      value: '0',
      description: 'Awaiting review',
      icon: UserCheck,
      variant: 'warning' as const,
    },
    {
      title: 'Security Alerts',
      value: '0',
      description: 'Require attention',
      icon: AlertTriangle,
      variant: 'destructive' as const,
    },
    {
      title: 'Encrypted Files',
      value: '0',
      description: 'Total in system',
      icon: Lock,
      variant: 'success' as const,
    },
  ];

  const recentActivities: any[] = [];

  const quickActions = [
    { title: 'User Approvals', description: 'Review pending registrations', icon: UserCheck, href: '/admin/approvals', count: 0 },
    { title: 'Security Alerts', description: 'Monitor suspicious activity', icon: AlertTriangle, href: '/admin/suspicious', count: 0 },
    { title: 'Activity Logs', description: 'View system audit trail', icon: Activity, href: '/activity-logs' },
    { title: 'All Files', description: 'Manage encrypted files', icon: FileText, href: '/my-files' },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Admin Dashboard</h1>
            <p className="text-muted-foreground mt-1">
              System overview and administrative controls
            </p>
          </div>
          <Badge variant="outline" className="w-fit">
            <Shield className="h-3 w-3 mr-1" />
            Administrator Access
          </Badge>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((stat, index) => (
            <StatsCard
              key={index}
              title={stat.title}
              value={stat.value}
              description={stat.description}
              icon={stat.icon}
              variant={stat.variant}
            />
          ))}
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {quickActions.map((action, index) => (
            <Link key={index} to={action.href}>
              <Card className="hover:border-primary/30 hover:shadow-md transition-all cursor-pointer h-full">
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between">
                    <div className="h-10 w-10 rounded-lg gradient-primary flex items-center justify-center">
                      <action.icon className="h-5 w-5 text-primary-foreground" />
                    </div>
                    {action.count && (
                      <Badge variant="secondary">{action.count}</Badge>
                    )}
                  </div>
                  <h3 className="font-semibold text-foreground mt-4">{action.title}</h3>
                  <p className="text-sm text-muted-foreground mt-1">{action.description}</p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        {/* Recent Activity & System Health */}
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Recent Activity */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5 text-primary" />
                Recent Activity
              </CardTitle>
              <CardDescription>Latest system events</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentActivities.map((activity, index) => (
                  <div key={index} className="flex items-start gap-3 pb-3 border-b border-border last:border-0 last:pb-0">
                    <div className={`h-2 w-2 rounded-full mt-2 ${
                      activity.type === 'alert' ? 'bg-destructive' :
                      activity.type === 'user_rejected' ? 'bg-warning' :
                      'bg-success'
                    }`} />
                    <div className="flex-1 min-w-0">
                      {activity.type === 'user_approved' && (
                        <p className="text-sm text-foreground">
                          <span className="font-medium">{activity.user}</span> approved as {activity.role}
                        </p>
                      )}
                      {activity.type === 'alert' && (
                        <p className="text-sm text-foreground">
                          <span className="text-destructive font-medium">Alert:</span> {activity.message}
                        </p>
                      )}
                      {activity.type === 'user_signup' && (
                        <p className="text-sm text-foreground">
                          <span className="font-medium">{activity.user}</span> requested {activity.role} access
                        </p>
                      )}
                      {activity.type === 'file_uploaded' && (
                        <p className="text-sm text-foreground">
                          <span className="font-medium">{activity.user}</span> uploaded {activity.files} files
                        </p>
                      )}
                      {activity.type === 'user_rejected' && (
                        <p className="text-sm text-foreground">
                          <span className="font-medium">{activity.user}</span> rejected: {activity.reason}
                        </p>
                      )}
                      <p className="text-xs text-muted-foreground mt-0.5">{activity.time}</p>
                    </div>
                  </div>
                ))}
              </div>
              <Button variant="outline" className="w-full mt-4" asChild>
                <Link to="/activity-logs">
                  View All Activity
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Link>
              </Button>
            </CardContent>
          </Card>

          {/* System Health */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-primary" />
                System Health
              </CardTitle>
              <CardDescription>Platform performance metrics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center py-2">
                  <span className="text-muted-foreground">System Status</span>
                  <Badge variant="default" className="bg-success">Operational</Badge>
                </div>
                <div className="flex justify-between items-center py-2">
                  <span className="text-muted-foreground">Encryption Service</span>
                  <Badge variant="default" className="bg-success">Active</Badge>
                </div>
                <div className="flex justify-between items-center py-2">
                  <span className="text-muted-foreground">Storage Usage</span>
                  <span className="font-medium text-foreground">0 GB / 100 GB</span>
                </div>
                <div className="flex justify-between items-center py-2">
                  <span className="text-muted-foreground">Active Sessions</span>
                  <span className="font-medium text-foreground">0</span>
                </div>
                <div className="flex justify-between items-center py-2">
                  <span className="text-muted-foreground">Failed Logins (24h)</span>
                  <span className="font-medium text-foreground">0</span>
                </div>
                <div className="flex justify-between items-center py-2">
                  <span className="text-muted-foreground">API Response Time</span>
                  <span className="font-medium text-foreground">45ms</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default AdminDashboard;
