import React, { useEffect, useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { adminAPI } from '@/lib/api';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, CheckCircle2, XCircle, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';

const ApprovalAction: React.FC = () => {
    const [searchParams] = useSearchParams();
    const navigate = useNavigate();
    const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading');
    const [message, setMessage] = useState('Processing your request...');

    const userId = searchParams.get('userId');
    const action = searchParams.get('action');

    useEffect(() => {
        const handleAction = async () => {
            if (!userId || !action) {
                setStatus('error');
                setMessage('Invalid approval link. Missing parameters.');
                return;
            }

            try {
                if (action === 'approve') {
                    await adminAPI.approveUser(userId);
                    setStatus('success');
                    setMessage('User account has been successfully approved.');
                    toast.success('User approved');
                } else if (action === 'reject') {
                    await adminAPI.rejectUser(userId);
                    setStatus('success');
                    setMessage('User account has been rejected.');
                    toast.warning('User rejected');
                } else {
                    throw new Error('Invalid action');
                }
            } catch (error: any) {
                console.error('Approval action failed:', error);
                setStatus('error');
                setMessage(error.response?.data?.message || 'Failed to process the request. You might need to be logged in as an administrator.');
                toast.error('Action failed');
            }
        };

        handleAction();
    }, [userId, action]);

    return (
        <div className="min-h-screen flex items-center justify-center bg-slate-50 p-6">
            <Card className="w-full max-w-md border-none shadow-xl rounded-2xl overflow-hidden animate-in zoom-in-95">
                <CardHeader className="text-center pb-2">
                    <div className="mx-auto w-16 h-16 rounded-full flex items-center justify-center mb-4">
                        {status === 'loading' && <Loader2 className="h-10 w-10 animate-spin text-indigo-600" />}
                        {status === 'success' && (action === 'approve' ? <CheckCircle2 className="h-12 w-12 text-emerald-500" /> : <XCircle className="h-12 w-12 text-rose-500" />)}
                        {status === 'error' && <AlertCircle className="h-12 w-12 text-amber-500" />}
                    </div>
                    <CardTitle className="text-2xl font-bold">
                        {status === 'loading' && 'Processing...'}
                        {status === 'success' && (action === 'approve' ? 'User Approved' : 'User Rejected')}
                        {status === 'error' && 'Action Failed'}
                    </CardTitle>
                    <CardDescription className="text-slate-500 mt-2">
                        {message}
                    </CardDescription>
                </CardHeader>
                <CardContent className="p-6 pt-0 flex flex-col gap-4">
                    <Button
                        className="w-full rounded-xl h-11"
                        onClick={() => navigate('/login')}
                    >
                        Back to Login
                    </Button>
                    {status === 'success' && (
                        <Button
                            variant="outline"
                            className="w-full rounded-xl h-11"
                            onClick={() => navigate('/admin/dashboard')}
                        >
                            Go to Admin Dashboard
                        </Button>
                    )}
                </CardContent>
            </Card>
        </div>
    );
};

export default ApprovalAction;
