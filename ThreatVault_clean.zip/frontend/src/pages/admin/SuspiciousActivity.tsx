import React, { useState } from 'react';
import { AlertTriangle, Filter, Shield, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import DashboardLayout from '@/components/layout/DashboardLayout';
import SuspiciousAlertCard from '@/components/shared/SuspiciousAlertCard';
import StatsCard from '@/components/shared/StatsCard';
import { toast } from '@/hooks/use-toast';

const SuspiciousActivity: React.FC = () => {
  const [severityFilter, setSeverityFilter] = useState('all');

  const alerts: any[] = [];

  const filteredAlerts = alerts.filter(alert => 
    severityFilter === 'all' || alert.severity === severityFilter
  );

  const handleDismiss = (id: string) => {
    toast({
      title: 'Alert dismissed',
      description: 'The alert has been marked as reviewed.',
    });
  };

  const handleInvestigate = (id: string) => {
    toast({
      title: 'Investigation started',
      description: 'Opening detailed activity log for this alert.',
    });
  };

  const stats = [
    { title: 'Critical Alerts', value: alerts.filter(a => a.severity === 'critical').length, variant: 'destructive' as const },
    { title: 'High Severity', value: alerts.filter(a => a.severity === 'high').length, variant: 'warning' as const },
    { title: 'Medium Severity', value: alerts.filter(a => a.severity === 'medium').length, variant: 'default' as const },
    { title: 'Total Alerts', value: alerts.length, variant: 'primary' as const },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-foreground flex items-center gap-2">
              <AlertTriangle className="h-8 w-8 text-warning" />
              Security Alerts
            </h1>
            <p className="text-muted-foreground mt-1">
              Monitor and investigate suspicious activities
            </p>
          </div>
          <Button variant="outline">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>

        {/* Stats */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((stat, index) => (
            <StatsCard
              key={index}
              title={stat.title}
              value={stat.value}
              icon={Shield}
              variant={stat.variant}
            />
          ))}
        </div>

        {/* Filter */}
        <div className="flex items-center gap-4">
          <Select value={severityFilter} onValueChange={setSeverityFilter}>
            <SelectTrigger className="w-[180px]">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Filter by severity" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Severities</SelectItem>
              <SelectItem value="critical">Critical</SelectItem>
              <SelectItem value="high">High</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="low">Low</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Alerts */}
        {filteredAlerts.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <Shield className="h-12 w-12 text-success mx-auto mb-4" />
              <p className="text-lg font-medium text-foreground">No alerts found</p>
              <p className="text-muted-foreground">All systems are operating normally.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {filteredAlerts.map((alert) => (
              <SuspiciousAlertCard
                key={alert.id}
                {...alert}
                onDismiss={() => handleDismiss(alert.id)}
                onInvestigate={() => handleInvestigate(alert.id)}
              />
            ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
};

export default SuspiciousActivity;
