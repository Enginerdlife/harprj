import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Plus,
  Search,
  Grid,
  List,
  Filter,
  Loader2,
  RefreshCw,
  Shield,
  FileBox,
  LayoutGrid,
  StretchHorizontal,
  Download
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import DashboardLayout from '@/components/layout/DashboardLayout';
import { cn, getPublicAppUrl } from '@/lib/utils';
import FileCard from '@/components/shared/FileCard';
import ShareModal from '@/components/shared/ShareModal';
import FileViewerModal from '@/components/shared/FileViewerModal';
import { toast } from 'sonner';
import { useFiles, EncryptedFile } from '@/contexts/FileContext';

const MyFiles: React.FC = () => {
  const { files, removeFile, createShare, refreshFiles } = useFiles();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('date');
  const [shareModalOpen, setShareModalOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState<{ id: string; name: string } | null>(null);
  const [fileToView, setFileToView] = useState<EncryptedFile | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  useEffect(() => {
    const init = async () => {
      setIsRefreshing(true);
      await refreshFiles();
      setIsRefreshing(false);
    };
    init();
  }, []);

  const filteredFiles = (Array.isArray(files) ? files : []).filter(file =>
    file?.name?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const sortedFiles = [...filteredFiles].sort((a, b) => {
    if (!a || !b) return 0;
    if (sortBy === 'date') {
      const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
      const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
      return dateB - dateA;
    }
    if (sortBy === 'name') {
      return (a.name || '').localeCompare(b.name || '');
    }
    if (sortBy === 'size') return (b.size || 0) - (a.size || 0);
    return 0;
  });

  const handleShare = (file: { id: string; name: string }) => {
    setSelectedFile(file);
    setShareModalOpen(true);
  };

  const handleCreateShare = async (email: string, expiresIn: number) => {
    if (!selectedFile) return '';
    try {
      const newShare = await createShare(selectedFile.id, email, expiresIn);
      const publicUrl = getPublicAppUrl();
      return `${publicUrl}/share/${newShare.id}`;
    } catch (err: any) {
      toast.error(err?.message || 'Failed to create share link');
      throw err;
    }
  };

  const handleDelete = async (fileId: string, fileName: string) => {
    if (window.confirm(`Are you sure you want to delete "${fileName}"? This action cannot be undone.`)) {
      try {
        await removeFile(fileId);
        toast.success(`"${fileName}" deleted successfully`);
      } catch (err) {
        toast.error('Failed to delete file');
      }
    }
  };

  const formatFileSize = (bytes: number) => {
    if (!bytes) return '0 B';
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  return (
    <DashboardLayout>
      <div className="container mx-auto max-w-7xl py-8 px-4 animate-in fade-in duration-700">
        {/* Modern Header */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-10">
          <div className="space-y-1">
            <h1 className="text-4xl font-extrabold tracking-tight text-slate-900">
              Vault <span className="text-indigo-600 font-black">Storage</span>
            </h1>
            <p className="text-slate-500 text-lg flex items-center gap-2">
              <Shield className="w-4 h-4 text-emerald-500" />
              Manage your securely encrypted threats and assets.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              size="lg"
              onClick={() => refreshFiles()}
              disabled={isRefreshing}
              className="bg-white border-slate-200 text-slate-600 hover:bg-slate-50 rounded-xl"
            >
              <RefreshCw className={cn("h-4 w-4 mr-2", isRefreshing && "animate-spin")} />
              Sync
            </Button>
            <Button asChild variant="secondary" size="lg" className="rounded-xl border border-slate-200">
              <Link to="/received">
                <Download className="h-5 w-5 mr-1 text-indigo-600" />
                Receive
              </Link>
            </Button>
            <Button asChild size="lg" className="bg-indigo-600 hover:bg-indigo-700 shadow-indigo-200/50 shadow-lg rounded-xl transition-all hover:scale-[1.02]">
              <Link to="/upload">
                <Plus className="h-5 w-5 mr-1" />
                Secure Upload
              </Link>
            </Button>
          </div>
        </div>

        {/* Toolbar */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm mb-8 flex flex-col md:flex-row gap-4 items-center">
          <div className="relative flex-1 w-full">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <Input
              placeholder="Search by filename..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 h-11 bg-slate-50/50 border-slate-200 rounded-xl focus:ring-indigo-500 w-full"
            />
          </div>

          <div className="flex items-center gap-3 w-full md:w-auto">
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-full md:w-[160px] h-11 bg-slate-50/50 border-slate-200 rounded-xl px-4">
                <div className="flex items-center gap-2">
                  <Filter className="h-4 w-4 text-slate-400" />
                  <SelectValue placeholder="Sort by" />
                </div>
              </SelectTrigger>
              <SelectContent className="rounded-xl">
                <SelectItem value="date">Latest First</SelectItem>
                <SelectItem value="name">Filename A-Z</SelectItem>
                <SelectItem value="size">Size (Large to Small)</SelectItem>
              </SelectContent>
            </Select>

            <div className="flex bg-slate-100 p-1 rounded-xl shrink-0">
              <Button
                variant={viewMode === 'list' ? 'white' : 'ghost'}
                size="icon"
                onClick={() => setViewMode('list')}
                className={cn("h-9 w-10 rounded-lg transition-all", viewMode === 'list' ? "bg-white shadow-sm" : "text-slate-500")}
              >
                <StretchHorizontal className="h-4 w-4" />
              </Button>
              <Button
                variant={viewMode === 'grid' ? 'white' : 'ghost'}
                size="icon"
                onClick={() => setViewMode('grid')}
                className={cn("h-9 w-10 rounded-lg transition-all", viewMode === 'grid' ? "bg-white shadow-sm" : "text-slate-500")}
              >
                <LayoutGrid className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Files Display */}
        {isRefreshing ? (
          <div className="flex flex-col items-center justify-center py-24 space-y-6">
            <div className="relative">
              <Loader2 className="h-12 w-12 animate-spin text-indigo-600" />
              <div className="absolute inset-0 h-12 w-12 rounded-full border-4 border-indigo-100/50" />
            </div>
            <div className="text-center">
              <p className="text-slate-900 font-bold text-lg animate-pulse">Synchronizing Cryptographic Vault</p>
              <p className="text-slate-400">Establishing secure connection to PostgreSQL...</p>
            </div>
          </div>
        ) : sortedFiles.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-32 bg-slate-50/50 rounded-3xl border-2 border-dashed border-slate-200">
            <div className="h-20 w-20 rounded-full bg-slate-100 flex items-center justify-center mb-6">
              <FileBox className="h-10 w-10 text-slate-300" />
            </div>
            <h3 className="text-xl font-bold text-slate-800 mb-2">No files discovered</h3>
            <p className="text-slate-500 mb-8 max-w-xs text-center">
              Your secure vault is currently empty. Start by uploading an encrypted file.
            </p>
            <Button asChild className="rounded-xl flex gap-2">
              <Link to="/upload">
                <Plus className="h-4 w-4" /> Secure Upload
              </Link>
            </Button>
          </div>
        ) : (
          <div className={cn(
            "transition-all duration-300",
            viewMode === 'grid'
              ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6'
              : 'space-y-4'
          )}>
            {sortedFiles.map((file) => (
              <FileCard
                key={file.id}
                id={file.id}
                name={file.name}
                size={formatFileSize(file.size)}
                type={file.type}
                uploadedAt={new Date(file.createdAt).toLocaleDateString(undefined, {
                  year: 'numeric',
                  month: 'short',
                  day: 'numeric'
                })}
                viewMode={viewMode}
                onView={() => setFileToView(file)}
                onDownload={() => setFileToView(file)} // Triggers password verification via FileViewerModal
                onShare={() => handleShare(file)}
                onDelete={() => handleDelete(file.id, file.name)}
              />
            ))}
          </div>
        )}
      </div>

      {/* Modals */}
      {selectedFile && (
        <ShareModal
          isOpen={shareModalOpen}
          onClose={() => setShareModalOpen(false)}
          fileName={selectedFile.name}
          onShare={handleCreateShare}
        />
      )}

      {fileToView && (
        <FileViewerModal
          isOpen={!!fileToView}
          onClose={() => setFileToView(null)}
          file={fileToView}
        />
      )}
    </DashboardLayout>
  );
};

export default MyFiles;
