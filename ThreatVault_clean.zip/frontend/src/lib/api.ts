import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_URL || '/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  maxBodyLength: Infinity,
  maxContentLength: Infinity,
});

// JWT Interceptor - Add token to requests
api.interceptors.request.use(
  (config) => {
    const token = sessionStorage.getItem('threatvault_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response Interceptor - Handle token expiration
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (error.response?.status === 401) {
      sessionStorage.removeItem('threatvault_token');
      sessionStorage.removeItem('threatvault_user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Auth API
export const authAPI = {
  login: (data: { email: string; password: string; role: string; employeeId?: string; code?: string }) =>
    api.post('/auth/login', {
      email: data.email,
      password: data.password,
      role: data.role,
      employeeId: data.employeeId,
      code: data.code
    }),
  signup: (data: any) => api.post('/auth/signup', data),
  googleAuth: (token: string) => api.post('/auth/google', { token }),
  // Advanced Security
  getQRCode: () => api.get('/auth/qr-code'),
  verifySession: (code: string) => api.post('/auth/verify-session', { code }),
  sendOTP: (email: string, phoneNumber?: string) => api.post('/auth/send-otp', { email, phoneNumber }),
  verifyOTP: (email: string, code: string) => api.post('/auth/verify-otp', { email, code }),
  setup2FA: (data: any) => api.post('/auth/setup-2fa', data),
  verify2FA: (data: any) => api.post('/auth/verify-2fa', data),
  logout: () => api.post('/auth/logout'),
};

// Files API
export const filesAPI = {
  upload: (data: any) =>
    api.post('/files/upload', data),
  getMyFiles: () => api.get('/files'),
  getFileDetails: (id: string) => api.get(`/files/${id}`),
  verifyFilePassword: (id: string, password: string) =>
    api.post(`/files/${id}/verify-password`, { password }),
  downloadFile: (id: string) => api.get(`/files/${id}/download`),
  deleteFile: (id: string) => api.delete(`/files/${id}`),
};

// Shares API
export const sharesAPI = {
  createShare: (data: { fileId: string; recipientEmail: string; expiresIn: number }) =>
    api.post('/shares', data),
  getMyShares: () => api.get('/shares'),
  revokeShare: (id: string) => api.delete(`/shares/${id}`),
  getShareDetails: (id: string) => api.get(`/shares/${id}`),
  downloadSharedFile: (id: string) => api.get(`/shares/${id}/download`),
};

// Admin API
export const adminAPI = {
  getPendingUsers: () => api.get('/admin/pending-users'),
  approveUser: (userId: string) => api.post(`/admin/approve/${userId}`),
  rejectUser: (userId: string) => api.post(`/admin/reject/${userId}`),
  getActivityLogs: () => api.get('/admin/logs'),
  getSuspiciousActivity: () => api.get('/admin/suspicious-activity'),
};

// Logs API
export const logsAPI = {
  getAllLogs: () => api.get('/logs'),
  getUserLogs: (userId: string) => api.get(`/logs/user/${userId}`),
  getFileLogs: (fileId: string) => api.get(`/logs/file/${fileId}`),
  getShareTransactions: () => api.get('/logs'), // Will filter FILE_SHARED on frontend
};

// Team API
export const teamAPI = {
  getTeamMembers: () => api.get('/team/members'),
  getTeamStats: () => api.get('/team/stats'),
};

// User API
export const userAPI = {
  getProfile: () => api.get('/user/profile'),
  updateProfile: (data: { name?: string; email?: string }) =>
    api.patch('/user/profile', data),
  changePassword: (data: { currentPassword: string; newPassword: string }) =>
    api.post('/user/change-password', data),
  getSecuritySettings: () => api.get('/user/security'),
  updateSecuritySettings: (data: { twoFactorEnabled?: boolean; phone_number?: string }) =>
    api.patch('/user/security', data),
};

export default api;
