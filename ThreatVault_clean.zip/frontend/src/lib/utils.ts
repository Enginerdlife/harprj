import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function getPublicAppUrl() {
  const envUrl = import.meta.env.VITE_PUBLIC_URL?.trim();
  if (envUrl) {
    return envUrl.replace(/\/$/, '');
  }

  const origin = window.location.origin.replace(/\/$/, '');
  if (origin) {
    const isLocalhost = /^(https?:\/\/)?(localhost|127(?:\.0\.0\.1)?)(:\d+)?$/i.test(origin);
    if (isLocalhost) {
      console.warn('VITE_PUBLIC_URL is not set. Falling back to window.location.origin for share URL generation. This may not be externally reachable from other machines.');
    }
    return origin;
  }

  throw new Error('Public app URL is not configured. Set VITE_PUBLIC_URL to the externally reachable app URL before sharing files with external users.');
}
