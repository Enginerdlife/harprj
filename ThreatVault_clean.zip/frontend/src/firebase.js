import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyBLkUBYZOfY8D9aCkxLF2Zk8VgzpCzKbzY",
  authDomain: "jai-hanuman-threatvault.firebaseapp.com",
  projectId: "jai-hanuman-threatvault",
  storageBucket: "jai-hanuman-threatvault.firebasestorage.app",
  messagingSenderId: "530823922424",
  appId: "1:530823922424:web:8550e2eae06972d760310d"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
