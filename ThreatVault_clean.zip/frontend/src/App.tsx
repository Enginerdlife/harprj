import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "@/contexts/ThemeContext";
import { AuthProvider } from "@/contexts/AuthContext";
import { FileProvider } from "@/contexts/FileContext";
import ProtectedRoute from "@/components/auth/ProtectedRoute";
import PublicRoute from "@/components/auth/PublicRoute";

// Public Pages
import Index from "./pages/Index";
import Features from "./pages/Features";
import Documentation from "./pages/Documentation";
import Pricing from "./pages/Pricing";
import About from "./pages/About";
import Blog from "./pages/Blog";
import Careers from "./pages/Careers";
import Legal from "./pages/Legal";
import Privacy from "./pages/Privacy";
import Terms from "./pages/Terms";
import ShareLanding from "./pages/ShareLanding";
import NotFound from "./pages/NotFound";
import Home from "./pages/Home";

// Auth Pages
import Login from "./pages/auth/Login";
import Signup from "./pages/auth/Signup";
import PendingApproval from "./pages/auth/PendingApproval";
import Setup2FA from "./pages/auth/Setup2FA";

// Protected Pages
import Dashboard from "./pages/Dashboard";
import Overview from "./pages/Overview";
import Upload from "./pages/Upload";
import MyFiles from "./pages/MyFiles";
import MyShares from "./pages/MyShares";
import ReceivedFiles from "./pages/ReceivedFiles";
import ActivityLogs from "./pages/ActivityLogs";
import Profile from "./pages/Profile";
import Security from "./pages/Security";
import Team from "./pages/Team";

// Admin Pages
import Approvals from "./pages/admin/Approvals";
import SuspiciousActivity from "./pages/admin/SuspiciousActivity";
import AdminDashboard from "./pages/admin/AdminDashboard";
import ApprovalAction from "./pages/admin/ApprovalAction";

const queryClient = new QueryClient();

const App = () => {
  console.log("[App] Rendering root component");
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <AuthProvider>
          <FileProvider>
            <TooltipProvider>
              <Toaster />
              <Sonner />
              <BrowserRouter>
                <Routes>
                  {/* Public Routes */}
                  <Route path="/" element={<Index />} />
                  <Route path="/features" element={<PublicRoute><Features /></PublicRoute>} />
                  <Route path="/documentation" element={<PublicRoute><Documentation /></PublicRoute>} />
                  <Route path="/pricing" element={<PublicRoute><Pricing /></PublicRoute>} />
                  <Route path="/about" element={<PublicRoute><About /></PublicRoute>} />
                  <Route path="/blog" element={<PublicRoute><Blog /></PublicRoute>} />
                  <Route path="/careers" element={<PublicRoute><Careers /></PublicRoute>} />
                  <Route path="/legal" element={<PublicRoute><Legal /></PublicRoute>} />
                  <Route path="/privacy" element={<PublicRoute><Privacy /></PublicRoute>} />
                  <Route path="/terms" element={<PublicRoute><Terms /></PublicRoute>} />
                  <Route path="/share/:shareId" element={<ShareLanding />} />

                  {/* Auth Routes */}
                  <Route path="/login" element={<PublicRoute><Login /></PublicRoute>} />
                  <Route path="/signup" element={<PublicRoute><Signup /></PublicRoute>} />
                  <Route path="/pending-approval" element={<PublicRoute><PendingApproval /></PublicRoute>} />
                  <Route path="/setup-2fa" element={<PublicRoute><Setup2FA /></PublicRoute>} />

                  {/* Protected Routes */}
                  <Route path="/home" element={<ProtectedRoute><Home /></ProtectedRoute>} />
                  <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
                  <Route path="/overview" element={<ProtectedRoute><Overview /></ProtectedRoute>} />
                  <Route path="/upload" element={<ProtectedRoute><Upload /></ProtectedRoute>} />
                  <Route path="/my-files" element={<ProtectedRoute><MyFiles /></ProtectedRoute>} />
                  <Route path="/my-shares" element={<ProtectedRoute><MyShares /></ProtectedRoute>} />
                  <Route path="/received" element={<ProtectedRoute><ReceivedFiles /></ProtectedRoute>} />
                  <Route path="/activity-logs" element={<ProtectedRoute allowedRoles={['auditor', 'compliance_officer', 'security_analyst', 'administrator']}><ActivityLogs /></ProtectedRoute>} />
                  <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
                  <Route path="/security" element={<ProtectedRoute><Security /></ProtectedRoute>} />
                  <Route path="/team" element={<ProtectedRoute allowedRoles={['manager']}><Team /></ProtectedRoute>} />

                  {/* Admin Routes */}
                  <Route path="/admin/approvals" element={<ProtectedRoute allowedRoles={['administrator', 'hr']}><Approvals /></ProtectedRoute>} />
                  <Route path="/admin/suspicious" element={<ProtectedRoute allowedRoles={['administrator', 'security_analyst']}><SuspiciousActivity /></ProtectedRoute>} />
                  <Route path="/admin/dashboard" element={<ProtectedRoute allowedRoles={['administrator']}><AdminDashboard /></ProtectedRoute>} />
                  <Route path="/admin/approval-action" element={<ApprovalAction />} />

                  {/* Catch-all */}
                  <Route path="*" element={<NotFound />} />
                </Routes>
              </BrowserRouter>
            </TooltipProvider>
          </FileProvider>
        </AuthProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
};

export default App;
