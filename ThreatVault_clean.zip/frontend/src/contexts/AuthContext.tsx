import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { authAPI } from '@/lib/api';

export type UserRole = 'employee' | 'administrator' | 'student' | 'guest' | 'manager' | 'it_support' | 'auditor' | 'compliance_officer' | 'security_analyst' | 'hr' | 'ADMIN';

export interface User {
    id: string;
    name: string;
    email: string;
    activeRole: UserRole;
    status: 'active' | 'pending' | 'rejected';
    department?: string;
    orgCode?: string;
    employeeId?: string;
}

interface AuthContextType {
    user: User | null;
    isAuthenticated: boolean;
    isLoading: boolean;
    login: (email: string, password: string, role: UserRole, employeeId?: string, code?: string) => Promise<any>;
    signup: (data: any) => Promise<void>;
    logout: () => void;
    googleLogin: (token: string) => Promise<void>;
    hasRole: (roles: UserRole[]) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [user, setUser] = useState<User | null>(null);
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [isLoading, setIsLoading] = useState(true);

    // Initialize auth state from local storage
    useEffect(() => {
        const initAuth = async () => {
            const token = sessionStorage.getItem('threatvault_token');
            const savedUser = sessionStorage.getItem('threatvault_user');

            if (token && savedUser) {
                try {
                    const parsedUser = JSON.parse(savedUser);

                    // Consistent role mapping for administrator (case-insensitive)
                    const role = (parsedUser.active_role || parsedUser.role || parsedUser.activeRole || '').toLowerCase();
                    if (role === 'admin' || role === 'administrator') {
                        parsedUser.activeRole = 'administrator';
                    } else {
                        parsedUser.activeRole = parsedUser.activeRole || parsedUser.active_role || parsedUser.role;
                    }

                    if (parsedUser.activeRole === 'admin') {
                        parsedUser.activeRole = 'administrator';
                    }

                    console.log(`[AuthContext] Initializing. UserID: ${parsedUser.id}, Role: ${parsedUser.activeRole}`);
                    setUser(parsedUser);
                    setIsAuthenticated(true);
                } catch (e) {
                    console.error("Failed to parse saved user", e);
                    sessionStorage.removeItem('threatvault_user');
                    sessionStorage.removeItem('threatvault_token');
                }
            }
            setIsLoading(false);
        };

        initAuth();
    }, []);

    const login = async (email: string, password: string, role: UserRole, employeeId?: string, code?: string) => {
        setIsLoading(true);
        try {
            const response = await authAPI.login({ email, password, role, employeeId, code });

            if (response.data.status === '2fa_required') {
                return response.data;
            }

            const { token, user } = response.data.data;

            // Map admin role consistently (case-insensitive)
            const mappedRole = (user.activeRole || user.active_role || '').toLowerCase();
            if (mappedRole === 'admin' || mappedRole === 'administrator') {
                user.activeRole = 'administrator';
            }

            console.log(`[AuthContext] Login success. UserID: ${user.id}, Role: ${user.activeRole}`);

            sessionStorage.setItem('threatvault_token', token);
            sessionStorage.setItem('threatvault_user', JSON.stringify(user));

            setUser(user);
            setIsAuthenticated(true);
        } catch (error) {
            console.error('Login failed:', error);
            throw error;
        } finally {
            setIsLoading(false);
        }
    };

    const signup = async (data: any) => {
        setIsLoading(true);
        try {
            await authAPI.signup(data);
            // Signup usually redirects to login or pending, doesn't auto-login unless API returns token
        } catch (error) {
            console.error('Signup failed:', error);
            throw error;
        } finally {
            setIsLoading(false);
        }
    };

    const googleLogin = async (token: string) => {
        setIsLoading(true);
        try {
            const response = await authAPI.googleAuth(token);
            const { token: jwt, user } = response.data.data;

            sessionStorage.setItem('threatvault_token', jwt);
            sessionStorage.setItem('threatvault_user', JSON.stringify(user));

            setUser(user);
            setIsAuthenticated(true);
        } catch (error) {
            console.error('Google login failed:', error);
            throw error;
        } finally {
            setIsLoading(false);
        }
    };

    const logout = async () => {
        try {
            await authAPI.logout();
        } catch (e) {
            // ignore
        }
        sessionStorage.removeItem('threatvault_token');
        sessionStorage.removeItem('threatvault_user');
        setUser(null);
        setIsAuthenticated(false);
        window.location.href = '/login';
    };

    const hasRole = (roles: UserRole[]) => {
        if (!user?.activeRole) return false;
        return roles.includes(user.activeRole);
    };

    return (
        <AuthContext.Provider value={{
            user,
            isAuthenticated,
            isLoading,
            login,
            signup,
            logout,
            googleLogin,
            hasRole
        }}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => {
    const context = useContext(AuthContext);
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
};
