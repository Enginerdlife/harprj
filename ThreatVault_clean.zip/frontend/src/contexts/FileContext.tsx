import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { filesAPI, sharesAPI } from '@/lib/api';
import { useAuth } from './AuthContext';

export interface EncryptedFile {
  id: string;
  name: string;
  size: number;
  type: string;
  createdAt: string;
  updatedAt: string;
  iv: string;
  encryptedKey: string;
  encryptedData: string;
  salt?: string; // Base64 encoded salt for password key derivation
  keyIv?: string; // IV used for encrypting the key
  protectionMethod?: 'password' | 'none';
}

export interface Share {
  id: string;
  fileId: string;
  recipient: string;
  token: string;
  expiresAt: string;
  createdAt: string;
  status: 'active' | 'expired' | 'revoked';
  accessCount: number;
  fileName: string; // Denormalized for easier display
}

interface FileContextType {
  files: EncryptedFile[];
  shares: Share[];
  uploadFile: (file: any) => Promise<EncryptedFile>;
  removeFile: (fileId: string) => void;
  getFile: (fileId: string) => EncryptedFile | undefined;
  getAllFiles: () => EncryptedFile[];
  createShare: (fileId: string, recipient: string, expiresIn: number) => Promise<Share>;
  revokeShare: (shareId: string) => void;
  refreshFiles: () => Promise<void>;
}

const FileContext = createContext<FileContextType | undefined>(undefined);

export const FileProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [files, setFiles] = useState<EncryptedFile[]>([]);
  const [shares, setShares] = useState<Share[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const { isAuthenticated } = useAuth();

  const fetchData = async () => {
    if (!isAuthenticated) {
      setFiles([]);
      setShares([]);
      setIsLoading(false);
      return;
    }

    try {
      setIsLoading(true);
      console.log(`[FileContext] Fetching files for user context...`);
      const [filesRes, sharesRes] = await Promise.all([
        filesAPI.getMyFiles(),
        sharesAPI.getMyShares()
      ]);
      console.log(`[FileContext] Received ${filesRes.data.data?.length || 0} files and ${sharesRes.data.data?.length || 0} shares`);
      setFiles(filesRes.data.data || []);
      setShares(sharesRes.data.data || []);
    } catch (error) {
      console.error('Failed to fetch data:', error);
      // Fallback to empty if auth fails or error
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [isAuthenticated]);

  const uploadFile = async (file: any) => {
    // Current flow: Upload.tsx calls this AFTER encrypting.
    try {
      console.log('[FileContext] Uploading file via context:', file);
      const response = await filesAPI.upload(file);
      const newFile = response.data.data;

      console.log('[FileContext] Upload success. API Response:', response);
      if (newFile) {
        setFiles(prev => [newFile, ...prev]);
        return newFile;
      }
      throw new Error('Upload failed: No data in response');
    } catch (error) {
      console.error('[FileContext] Upload failed', error);
      throw error;
    }
  };

  const removeFile = async (fileId: string) => {
    try {
      await filesAPI.deleteFile(fileId);
      setFiles(prev => prev.filter(f => f.id !== fileId));
    } catch (error) {
      console.error('Delete failed', error);
      throw error;
    }
  };

  const createShare = async (fileId: string, recipient: string, expiresIn: number) => {
    try {
      console.log('Creating share:', { fileId, recipient, expiresIn });
      const response = await sharesAPI.createShare({
        fileId,
        recipientEmail: recipient,
        expiresIn
      });
      const newShare: Share = response.data.data;
      console.log('Share created successfully:', newShare);
      setShares(prev => [newShare, ...prev]);
      return newShare;
    } catch (error) {
      console.error('Share creation failed:', error);
      throw error;
    }
  };

  const revokeShare = async (shareId: string) => {
    try {
      await sharesAPI.revokeShare(shareId);
      setShares(prev => prev.map(s => s.id === shareId ? { ...s, status: 'revoked' as const } : s));
    } catch (error) {
      console.error('Revoke failed', error);
      throw error;
    }
  };

  const getShare = (shareId: string) => {
    // With backend, we might not have all shares in memory if paging? 
    // But for now we fetch all.
    return shares.find(s => s.id === shareId);
  };

  const getFile = (fileId: string) => {
    return files.find(f => f.id === fileId);
  };

  const getAllFiles = () => {
    return [...files];
  };

  return (
    <FileContext.Provider
      value={{
        files,
        shares,
        uploadFile,
        removeFile,
        getFile,
        getAllFiles,
        createShare,
        revokeShare,
        getShare,
        refreshFiles: fetchData
      }}
    >
      {children}
    </FileContext.Provider>
  );
};

export const useFiles = () => {
  const context = useContext(FileContext);
  if (context === undefined) {
    throw new Error('useFiles must be used within a FileProvider');
  }
  return context;
};
