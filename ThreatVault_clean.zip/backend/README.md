# ThreatVault Backend

Zero-Trust Encrypted File Sharing Platform - Backend API

## Project Structure

```
backend/
├── src/
│   ├── config/
│   │   ├── env.js              # Environment variables
│   │   ├── database.js         # Database configuration & Firestore connection
│   │   ├── firebase.js         # Firebase client setup
│   │   ├── jwt.js              # JWT token management
│   │   ├── constants.js        # Global constants & roles
│   ├── utils/
│   │   └── hash.js             # Password hashing utilities
│   ├── controllers/            # Business logic
│   │   ├── authController.js
│   │   ├── userController.js
│   │   ├── fileController.js
│   │   ├── shareController.js
│   │   ├── adminController.js
│   │   └── logController.js
│   ├── routes/                 # API endpoints
│   │   ├── authRoutes.js
│   │   ├── userRoutes.js
│   │   ├── fileRoutes.js
│   │   ├── shareRoutes.js
│   │   ├── adminRoutes.js
│   │   └── logRoutes.js
│   ├── middleware/             # Request handlers
│   │   ├── authMiddleware.js
│   │   ├── roleMiddleware.js
│   │   ├── validationMiddleware.js
│   │   └── errorMiddleware.js
│   ├── app.js                  # Express app setup
│   └── server.js               # Server entry point
├── .env                        # Environment variables (not in git)
├── .env.example                # Environment template
├── .gitignore
├── package.json
└── README.md
```

## Getting Started

### Prerequisites

- Node.js v14+ 
- npm or yarn

### Installation

1. Navigate to backend directory:
   ```bash
   cd backend
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Create `.env` file (copy from `.env.example` or use existing `.env`):
   ```bash
   NODE_ENV=development
   PORT=5000
   
   FIREBASE_PROJECT_ID=your-project-id
   FIREBASE_CLIENT_EMAIL=your-client-email
   FIREBASE_PRIVATE_KEY="your-private-key"
   FIREBASE_STORAGE_BUCKET=your-bucket-name.appspot.com
   
   JWT_SECRET=your-secret-key
   JWT_EXPIRE=7d
   ```

## Firebase Setup

1. Create a Firebase project at https://console.firebase.google.com
2. Enable Firestore Database
3. Enable Firebase Storage
4. Create a Service Account (Project Settings -> Service Accounts)
5. Generate a new private key and add credentials to `.env` file

### Running the Server

**Development mode (with auto-reload):**
```bash
npm run dev
```

**Production mode:**
```bash
npm start
```

The server will start on `http://localhost:5000`

## API Endpoints

### Health Check
- `GET /api/health` - Server status

### Authentication
- `POST /api/auth/signup` - Register new user
- `POST /api/auth/login` - Login user and get JWT token
- `POST /api/auth/logout` - Logout user
- `POST /api/auth/refresh-token` - Refresh JWT token

### Files
- `GET /api/files` - Get all user files
- `POST /api/files/upload` - Upload file
- `GET /api/files/:id` - Get file details
- `GET /api/files/:id/download` - Download file
- `DELETE /api/files/:id` - Delete file

### Sharing
- `GET /api/shares` - Get shared files
- `POST /api/shares` - Share file with users
- `GET /api/shares/:id` - Get share details
- `DELETE /api/shares/:id` - Revoke share

## Dependencies

- **express** - Web framework
- **cors** - Cross-Origin Resource Sharing
- **dotenv** - Environment variable management
- **firebase-admin** - Firebase Admin SDK for database & storage operations

## License

MIT
