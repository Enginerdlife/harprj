import nodemailer from 'nodemailer';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

// Load .env from parent directory
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
dotenv.config({ path: path.join(__dirname, '../.env') });

async function verifyEmailConfig() {
    console.log('--- Email Configuration Verification ---');
    console.log(`SMTP_HOST: ${process.env.SMTP_HOST}`);
    console.log(`SMTP_PORT: ${process.env.SMTP_PORT}`);
    console.log(`SMTP_USER: ${process.env.SMTP_USER ? 'Set (***)' : 'MISSING'}`);
    console.log(`SMTP_PASS: ${process.env.SMTP_PASS ? 'Set (***)' : 'MISSING'}`);
    console.log('----------------------------------------');

    if (!process.env.SMTP_USER || !process.env.SMTP_PASS) {
        console.error('❌ Error: SMTP_USER or SMTP_PASS is missing in .env file.');
        console.error('   You must set these values to send emails.');
        console.error('   If using Gmail, generate an App Password at: https://myaccount.google.com/apppasswords');
        process.exit(1);
    }

    const transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST || 'smtp.gmail.com',
        port: parseInt(process.env.SMTP_PORT) || 587,
        secure: false,
        auth: {
            user: process.env.SMTP_USER,
            pass: process.env.SMTP_PASS,
        },
    });

    try {
        console.log('Attempting to verify SMTP connection...');
        await transporter.verify();
        console.log('✅ SMTP Connection Successful!');

        console.log('Attempting to send test email...');
        const info = await transporter.sendMail({
            from: process.env.SMTP_FROM || process.env.SMTP_USER,
            to: process.env.SMTP_USER, // Send to self
            subject: 'ThreatVault Email Test',
            text: 'If you are reading this, your email configuration is working correctly!',
        });
        console.log(`✅ Test email sent successfully! Message ID: ${info.messageId}`);
        console.log(`   Check your inbox at: ${process.env.SMTP_USER}`);

    } catch (error) {
        console.error('❌ SMTP Connection/Sending Failed:');
        console.error(error);
    }
}

verifyEmailConfig();
