
import { db } from '../src/config/firebase.js';
import { hashPassword } from '../src/utils/passwordHelper.js';

const seedAdmin = async () => {
    try {
        const adminEmail = 'admin@threatvault.com';
        const adminPassword = 'Admin123!';
        const adminName = 'System Administrator';

        console.log(`[Seed] Checking for existing admin: ${adminEmail}`);

        const snapshot = await db.collection('users').where('email', '==', adminEmail).limit(1).get();

        const passwordHash = await hashPassword(adminPassword);

        const adminData = {
            name: adminName,
            email: adminEmail,
            password_hash: passwordHash,
            active_role: 'administrator',
            role_requested: 'administrator', // Auto-approve
            status: 'active',
            department: 'IT Security',
            employee_id: 'ADMIN-001',
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
        };

        if (!snapshot.empty) {
            const doc = snapshot.docs[0];
            await doc.ref.update({
                password_hash: passwordHash,
                active_role: 'administrator',
                status: 'active',
                updated_at: new Date().toISOString()
            });
            console.log(`[Seed] ✓ Admin user updated. ID: ${doc.id}`);
        } else {
            const ref = await db.collection('users').add(adminData);
            console.log(`[Seed] ✓ Admin user created. ID: ${ref.id}`);
        }

        console.log(`[Seed] Credentials: ${adminEmail} / ${adminPassword}`);
        process.exit(0);
    } catch (error) {
        console.error('[Seed] Failed to seed admin:', error);
        process.exit(1);
    }
};

seedAdmin();
