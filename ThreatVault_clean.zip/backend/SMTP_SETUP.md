# ThreatVault SMTP Email Setup Guide

## Current Status
⚠️ **SMTP is NOT configured** - Emails will not be sent until you complete this setup.

---

## Option 1: Gmail (Free - Recommended)

### Prerequisites
- A Gmail account
- 2-Factor Authentication enabled on your Gmail account

### Steps

1. **Enable 2-Factor Authentication**
   - Go to https://myaccount.google.com/security
   - Enable 2-Step Verification if not already enabled

2. **Generate App Password**
   - Go to https://myaccount.google.com/apppasswords
   - Select "Mail" and "Windows Computer" (or Other)
   - Click "Generate"
   - Copy the 16-character code (e.g., `abcd efgh ijkl mnop`)

3. **Update `.env` file**
   Open `backend/.env` and update lines 29-30:
   ```env
   SMTP_USER=your-gmail@gmail.com
   SMTP_PASS=yourapppasswordhere
   ```
   
   Example:
   ```env
   SMTP_USER=admin@gmail.com
   SMTP_PASS=abcdefghijklmnop
   ```

4. **Restart Backend Server**
   ```bash
   cd backend
   npm run dev
   ```

---

## Option 2: Using Ethereal (Free - For Testing Only)

If you just want to test without real email delivery:

1. Go to https://ethereal.email/
2. Click "Create Ethereal Account"
3. Copy the SMTP credentials provided
4. Update `.env`:
   ```env
   SMTP_HOST=smtp.ethereal.email
   SMTP_PORT=587
   SMTP_USER=<your-ethereal-username>
   SMTP_PASS=<your-ethereal-password>
   ```

**Note**: Emails won't actually be delivered, but you can view them at https://ethereal.email/messages

---

## Verification

After configuring SMTP, test it:

```bash
cd backend
node scripts/test-email.js
```

Expected output:
```
✅ SMTP Connection Successful!
✅ Test email sent successfully!
```

---

## Troubleshooting

### "Invalid login" error
- Make sure you're using an App Password, NOT your regular Gmail password
- Remove any spaces from the app password

### "Connection timeout"
- Check firewall settings
- Verify SMTP_PORT is 587 (for TLS)

### Emails going to spam
- Add `no-reply@threatvault.app` to contacts
- Check spam folder after first send
