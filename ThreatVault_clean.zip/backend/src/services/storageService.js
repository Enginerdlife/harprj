export function uploadToStorage() {
  throw new Error('Storage disabled: uploadToStorage was removed.');
}

export function getFileUrl() {
  throw new Error('Storage disabled: getFileUrl was removed.');
}  getProfile: () => api.get('/user/profile'),
  updateProfile: (data: { name?: string; email?: string }) =>
    api.patch('/user/profile', data),
