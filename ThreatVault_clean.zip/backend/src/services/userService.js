import { db } from '../config/firebase.js';

export const createUser = async (userData) => {
  try {
    const docRef = await db.collection('users').add({
        ...userData,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
    });
    const savedDoc = await docRef.get();
    return { success: true, data: { id: savedDoc.id, ...savedDoc.data() } };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

export const getUserByEmail = async (email) => {
  try {
    const snapshot = await db.collection('users').where('email', '==', email).limit(1).get();
    if (snapshot.empty) return { success: true, data: null };
    const doc = snapshot.docs[0];
    return { success: true, data: { id: doc.id, ...doc.data() } };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

export const getUserById = async (id) => {
  try {
    const doc = await db.collection('users').doc(id).get();
    if (!doc.exists) return { success: true, data: null };
    return { success: true, data: { id: doc.id, ...doc.data() } };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

export const updateUser = async (id, updates) => {
  try {
    await db.collection('users').doc(id).update({
        ...updates,
        updated_at: new Date().toISOString(),
    });
    const updatedDoc = await db.collection('users').doc(id).get();
    return { success: true, data: { id: updatedDoc.id, ...updatedDoc.data() } };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

export const deleteUser = async (id) => {
  try {
    await db.collection('users').doc(id).delete();
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

export const getAllUsers = async (filters = {}) => {
  try {
    let query = db.collection('users');

    if (filters.status) {
      query = query.where('status', '==', filters.status);
    }

    if (filters.role) {
      query = query.where('active_role', '==', filters.role);
    }

    if (filters.limit) {
      query = query.limit(filters.limit);
    }

    const snapshot = await query.get();
    const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

    return { success: true, data };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

export const getUserCount = async () => {
  try {
    const snapshot = await db.collection('users').count().get();
    return { success: true, count: snapshot.data().count };
  } catch (error) {
    return { success: false, error: error.message };
  }
};
