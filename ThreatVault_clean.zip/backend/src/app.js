import express from 'express';
import cors from 'cors';
import authRoutes from './authRoutes/authRoutes.js';
import userRoutes from './authRoutes/userRoutes.js';
import fileRoutes from './authRoutes/fileRoutes.js';
import shareRoutes from './authRoutes/shareRoutes.js';
import adminRoutes from './authRoutes/adminRoutes.js';
import logRoutes from './authRoutes/logRoutes.js';
import errorMiddleware from './middleware/errorMiddleware.js';
import path from 'path';
import { fileURLToPath } from 'url';
import './config/firebase.js'; // initialize firebase-admin early

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Serve static files from the React frontend app
app.use(express.static(path.join(__dirname, '../../frontend/dist')));

app.get('/api/health', (req, res) => {
  res.status(200).json({
    status: 'success',
    message: 'ThreatVault API - Zero-Trust Encrypted File Sharing Platform',
    version: '1.0.0',
    timestamp: new Date().toISOString(),
  });
});

app.use('/api/auth', authRoutes);
app.use('/api/user', userRoutes);
app.use('/api/files', fileRoutes);
app.use('/api/shares', shareRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/logs', logRoutes);

// Catch-all handler for any request that doesn't match an API route
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api')) {
    return next();
  }
  res.sendFile(path.join(__dirname, '../../frontend/dist/index.html'));
});

app.use((req, res) => {
  res.status(404).json({
    status: 'error',
    message: 'Route not found',
    path: req.path,
  });
});

app.use(errorMiddleware);

export default app;
