import app from './app.js';
import env from './config/env.js';

const PORT = env.PORT;
const NODE_ENV = env.NODE_ENV;

const server = app.listen(PORT, () => {
  console.log('╔════════════════════════════════════════════════════╗');
  console.log('║     ThreatVault Backend Server Started              ║');
  console.log('╠════════════════════════════════════════════════════╣');
  console.log(`║  Environment: ${NODE_ENV.padEnd(42, ' ')}║`);
  console.log(`║  Port: ${PORT}${' '.repeat(43 - PORT.toString().length)}║`);
  console.log(`║  Time: ${new Date().toLocaleString().padEnd(41, ' ')}║`);
  console.log('╠════════════════════════════════════════════════════╣');
  console.log('║  API Endpoints:                                    ║');
  console.log(`║  • Frontend:     http://localhost:${PORT}${' '.repeat(17 - PORT.toString().length)}║`);
  console.log(`║  • Health Check: http://localhost:${PORT}/api/health${' '.repeat(6 - PORT.toString().length)}║`);
  console.log(`║  • Auth: http://localhost:${PORT}/api/auth${' '.repeat(11 - PORT.toString().length)}║`);
  console.log(`║  • Users: http://localhost:${PORT}/api/users${' '.repeat(9 - PORT.toString().length)}║`);
  console.log(`║  • Files: http://localhost:${PORT}/api/files${' '.repeat(9 - PORT.toString().length)}║`);
  console.log(`║  • Share: http://localhost:${PORT}/api/share${' '.repeat(9 - PORT.toString().length)}║`);
  console.log(`║  • Admin: http://localhost:${PORT}/api/admin${' '.repeat(9 - PORT.toString().length)}║`);
  console.log(`║  • Logs: http://localhost:${PORT}/api/logs${' '.repeat(10 - PORT.toString().length)}║`);
  console.log('╚════════════════════════════════════════════════════╝');
  console.log('');
  console.log('Server is ready to receive requests...');
});

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`\n❌ Port ${PORT} is already in use.`);
    console.error(`\nSolutions:`);
    console.error(`1. Kill the process using port ${PORT}:`);
    console.error(`   • On Windows: taskkill /F /IM node.exe`);
    console.error(`   • On Mac/Linux: killall node`);
    console.error(`2. Use a different port: PORT=3000 npm run dev`);
    process.exit(1);
  } else {
    throw err;
  }
});

process.on('SIGTERM', () => {
  console.log('SIGTERM signal received: closing HTTP server');
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('SIGINT signal received: closing HTTP server');
  process.exit(0);
});
