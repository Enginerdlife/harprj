-- ThreatVault Database Schema for Supabase
-- ==========================================
-- This file documents the database tables needed for ThreatVault
-- These tables should be created in Supabase

-- ==========================================
-- TABLE: users
-- ==========================================
-- Stores user account information
-- Status: pending, active, rejected, suspended
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  name VARCHAR(255) NOT NULL,
  role_requested VARCHAR(50),
  active_role VARCHAR(50) DEFAULT 'student',
  employee_id VARCHAR(255),
  org_code VARCHAR(100),
  department VARCHAR(100),
  status VARCHAR(50) DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  last_login TIMESTAMP
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_status ON users(status);
CREATE INDEX idx_users_role ON users(active_role);

-- ==========================================
-- TABLE: employee_registry
-- ==========================================
-- Stores approved employee information for verification
-- Used during signup/approval process
CREATE TABLE IF NOT EXISTS employee_registry (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id VARCHAR(255) UNIQUE NOT NULL,
  org_code VARCHAR(100) NOT NULL,
  department VARCHAR(100) NOT NULL,
  email VARCHAR(255) NOT NULL,
  approved_role VARCHAR(50) DEFAULT 'employee',
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_employee_registry_employee_id ON employee_registry(employee_id);
CREATE INDEX idx_employee_registry_org_code ON employee_registry(org_code);

-- ==========================================
-- TABLE: files
-- ==========================================
-- Stores encrypted file metadata
-- Actual file content stored in Local File System
CREATE TABLE IF NOT EXISTS files (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  filename VARCHAR(255) NOT NULL,
  size BIGINT NOT NULL,
  iv VARCHAR(255) NOT NULL,
  encryption_key TEXT NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  storage_path VARCHAR(500) NOT NULL UNIQUE,
  failed_attempts INTEGER DEFAULT 0,
  locked_until TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_files_owner_id ON files(owner_id);
CREATE INDEX idx_files_created_at ON files(created_at);

-- ==========================================
-- TABLE: shares
-- ==========================================
-- Stores file sharing information
-- Tracks who shared what file with whom
CREATE TABLE IF NOT EXISTS shares (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  file_id UUID NOT NULL REFERENCES files(id) ON DELETE CASCADE,
  owner_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  shared_with UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token VARCHAR(255) UNIQUE,
  expires_at TIMESTAMP,
  permissions VARCHAR(100) DEFAULT 'view',
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_shares_file_id ON shares(file_id);
CREATE INDEX idx_shares_owner_id ON shares(owner_id);
CREATE INDEX idx_shares_shared_with ON shares(shared_with);
CREATE INDEX idx_shares_token ON shares(token);

-- ==========================================
-- TABLE: audit_logs
-- ==========================================
-- Immutable audit log for compliance
-- Stores all user actions for security and compliance
CREATE TABLE IF NOT EXISTS audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  action VARCHAR(100) NOT NULL,
  resource_type VARCHAR(100),
  resource_id UUID,
  metadata JSONB,
  ip_address VARCHAR(45),
  user_agent VARCHAR(500),
  timestamp TIMESTAMP DEFAULT NOW(),
  prev_hash VARCHAR(64),
  hash VARCHAR(64) NOT NULL
);

CREATE INDEX idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_action ON audit_logs(action);
CREATE INDEX idx_audit_logs_timestamp ON audit_logs(timestamp);
CREATE INDEX idx_audit_logs_resource_id ON audit_logs(resource_id);

-- ==========================================
-- STORAGE BUCKETS
-- ==========================================
-- Supabase Storage bucket for encrypted files
-- Bucket name: encrypted-files
-- Access: Private (authenticated users only)

-- ==========================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ==========================================
-- TODO: Implement RLS policies for fine-grained access control
-- Examples:
-- - Users can only see their own profile
-- - Users can only see files they own or have access to
-- - Only admins can view audit logs
-- - Only file owner can modify shares

-- ==========================================
-- FUNCTIONS (Triggers for audit logging)
-- ==========================================
-- TODO: Create triggers for automatic audit logging on file/share operations
