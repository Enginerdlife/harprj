import { db } from './firebase.js';

export const testConnection = async () => {
  try {
    console.log('[Database] Testing Firestore connection...');
    // Try to list collections to verify connection
    await db.listCollections();
    console.log('[Database] ✓ Firestore connection successful');
    return { success: true };
  } catch (error) {
    console.error('[Database] ✗ Firestore connection failed:', error.message);
    return { success: false, error };
  }
};

export default { testConnection };
