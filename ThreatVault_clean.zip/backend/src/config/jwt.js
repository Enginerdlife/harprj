import jwt from 'jsonwebtoken';
import env from './env.js';

const JWT_SECRET = env.JWT_SECRET;
const TOKEN_EXPIRY = env.JWT_EXPIRE;

export const signToken = (payload) => {
  try {
    const token = jwt.sign(payload, JWT_SECRET, {
      expiresIn: TOKEN_EXPIRY,
      algorithm: 'HS256',
    });
    return token;
  } catch (error) {
    console.error('[JWT] Error signing token:', error.message);
    throw new Error('Token signing failed');
  }
};

export const verifyToken = (token) => {
  try {
    const decoded = jwt.verify(token, JWT_SECRET, {
      algorithms: ['HS256'],
    });
    return decoded;
  } catch (error) {
    console.error('[JWT] Error verifying token:', error.message);
    if (error.name === 'TokenExpiredError') {
      throw new Error('Token expired');
    }
    if (error.name === 'JsonWebTokenError') {
      throw new Error('Invalid token');
    }
    throw error;
  }
};

export const decodeToken = (token) => {
  try {
    const decoded = jwt.decode(token);
    return decoded;
  } catch (error) {
    console.error('[JWT] Error decoding token:', error.message);
    return null;
  }
};

export default {
  signToken,
  verifyToken,
  decodeToken,
};
