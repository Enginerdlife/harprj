export const USER_ROLES = {
  ADMIN: 'admin',
  EMPLOYEE: 'employee',
  STUDENT: 'student',
  MODERATOR: 'moderator',
};

export const FILE_STATUS = {
  ACTIVE: 'active',
  ARCHIVED: 'archived',
  DELETED: 'deleted',
  SHARED: 'shared',
};

export const SHARE_STATUS = {
  PENDING: 'pending',
  APPROVED: 'approved',
  REJECTED: 'rejected',
  REVOKED: 'revoked',
};

export const ACCOUNT_STATUS = {
  ACTIVE: 'active',
  PENDING_APPROVAL: 'pending_approval',
  SUSPENDED: 'suspended',
  DISABLED: 'disabled',
};

export const HTTP_STATUS = {
  OK: 200,
  CREATED: 201,
  BAD_REQUEST: 400,
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  INTERNAL_ERROR: 500,
};

export default {
  USER_ROLES,
  FILE_STATUS,
  SHARE_STATUS,
  ACCOUNT_STATUS,
  HTTP_STATUS,
};
