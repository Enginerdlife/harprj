import pg from 'pg';
import env from './env.js';

const { Pool } = pg;

// PostgreSQL connection pool
const pool = new Pool({
    host: env.DB_HOST || 'localhost',
    port: env.DB_PORT || 5432,
    database: env.DB_NAME || 'threatvault',
    user: env.DB_USER || 'postgres',
    password: env.DB_PASSWORD || 'postgres',
    max: 20,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 2000,
});

// Test connection on startup
pool.on('connect', () => {
    console.log('[PostgreSQL] ✓ Database connection established');
});

pool.on('error', (err) => {
    console.error('[PostgreSQL] ✗ Unexpected error on idle client', err);
    process.exit(-1);
});

// Test connection
export const testConnection = async () => {
    try {
        const client = await pool.connect();
        const result = await client.query('SELECT NOW()');
        client.release();
        console.log('[PostgreSQL] ✓ Connection test successful:', result.rows[0].now);
        return { success: true };
    } catch (error) {
        console.error('[PostgreSQL] ✗ Connection test failed:', error.message);
        return { success: false, error };
    }
};

// Query helper
export const query = async (text, params) => {
    const start = Date.now();
    try {
        const res = await pool.query(text, params);
        const duration = Date.now() - start;
        console.log('[PostgreSQL] Query executed', { text: text.substring(0, 50), duration, rows: res.rowCount });
        return res;
    } catch (error) {
        console.error('[PostgreSQL] Query error:', error.message);
        throw error;
    }
};

// Transaction helper
export const transaction = async (callback) => {
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        const result = await callback(client);
        await client.query('COMMIT');
        return result;
    } catch (error) {
        await client.query('ROLLBACK');
        throw error;
    } finally {
        client.release();
    }
};

export default pool;
