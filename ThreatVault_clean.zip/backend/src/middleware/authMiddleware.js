import { verifyToken } from '../config/jwt.js';

export const authMiddleware = (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({
        status: 'error',
        message: 'Missing or invalid Authorization header',
      });
    }

    const token = authHeader.slice(7);

    const decoded = verifyToken(token);
    req.user = decoded;

    console.log(`[Auth Middleware] ✓ Token verified for user: ${decoded.email}`);
    next();
  } catch (error) {
    console.error('[Auth Middleware] ✗ Token verification failed:', error.message);

    let statusCode = 401;
    let message = 'Invalid or expired token';

    if (error.message === 'Token expired') {
      message = 'Token has expired';
      statusCode = 401;
    }

    res.status(statusCode).json({
      status: 'error',
      message,
    });
  }
};

export default authMiddleware;
