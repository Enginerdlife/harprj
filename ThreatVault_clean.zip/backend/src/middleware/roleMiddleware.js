export const roleMiddleware = (allowedRoles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        status: 'error',
        message: 'User not authenticated',
      });
    }

    const userRole = (req.user.active_role || req.user.role || '').toLowerCase();
    const normalizedAllowedRoles = allowedRoles.map(r => r.toLowerCase());

    if (!normalizedAllowedRoles.includes(userRole)) {
      console.warn(
        `[Role Middleware] ✗ Access denied for user ${req.user.email} with role ${userRole}`
      );

      return res.status(403).json({
        status: 'error',
        message: 'Access denied: insufficient permissions',
        required_roles: allowedRoles,
        user_role: userRole,
      });
    }

    console.log(`[Role Middleware] ✓ Access granted for user ${req.user.email} with role ${userRole}`);
    next();
  };
};

export default roleMiddleware;
