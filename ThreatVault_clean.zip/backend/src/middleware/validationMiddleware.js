export const validateEmail = (email) => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

export const validatePassword = (password) => {
  if (password.length < 8) {
    return { valid: false, error: 'Password must be at least 8 characters' };
  }
  if (!/[a-z]/.test(password)) {
    return { valid: false, error: 'Password must contain lowercase letters' };
  }
  if (!/[A-Z]/.test(password)) {
    return { valid: false, error: 'Password must contain uppercase letters' };
  }
  if (!/\d/.test(password)) {
    return { valid: false, error: 'Password must contain numbers' };
  }
  return { valid: true };
};

export const validateRegisterInput = (req, res, next) => {
  const { name, email, password, role, employeeId, orgCode, department } = req.body;

  const errors = [];

  if (!name || name.trim().length === 0) {
    errors.push('Name is required');
  }

  if (!email || !validateEmail(email)) {
    errors.push('Valid email is required');
  }

  if (!password) {
    errors.push('Password is required');
  } else {
    const passwordValidation = validatePassword(password);
    if (!passwordValidation.valid) {
      errors.push(passwordValidation.error);
    }
  }

  if (!role) {
    errors.push('Role is required');
  }

  if (role && role !== 'student' && role !== 'admin' && role !== 'administrator') {
    if (!employeeId) {
      errors.push('Employee ID is required for this role');
    }
    if (!orgCode) {
      errors.push('Organization code is required for this role');
    }
    if (!department) {
      errors.push('Department is required for this role');
    }
  }

  if (errors.length > 0) {
    return res.status(400).json({
      status: 'error',
      message: 'Validation failed',
      errors,
    });
  }

  next();
};

export const validateLoginInput = (req, res, next) => {
  const { email, password, role } = req.body;

  const errors = [];

  if (!email || !validateEmail(email)) {
    errors.push('Valid email is required');
  }

  if (!password) {
    errors.push('Password is required');
  }

  if (!role) {
    errors.push('Role is required');
  }

  if (errors.length > 0) {
    return res.status(400).json({
      status: 'error',
      message: 'Validation failed',
      errors,
    });
  }

  next();
};

export default {
  validateEmail,
  validatePassword,
  validateRegisterInput,
  validateLoginInput,
};
