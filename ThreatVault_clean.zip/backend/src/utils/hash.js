import bcrypt from 'bcryptjs';

const SALT_ROUNDS = 10;

export const hashPassword = async (password) => {
  try {
    const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);
    return hashedPassword;
  } catch (error) {
    console.error('[Hash] Error hashing password:', error.message);
    throw new Error('Password hashing failed');
  }
};

export const comparePassword = async (plainPassword, hashedPassword) => {
  try {
    const isMatch = await bcrypt.compare(plainPassword, hashedPassword);
    return isMatch;
  } catch (error) {
    console.error('[Hash] Error comparing password:', error.message);
    throw new Error('Password comparison failed');
  }
};

export default {
  hashPassword,
  comparePassword,
};
