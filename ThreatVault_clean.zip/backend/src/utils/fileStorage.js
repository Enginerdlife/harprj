import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Upload directory path
const UPLOAD_DIR = path.join(__dirname, '../../uploads/encrypted-files');

/**
 * Ensure upload directory exists
 */
export async function ensureUploadDir() {
    try {
        await fs.access(UPLOAD_DIR);
    } catch {
        await fs.mkdir(UPLOAD_DIR, { recursive: true });
        console.log('[FileStorage] ✓ Created upload directory:', UPLOAD_DIR);
    }
}

/**
 * Save encrypted file to local storage
 * @param {string} userId - User ID
 * @param {string} filename - Original filename
 * @param {Buffer} data - File data (encrypted)
 * @returns {Promise<string>} - Storage path
 */
export async function saveFile(userId, filename, data) {
    await ensureUploadDir();

    const userDir = path.join(UPLOAD_DIR, userId);

    // Create user directory if it doesn't exist
    try {
        await fs.access(userDir);
    } catch {
        await fs.mkdir(userDir, { recursive: true });
    }

    // Generate unique filename with timestamp
    const timestamp = Date.now();
    const sanitizedFilename = filename.replace(/[^a-zA-Z0-9.-]/g, '_');
    const storagePath = path.join(userDir, `${timestamp}_${sanitizedFilename}`);
    const relativePath = path.relative(path.join(__dirname, '../..'), storagePath);

    // Save file
    await fs.writeFile(storagePath, data);

    console.log('[FileStorage] ✓ File saved:', relativePath);
    return relativePath;
}

/**
 * Read encrypted file from local storage
 * @param {string} storagePath - Relative storage path
 * @returns {Promise<Buffer>} - File data
 */
export async function readFile(storagePath) {
    const fullPath = path.join(__dirname, '../..', storagePath);

    try {
        const data = await fs.readFile(fullPath);
        console.log('[FileStorage] ✓ File read:', storagePath);
        return data;
    } catch (error) {
        console.error('[FileStorage] ✗ Error reading file:', error.message);
        throw new Error('File not found or inaccessible');
    }
}

/**
 * Delete file from local storage
 * @param {string} storagePath - Relative storage path
 * @returns {Promise<void>}
 */
export async function deleteFile(storagePath) {
    const fullPath = path.join(__dirname, '../..', storagePath);

    try {
        await fs.unlink(fullPath);
        console.log('[FileStorage] ✓ File deleted:', storagePath);
    } catch (error) {
        console.error('[FileStorage] ✗ Error deleting file:', error.message);
        // Don't throw - file might already be deleted
    }
}

/**
 * Check if file exists
 * @param {string} storagePath - Relative storage path
 * @returns {Promise<boolean>}
 */
export async function fileExists(storagePath) {
    const fullPath = path.join(__dirname, '../..', storagePath);

    try {
        await fs.access(fullPath);
        return true;
    } catch {
        return false;
    }
}

/**
 * Get file stats
 * @param {string} storagePath - Relative storage path
 * @returns {Promise<object>}
 */
export async function getFileStats(storagePath) {
    const fullPath = path.join(__dirname, '../..', storagePath);
    return await fs.stat(fullPath);
}

export default {
    ensureUploadDir,
    saveFile,
    readFile,
    deleteFile,
    fileExists,
    getFileStats
};
