import express from 'express';
import * as fileController from '../Controller/fileController.js';
import authMiddleware from '../middleware/authMiddleware.js';

const router = express.Router();

router.use(authMiddleware);

router.get('/', fileController.getAllFiles);
router.post('/upload', fileController.uploadFile);
router.get('/:id', fileController.getFileById);
router.post('/:id/verify-password', fileController.verifyFilePassword);
router.get('/:id/download', fileController.downloadFile);
router.delete('/:id', fileController.deleteFile);

export default router;
