import express from 'express';
import * as adminController from '../Controller/adminController.js';
import authMiddleware from '../middleware/authMiddleware.js';
import roleMiddleware from '../middleware/roleMiddleware.js';

const router = express.Router();

router.use(authMiddleware);
router.use(roleMiddleware(['admin', 'administrator']));

router.get('/dashboard', adminController.getDashboard);
router.get('/pending-users', adminController.getPendingApprovals);
router.get('/approvals/pending', adminController.getPendingApprovals);
router.post('/approve/:userId', adminController.approveUser);
router.post('/reject/:userId', adminController.rejectUser);
router.post('/users/:userId/approve', adminController.approveUser);
router.post('/users/:userId/reject', adminController.rejectUser);
router.post('/users/:userId/suspend', adminController.suspendUser);

import * as logController from '../Controller/logController.js';
router.get('/logs', logController.getAllLogs);

export default router;
