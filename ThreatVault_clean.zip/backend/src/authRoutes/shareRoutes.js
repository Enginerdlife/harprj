import express from 'express';
import * as shareController from '../Controller/shareController.js';

import authMiddleware from '../middleware/authMiddleware.js';

const router = express.Router();

router.get('/', authMiddleware, shareController.getSharedFiles);
router.post('/', authMiddleware, shareController.shareFile);
router.get('/:shareId', shareController.getShareDetails); // Public
router.get('/:shareId/download', shareController.downloadSharedFile); // Public download for unlock
router.put('/:shareId/permissions', authMiddleware, shareController.updateSharePermissions);
router.delete('/:shareId', authMiddleware, shareController.revokeShare);

export default router;
