import express from 'express';
import * as userController from '../Controller/userController.js';
import authMiddleware from '../middleware/authMiddleware.js';

const router = express.Router();

router.use(authMiddleware);

router.get('/', userController.getAllUsers);
router.get('/profile', userController.getUserProfile);
router.patch('/profile', userController.updateUserProfile);
router.get('/security', (req, res) => res.status(200).json({ status: 'success', data: { twoFactorEnabled: false } }));
router.patch('/security', (req, res) => res.status(200).json({ status: 'success', message: 'Security settings updated' }));
router.post('/change-password', (req, res) => res.status(200).json({ status: 'success', message: 'Password changed successfully' }));
router.get('/:id', userController.getUserById);
router.put('/:id', userController.updateUser);
router.delete('/:id', userController.deleteUser);

export default router;
