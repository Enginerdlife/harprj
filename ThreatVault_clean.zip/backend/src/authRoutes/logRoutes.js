import express from 'express';
import * as logController from '../Controller/logController.js';
import authMiddleware from '../middleware/authMiddleware.js';

const router = express.Router();

router.use(authMiddleware);

router.get('/', logController.getAllLogs);
router.post('/', logController.createLog);
router.get('/:id', logController.getLogById);
router.get('/user/:userId', logController.getUserLogs);
router.get('/file/:fileId', logController.getFileLogs);

export default router;
