import express from 'express';
import * as authController from '../Controller/authController.js';
import { validateRegisterInput, validateLoginInput } from '../middleware/validationMiddleware.js';
import authMiddleware from '../middleware/authMiddleware.js';

const router = express.Router();

router.post('/register', validateRegisterInput, authController.signup);
router.post('/signup', validateRegisterInput, authController.signup);
router.post('/login', validateLoginInput, authController.login);
router.post('/google', authController.googleAuth);
router.post('/logout', authMiddleware, authController.logout);
router.post('/refresh-token', authMiddleware, authController.refreshToken);

// Advanced Security Features
router.get('/qr-code', authController.generateQR);
router.post('/verify-session', authController.verifyQR);
router.post('/send-otp', authController.sendOTP);
router.post('/verify-otp', authController.verifyOTP);

router.post('/setup-2fa', authMiddleware, authController.setup2FA);
router.post('/verify-2fa', authMiddleware, authController.verify2FA);

export default router;
