import { db, auth } from "../integrations/firebase-service.js";
import { doc, setDoc, serverTimestamp } from "firebase/firestore";

export const signup = async (req, res) => {
    try {

        const {
            name,
            email,
            password,
            employeeId,
            department,
            departmentNumber,
            organizationCode,
            phone,
            role
        } = req.body;

        const userRecord = await auth.createUser({
            email,
            password
        });

        await setDoc(doc(db, "users", userRecord.uid), {
            name,
            email,
            employeeId,
            department,
            departmentNumber,
            organizationCode,
            phone,

            role: role || "Employee",
            status: "pending",

            approvedBy: null,
            createdAt: serverTimestamp()
        });

        res.status(201).json({ message: "Signup Successful. Await Approval." });

    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};
