import { db, auth } from '../config/firebase.js';
import { hashPassword, verifyPassword } from '../utils/passwordHelper.js';
import { signToken } from '../config/jwt.js';
import speakeasy from 'speakeasy';
import QRCode from 'qrcode';
import nodemailer from 'nodemailer';

/* ======================================================
   SIGNUP
 ====================================================== */
export const signup = async (req, res) => {
  try {
    const {
      name,
      email,
      password,
      role,
      employeeId,
      orgCode,
      department,
      authorizationCode
    } = req.body;

    console.log(`[Auth] Signup attempt for: ${email}`);

    // If role is not student, require an authorization code (simple hardcoded check for demo)
    if (role !== 'student' && authorizationCode !== 'THREAT-VAULT-2026') {
      return res.status(401).json({
        status: 'error',
        message: 'Invalid or missing Authorization Code'
      });
    }

    const normalizedEmail = email.toLowerCase();

    /* ---------- Check Existing User ---------- */
    const snapshot = await db.collection('users').where('email', '==', normalizedEmail).get();

    if (!snapshot.empty) {
      return res.status(400).json({
        status: 'error',
        message: 'Email already registered'
      });
    }

    /* ---------- Default Status ---------- */
    let status = 'pending';
    let active_role = null;

    // Even if they request administrator, they MUST be pending
    if (role === 'student') {
        status = 'active';
        active_role = 'student';
    }

    /* ---------- Password Hash ---------- */
    const password_hash = await hashPassword(password);

    /* ---------- User Record ---------- */
    const userRef = await db.collection('users').add({
      name,
      email: normalizedEmail,
      password_hash,
      role_requested: role,
      active_role,
      employee_id: employeeId,
      org_code: orgCode,
      department,
      status,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    });

    console.log(`[Auth] ✓ User Registered → Pending Approval: ${userRef.id}`);

    // Notify Admin via Email
    try {
      const transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST || 'smtp.gmail.com',
        port: process.env.SMTP_PORT || 587,
        secure: false,
        auth: {
          user: process.env.SMTP_USER,
          pass: process.env.SMTP_PASS,
        },
      });

      const baseUrl = process.env.VITE_APP_URL || 'http://localhost:5173';
      const approveLink = `${baseUrl}/admin/approval-action?userId=${userRef.id}&action=approve`;
      const rejectLink = `${baseUrl}/admin/approval-action?userId=${userRef.id}&action=reject`;

      const mailOptions = {
        from: process.env.SMTP_FROM || '"ThreatVault Notifications" <no-reply@threatvault.app>',
        to: process.env.ADMIN_EMAIL || process.env.SMTP_USER,
        subject: 'Action Required: New User Signup - ThreatVault',
        html: `
          <div style="font-family: Arial, sans-serif; padding: 20px; color: #333; max-width: 600px; border: 1px solid #e5e7eb; border-radius: 12px;">
            <h2 style="color: #2563eb;">New User Approval Requested</h2>
            <p>A new user has registered for ThreatVault and is awaiting your approval.</p>
            
            <div style="background: #f9fafb; padding: 15px; border-radius: 8px; margin: 20px 0;">
              <p style="margin: 5px 0;"><strong>Name:</strong> ${name}</p>
              <p style="margin: 5px 0;"><strong>Email:</strong> ${normalizedEmail}</p>
              <p style="margin: 5px 0;"><strong>Role Requested:</strong> ${role}</p>
              <p style="margin: 5px 0;"><strong>Department:</strong> ${department || 'N/A'}</p>
            </div>
            
            <p>You can approve or reject this user directly from this email:</p>
            
            <div style="margin-top: 25px;">
              <a href="${approveLink}" style="display: inline-block; background: #059669; color: #fff; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: bold; margin-right: 15px;">Approve User</a>
              <a href="${rejectLink}" style="display: inline-block; background: #dc2626; color: #fff; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: bold;">Reject User</a>
            </div>
            
            <p style="font-size: 12px; color: #666; margin-top: 30px; border-top: 1px solid #eee; pt: 10px;">
              This is an automated notification from ThreatVault Security.
            </p>
          </div>
        `
      };

      if (process.env.SMTP_USER) {
        await transporter.sendMail(mailOptions);
      }
    } catch (emailErr) {
      console.error('Failed to send admin notification email:', emailErr);
    }

    res.status(201).json({
      status: 'success',
      message: role === 'student' ? 'Account created. You can now log in.' : 'Account created. Awaiting Admin/HR approval.',
      data: {
        userId: userRef.id,
        email,
        status
      }
    });
  } catch (error) {
    console.error('[Auth] Signup error:', error);
    res.status(500).json({ status: 'error', message: 'Signup failed' });
  }
};

/* ======================================================
   LOGIN
 ====================================================== */
export const login = async (req, res) => {
  try {
    const { email, password, code } = req.body;

    console.log(`[Auth] Login attempt for: ${email}`);

    const snapshot = await db.collection('users').where('email', '==', email).limit(1).get();

    if (snapshot.empty) {
      return res.status(401).json({
        status: 'error',
        message: 'Invalid email or password'
      });
    }

    const userDoc = snapshot.docs[0];
    const user = { id: userDoc.id, ...userDoc.data() };

    /* ---------- Password Check ---------- */
    const isMatch = await verifyPassword(password, user.password_hash);

    if (!isMatch) {
      return res.status(401).json({
        status: 'error',
        message: 'Invalid email or password'
      });
    }

    /* ---------- Status Checks ---------- */
    if (user.status === 'pending') {
      return res.status(403).json({
        status: 'error',
        message: 'Account awaiting approval'
      });
    }

    if (user.status === 'rejected') {
      return res.status(403).json({
        status: 'error',
        message: 'Account rejected'
      });
    }

    if (user.status === 'suspended') {
      return res.status(403).json({
        status: 'error',
        message: 'Account suspended'
      });
    }

    /* ---------- Role Activated Check ---------- */
    if (!user.active_role) {
      return res.status(403).json({
        status: 'error',
        message: 'Role not activated yet'
      });
    }

    /* ---------- 2FA FLOW ---------- */
    if (user.two_factor_enabled) {
      if (!code) {
        return res.status(200).json({
          status: '2fa_required',
          message: 'MFA is required for this account.',
          data: { email, method: user.two_factor_method || 'mfa_required' }
        });
      }

      // If user has traditional 2FA enabled
      if (user.two_factor_enabled && user.two_factor_secret) {
        const verified = speakeasy.totp.verify({
          secret: user.two_factor_secret,
          encoding: 'base32',
          token: code,
          window: 1
        });

        if (!verified) {
          return res.status(401).json({
            status: 'error',
            message: 'Invalid MFA code'
          });
        }
      } else {
        // Handle mandatory Admin MFA verification if no traditional 2FA set
        // For simplicity in this demo, we'll check against a recently generated OTP or session code
        // In a real app, you'd verify against the specific method requested
        const mfaSnapshot = await db.collection('mfa_codes')
          .where('email', '==', email)
          .where('code', '==', code)
          .where('expires_at', '>', new Date().toISOString())
          .get();

        if (mfaSnapshot.empty) {
          return res.status(401).json({
            status: 'error',
            message: 'Invalid or expired MFA code'
          });
        }
        // Cleanup code
        await mfaSnapshot.docs[0].ref.delete();
      }
    }

    /* ---------- Update Last Login ---------- */
    await userDoc.ref.update({ last_login: new Date().toISOString() });

    /* ---------- JWT TOKEN ---------- */
    const token = signToken({
      id: user.id,
      email: user.email,
      active_role: user.active_role,
      name: user.name
    });

    res.status(200).json({
      status: 'success',
      message: 'Login successful',
      data: {
        token,
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          activeRole: user.active_role.toLowerCase() === 'admin' || user.active_role.toLowerCase() === 'administrator' ? 'administrator' : user.active_role,
          status: user.status
        }
      }
    });

  } catch (error) {
    console.error('[Auth] Login error:', error);
    res.status(500).json({ status: 'error', message: 'Login failed' });
  }
};

/* ======================================================
   ADVANCED SECURITY: QR & OTP
   ====================================================== */

export const generateQR = async (req, res) => {
  try {
    const sessionToken = Math.random().toString(36).substring(2, 10).toUpperCase();
    const expiresAt = new Date(Date.now() + 120 * 1000).toISOString(); // 2 mins

    // Return just the code in the QR, not JSON, so generic scanners pick it up correctly
    const qrImage = await QRCode.toDataURL(sessionToken);

    await db.collection('session_codes').add({
      token: sessionToken,
      expires_at: expiresAt,
      created_at: new Date().toISOString()
    });

    res.json({
      status: 'success',
      data: {
        qrCode: qrImage,
        code: sessionToken, // For testing/simulated scanning
        expiresAt
      }
    });
  } catch (error) {
    console.error('[Auth] QR Generation error:', error);
    res.status(500).json({ message: 'Failed to generate QR' });
  }
};

export const verifyQR = async (req, res) => {
  try {
    const { code } = req.body;
    const snapshot = await db.collection('session_codes')
      .where('token', '==', code)
      .where('expires_at', '>', new Date().toISOString())
      .limit(1)
      .get();

    if (snapshot.empty) {
      return res.status(400).json({ status: 'error', message: 'Invalid or expired session code' });
    }

    res.json({ status: 'success', message: 'Session verified' });
  } catch (error) {
    console.error('[Auth] QR Verification error:', error);
    res.status(500).json({ message: 'Verification failed' });
  }
};

export const sendOTP = async (req, res) => {
  try {
    const { email, phoneNumber } = req.body;
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000).toISOString(); // 5 mins

    console.log(`[Auth] Generating OTP for ${email}: ${otp}`);

    await db.collection('mfa_codes').add({
      email,
      code: otp,
      expires_at: expiresAt,
      created_at: new Date().toISOString()
    });

    // In a real app, use Twilio or similar to send SMS to phoneNumber
    // For now, we simulate success
    res.json({ status: 'success', message: `OTP sent to ${phoneNumber || email}`, code: otp });
  } catch (error) {
    console.error('[Auth] OTP Send error:', error);
    res.status(500).json({ message: 'Failed to send OTP' });
  }
};

export const verifyOTP = async (req, res) => {
  try {
    const { email, code } = req.body;
    const snapshot = await db.collection('mfa_codes')
      .where('email', '==', email)
      .where('code', '==', code)
      .where('expires_at', '>', new Date().toISOString())
      .get();

    if (snapshot.empty) {
      return res.status(400).json({ status: 'error', message: 'Invalid or expired OTP' });
    }

    // Cleanup
    await snapshot.docs[0].ref.delete();

    res.json({ status: 'success', message: 'OTP verified' });
  } catch (error) {
    console.error('[Auth] OTP Verification error:', error);
    res.status(500).json({ message: 'Verification failed' });
  }
};

/* ======================================================
   LOGOUT
   ====================================================== */
export const logout = async (req, res) => {
  res.status(200).json({
    status: 'success',
    message: 'Logged out successfully'
  });
};

/* ======================================================
   REFRESH TOKEN
   ====================================================== */
export const refreshToken = async (req, res) => {
  if (!req.user) {
    return res.status(401).json({ message: 'Not authenticated' });
  }

  const newToken = signToken({
    id: req.user.id,
    email: req.user.email,
    active_role: req.user.active_role,
    name: req.user.name
  });

  res.json({ token: newToken });
};

/* ======================================================
   2FA SETUP
   ====================================================== */
export const setup2FA = async (req, res) => {
  try {
    const email = req.user.email;
    const { method, phoneNumber } = req.body;

    const secret = speakeasy.generateSecret({
      length: 20,
      name: `ThreatVault (${email})`
    });

    if (method === 'sms') {
      return res.json({
        method: 'sms',
        secret: secret.base32,
        phoneNumber
      });
    } else {
      const qrCode = await QRCode.toDataURL(secret.otpauth_url);
      return res.json({
        method: 'app',
        secret: secret.base32,
        qrCode
      });
    }
  } catch (error) {
    console.error('[Auth] 2FA Setup error:', error);
    res.status(500).json({ message: '2FA setup failed' });
  }
};

/* ======================================================
   2FA VERIFY
   ====================================================== */
export const verify2FA = async (req, res) => {
  try {
    const { code, secret, method, phoneNumber } = req.body;

    const verified = speakeasy.totp.verify({
      secret,
      encoding: 'base32',
      token: code,
      window: 1
    });

    if (!verified) {
      return res.status(400).json({ message: 'Invalid code' });
    }

    await db.collection('users').doc(req.user.id).update({
      two_factor_enabled: true,
      two_factor_secret: secret,
      two_factor_method: method,
      phone_number: phoneNumber || null,
      updated_at: new Date().toISOString()
    });

    res.json({ message: '2FA Enabled' });
  } catch (error) {
    console.error('[Auth] 2FA Verify error:', error);
    res.status(500).json({ message: '2FA verification failed' });
  }
};

export const googleAuth = async (req, res) => {
  try {
    const { token } = req.body;
    let email, name, googleId;

    // Simulate Google Verification for Demo/Dev
    if (token === 'mock_token') {
      email = 'google_user@gmail.com';
      name = 'Google User';
      googleId = 'mock_google_id_123';
    } else {
      // In production, verify actual Google Token here
      // const ticket = await client.verifyIdToken(...)
      return res.status(400).json({ message: 'Invalid token' });
    }

    // Check if user exists
    const snapshot = await db.collection('users').where('email', '==', email).limit(1).get();
    let user;

    if (snapshot.empty) {
      // Create new user
      const newUser = {
        name,
        email,
        password_hash: null, // No password for OAuth
        role_requested: 'employee',
        active_role: 'employee', // Auto-activate for demo
        status: 'active',
        auth_provider: 'google',
        google_id: googleId,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        last_login: new Date().toISOString()
      };

      const ref = await db.collection('users').add(newUser);
      user = { id: ref.id, ...newUser };
    } else {
      // Update existing
      const doc = snapshot.docs[0];
      await doc.ref.update({ last_login: new Date().toISOString() });
      user = { id: doc.id, ...doc.data() };
    }

    const jwtToken = signToken({
      id: user.id,
      email: user.email,
      active_role: user.active_role,
      name: user.name
    });

    res.status(200).json({
      status: 'success',
      data: {
        token: jwtToken,
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          activeRole: user.active_role,
          status: user.status
        }
      }
    });

  } catch (error) {
    console.error('[Auth] Google Login Error:', error);
    res.status(500).json({ message: 'Google login failed' });
  }
};

export default {
  signup,
  login,
  logout,
  refreshToken,
  setup2FA,
  verify2FA,
  generateQR,
  verifyQR,
  sendOTP,
  verifyOTP,
  googleAuth
};
