import { db } from '../config/firebase.js';

export const getAllLogs = async (req, res) => {
  try {
    const snapshot = await db.collection('audit_logs')
      .orderBy('timestamp', 'desc')
      .limit(100)
      .get();
    
    const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

    res.status(200).json({
      status: 'success',
      data: data,
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error.message,
    });
  }
};

export const getLogById = async (req, res) => {
  try {
    const { id } = req.params;
    const doc = await db.collection('audit_logs').doc(id).get();

    if (!doc.exists) {
      return res.status(404).json({ status: 'error', message: 'Log not found' });
    }

    res.status(200).json({
      status: 'success',
      data: { id: doc.id, ...doc.data() },
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error.message,
    });
  }
};

export const getUserLogs = async (req, res) => {
  try {
    const { userId } = req.params;
    const snapshot = await db.collection('audit_logs')
      .where('user_id', '==', userId)
      .orderBy('timestamp', 'desc')
      .get();
    
    const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

    res.status(200).json({
      status: 'success',
      data: data,
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error.message,
    });
  }
};

export const getFileLogs = async (req, res) => {
  try {
    const { fileId } = req.params;
    const snapshot = await db.collection('audit_logs')
      .where('file_id', '==', fileId)
      .orderBy('timestamp', 'desc')
      .get();
    
    const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

    res.status(200).json({
      status: 'success',
      data: data,
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error.message,
    });
  }
};

export const createLog = async (req, res) => {
  try {
    const { action, userId, fileId, details, ipAddress } = req.body;
    
    const logData = {
      action,
      user_id: userId || req.user?.id,
      file_id: fileId,
      details,
      ip_address: ipAddress || req.ip,
      timestamp: new Date().toISOString(),
    };

    const docRef = await db.collection('audit_logs').add(logData);

    res.status(201).json({
      status: 'success',
      data: { id: docRef.id, ...logData },
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error.message,
    });
  }
};

export default {
  getAllLogs,
  getLogById,
  getUserLogs,
  getFileLogs,
  createLog,
};
