import { db } from '../config/firebase.js';
import * as fileStorage from '../utils/fileStorage.js';
import nodemailer from 'nodemailer';

// Helper for file size
const formatFileSize = (bytes) => {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

const isLocalhostUrl = (url = '') => {
  return /^(https?:\/\/)?(localhost|127(?:\.0\.0\.1)?)(:\d+)?$/i.test(url.replace(/\/$/, ''));
};

const getPublicBaseUrl = (req) => {
  const envUrl = process.env.VITE_APP_URL?.trim();
  if (envUrl) {
    return envUrl.replace(/\/$/, '');
  }

  const requestOrigin = req.get('origin') || req.get('referer');
  if (requestOrigin) {
    return requestOrigin.replace(/\/$/, '');
  }

  const hostHeader = req.get('host');
  if (hostHeader) {
    const protocol = req.protocol || 'http';
    return `${protocol}://${hostHeader}`.replace(/\/$/, '');
  }

  return null;
};

// Helper to map DB file to Frontend EncryptedFile format
const mapFileToFrontend = (file) => {
  if (!file) return null;

  let extraData = {};
  try {
    if (typeof file.encryption_key === 'object' && file.encryption_key !== null) {
      extraData = file.encryption_key;
    } else if (typeof file.encryption_key === 'string' && file.encryption_key.trim().startsWith('{')) {
      extraData = JSON.parse(file.encryption_key);
    } else {
      extraData = { encryptedKey: file.encryption_key };
    }
  } catch (e) {
    extraData = { encryptedKey: file.encryption_key };
  }

  return {
    id: file.id || file.docId,
    name: file.filename,
    size: parseInt(file.size),
    type: extraData.type || 'application/octet-stream',
    createdAt: file.created_at,
    updatedAt: file.updated_at,
    iv: file.iv,
    encryptedKey: extraData.encryptedKey || file.encryption_key,
    encryptedData: '',
    salt: extraData.salt,
    keyIv: extraData.keyIv,
    protectionMethod: extraData.protectionMethod || 'password'
  };
};

export const getSharedFiles = async (req, res) => {
  try {
    const userId = req.user.id;
    const snapshot = await db.collection('shares')
      .where('shared_with', '==', userId)
      .get();

    const shares = [];
    for (const doc of snapshot.docs) {
      const shareData = doc.data();

      // If expired, skip
      if (new Date(shareData.expires_at) < new Date()) continue;

      // Fetch file details
      const fileDoc = await db.collection('files').doc(shareData.file_id).get();
      if (!fileDoc.exists) continue;

      const fileData = fileDoc.data();

      shares.push({
        id: doc.id,
        file_id: shareData.file_id,
        owner_id: shareData.owner_id,
        shared_with: shareData.shared_with,
        token: shareData.token,
        expires_at: shareData.expires_at,
        permissions: shareData.permissions,
        created_at: shareData.created_at,
        file: mapFileToFrontend({ id: fileDoc.id, ...fileData })
      });
    }

    res.status(200).json({
      status: 'success',
      data: shares,
    });
  } catch (error) {
    console.error('[ShareController] GetSharedFiles error:', error);
    res.status(500).json({
      status: 'error',
      message: error.message,
    });
  }
};

export const shareFile = async (req, res) => {
  try {
    const { fileId, recipientEmail, expiresIn } = req.body;
    const normalizedEmail = recipientEmail.toLowerCase();

    // 1. Find recipient user if exists
    const userSnapshot = await db.collection('users').where('email', '==', normalizedEmail).limit(1).get();

    let recipientId = null;
    if (!userSnapshot.empty) {
      recipientId = userSnapshot.docs[0].id;
    }
    const token = Math.random().toString(36).substring(2) + Math.random().toString(36).substring(2);
    const expiresAt = new Date(Date.now() + expiresIn * 3600 * 1000).toISOString();

    const shareRef = await db.collection('shares').add({
      file_id: fileId,
      owner_id: req.user.id,
      shared_with: recipientId,
      recipient_email: recipientEmail,
      token,
      expires_at: expiresAt,
      permissions: 'view',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    });

    const savedShareDoc = await shareRef.get();
    const savedShare = { id: savedShareDoc.id, ...savedShareDoc.data() };

    // Use the origin from the request (e.g. the tunnel URL) if available, otherwise fallback to env or localhost
    const baseUrl = getPublicBaseUrl(req);
    const effectiveBaseUrl = baseUrl || `${req.protocol || 'http'}://${req.get('host') || 'localhost'}`;
    if (!baseUrl) {
      console.warn(`[ShareController] No explicit public share URL configured. Falling back to ${effectiveBaseUrl}. This may not be externally reachable if the app is running locally.`);
    }

    const link = `${effectiveBaseUrl}/share/${savedShare.id}`;

    // Fetch file details for email
    const fileDoc = await db.collection('files').doc(fileId).get();
    const fileData = fileDoc.data();
    const filename = fileData ? fileData.filename : 'Unknown File';
    const fileSize = fileData ? formatFileSize(fileData.size) : 'Unknown Size';

    // Send Email
    if (process.env.SMTP_USER && process.env.SMTP_PASS) {
      try {
        const transporter = nodemailer.createTransport({
          host: process.env.SMTP_HOST || 'smtp.gmail.com',
          port: parseInt(process.env.SMTP_PORT) || 587,
          secure: false, // true for 465, false for other ports
          auth: {
            user: process.env.SMTP_USER,
            pass: process.env.SMTP_PASS,
          },
        });

        const mailOptions = {
          from: process.env.SMTP_FROM || '"ThreatVault Secure Share" <no-reply@threatvault.app>',
          to: recipientEmail,
          subject: 'You have received a secure encrypted file - ThreatVault',
          html: `
            <div style="font-family: Arial, sans-serif; padding: 20px; color: #333; max-width: 600px; margin: 0 auto; border: 1px solid #e5e7eb; border-radius: 8px;">
              <h2 style="color: #2563eb; text-align: center;">Secure File Shared</h2>
              <p><strong>${req.user.name || req.user.email}</strong> has shared a secure encrypted file with you.</p>
              
              <div style="background: #f9fafb; padding: 20px; border-radius: 8px; margin: 20px 0; border: 1px solid #e5e7eb;">
                <h3 style="margin-top: 0; color: #374151; font-size: 16px;">File Details</h3>
                <table style="width: 100%; border-collapse: collapse;">
                  <tr>
                    <td style="padding: 8px 0; color: #6b7280; width: 100px;">File Name:</td>
                    <td style="padding: 8px 0; font-weight: 500; color: #111827;">${filename}</td>
                  </tr>
                  <tr>
                    <td style="padding: 8px 0; color: #6b7280;">Size:</td>
                    <td style="padding: 8px 0; font-weight: 500; color: #111827;">${fileSize}</td>
                  </tr>
                  <tr>
                    <td style="padding: 8px 0; color: #6b7280;">Date Sent:</td>
                    <td style="padding: 8px 0; font-weight: 500; color: #111827;">${new Date().toLocaleString()}</td>
                  </tr>
                  <tr>
                    <td style="padding: 8px 0; color: #6b7280;">Expires:</td>
                    <td style="padding: 8px 0; font-weight: 500; color: #ef4444;">${new Date(expiresAt).toLocaleString()}</td>
                  </tr>
                </table>
              </div>

              <div style="text-align: center; margin: 30px 0;">
                <a href="${link}" style="background: #2563eb; color: #fff; padding: 14px 28px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block;">Access Secure File</a>
              </div>

              <p style="font-size: 12px; color: #9ca3af; text-align: center; margin-top: 30px; border-top: 1px solid #e5e7eb; padding-top: 20px;">
                This link is secure and intented only for ${recipientEmail}.<br>
                ThreatVault &copy; ${new Date().getFullYear()}
              </p>
            </div>
          `
        };

        const info = await transporter.sendMail(mailOptions);
        console.log(`[ShareController] ✓ Email sent to ${recipientEmail}: ${info.messageId}`);
      } catch (emailErr) {
        console.error('[ShareController] ✗ Failed to send share email:', emailErr);
        // We don't fail the request, but we log the error
      }
    } else {
      console.warn('[ShareController] ⚠ SMTP configuration missing. Email was NOT sent to:', recipientEmail);
      console.warn('  > Please set SMTP_USER and SMTP_PASS in .env to enable email notifications.');
    }

    // --- TRANSACTION HISTORY LOGGING ---
    try {
      await db.collection('audit_logs').add({
        action: 'FILE_SHARED',
        user_id: req.user.id,
        user_email: req.user.email,
        file_id: fileId,
        file_name: filename,
        recipient_email: recipientEmail,
        timestamp: new Date().toISOString(),
        details: `File "${filename}" (${fileSize}) shared with ${recipientEmail}`,
        ip_address: req.ip || req.connection.remoteAddress
      });
      console.log(`[ShareController] ✓ Transaction logged for file share: ${filename}`);
    } catch (logErr) {
      console.error('[ShareController] ✗ Failed to log transaction:', logErr);
    }

    res.status(201).json({
      status: 'success',
      data: { ...savedShare, link },
    });
  } catch (error) {
    console.error('[ShareController] ShareFile error:', error);
    res.status(500).json({
      status: 'error',
      message: error.message,
    });
  }
};

export const revokeShare = async (req, res) => {
  try {
    const { shareId } = req.params;

    const shareRef = db.collection('shares').doc(shareId);
    const shareDoc = await shareRef.get();

    if (!shareDoc.exists || shareDoc.data().owner_id !== req.user.id) {
      return res.status(404).json({ status: 'error', message: 'Share not found or access denied' });
    }

    await shareRef.delete();

    res.status(200).json({
      status: 'success',
      message: 'Share revoked successfully',
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error.message,
    });
  }
};

export const updateSharePermissions = async (req, res) => {
  res.status(501).json({ message: 'Not implemented' });
};

export const getShareDetails = async (req, res) => {
  try {
    const { shareId } = req.params;

    const shareDoc = await db.collection('shares').doc(shareId).get();

    if (!shareDoc.exists) {
      return res.status(404).json({ status: 'error', message: 'Share not found' });
    }

    const shareData = shareDoc.data();

    if (new Date(shareData.expires_at) < new Date()) {
      return res.status(410).json({ status: 'error', message: 'Share link expired' });
    }

    const fileDoc = await db.collection('files').doc(shareData.file_id).get();
    if (!fileDoc.exists) {
      return res.status(404).json({ status: 'error', message: 'File not found' });
    }

    res.status(200).json({
      status: 'success',
      data: {
        id: shareDoc.id,
        ...shareData,
        file: mapFileToFrontend({ id: fileDoc.id, ...fileDoc.data() })
      },
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error.message,
    });
  }
};

export const downloadSharedFile = async (req, res) => {
  try {
    const { shareId } = req.params;

    const shareDoc = await db.collection('shares').doc(shareId).get();

    if (!shareDoc.exists) {
      return res.status(404).json({ status: 'error', message: 'Share not found' });
    }

    const shareData = shareDoc.data();

    if (new Date(shareData.expires_at) < new Date()) {
      return res.status(410).json({ status: 'error', message: 'Share link expired' });
    }

    const fileDoc = await db.collection('files').doc(shareData.file_id).get();
    if (!fileDoc.exists) {
      return res.status(404).json({ status: 'error', message: 'File not found' });
    }

    const fileData = fileDoc.data();
    const fileBuffer = await fileStorage.readFile(fileData.storage_path);
    const base64Data = fileBuffer.toString('base64');

    res.status(200).json({
      status: 'success',
      data: {
        encryptedData: base64Data
      }
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error.message,
    });
  }
};

export default {
  getSharedFiles,
  shareFile,
  revokeShare,
  updateSharePermissions,
  getShareDetails,
  downloadSharedFile,
};
