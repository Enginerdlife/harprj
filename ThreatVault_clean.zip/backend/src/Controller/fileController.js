import { db } from '../config/firebase.js';
import { hashPassword, verifyPassword } from '../utils/passwordHelper.js';
import * as fileStorage from '../utils/fileStorage.js';

// Helper to map DB file to Frontend format
const mapFileToFrontend = (file) => {
  if (!file) return null;

  let extraData = {};
  try {
    if (typeof file.encryption_key === 'object' && file.encryption_key !== null) {
      extraData = file.encryption_key;
    } else if (typeof file.encryption_key === 'string' && file.encryption_key.trim().startsWith('{')) {
      extraData = JSON.parse(file.encryption_key);
    }
  } catch (e) {
    console.error("[DEBUG] Error parsing encryption_key:", e);
  }

  return {
    id: file.id,
    name: file.filename,
    size: parseInt(file.size),
    type: extraData.type || 'application/octet-stream',
    createdAt: file.created_at,
    updatedAt: file.updated_at,
    iv: file.iv,
    salt: extraData.salt || file.salt, // Direct password derivation salt
    protectionMethod: 'password',
    isLocked: file.locked_until && new Date(file.locked_until) > new Date(),
    ownerId: file.owner_id
  };
};

export const getAllFiles = async (req, res) => {
  try {
    const userId = req.user.id;
    const userRole = req.user.active_role;

    console.log(`[FileController] GET ALL FILES. User: ${userId}, Role: ${userRole}`);

    let snapshot;
    if (userRole === 'admin' || userRole === 'administrator') {
      // Admin sees everything
      snapshot = await db.collection('files').orderBy('created_at', 'desc').get();
    } else {
      // Regular user sees only their files
      snapshot = await db.collection('files')
        .where('owner_id', '==', userId)
        .orderBy('created_at', 'desc')
        .get();
    }

    const files = [];
    snapshot.forEach(doc => {
      files.push(mapFileToFrontend({ id: doc.id, ...doc.data() }));
    });

    res.status(200).json({
      status: 'success',
      data: files,
    });
  } catch (error) {
    console.error('Get all files error:', error);
    res.status(500).json({
      status: 'error',
      message: error.message,
    });
  }
};

export const getFileById = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;
    const userRole = req.user.active_role;

    // Check if shared
    const shareSnapshot = await db.collection('shares')
      .where('file_id', '==', id)
      .where('shared_with', '==', userId)
      .limit(1)
      .get();

    const isShared = !shareSnapshot.empty;

    const fileDoc = await db.collection('files').doc(id).get();

    if (!fileDoc.exists) {
      return res.status(404).json({ status: 'error', message: 'File not found' });
    }

    const file = { id: fileDoc.id, ...fileDoc.data() };

    // Access control: Owner, Admin, or Shared
    const isOwner = file.owner_id === userId;
    const isAdmin = userRole === 'admin' || userRole === 'administrator';

    if (!isShared && !isOwner && !isAdmin) {
      return res.status(403).json({ status: 'error', message: 'Access denied' });
    }

    res.status(200).json({
      status: 'success',
      data: mapFileToFrontend(file),
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error.message,
    });
  }
};

export const uploadFile = async (req, res) => {
  try {
    const {
      name,
      size,
      type,
      iv,
      salt,
      encryptedData,
      encryptionPassword  // Used only for hashing, NOT stored
    } = req.body;

    if (!encryptedData) {
      return res.status(400).json({ status: 'error', message: 'No file data' });
    }

    if (!encryptionPassword) {
      return res.status(400).json({ status: 'error', message: 'Encryption password is required' });
    }

    // Hash the encryption password for verification
    const passwordHash = await hashPassword(encryptionPassword);

    // Save file to local storage
    const fileBuffer = Buffer.from(encryptedData, 'base64');
    const storagePath = await fileStorage.saveFile(req.user.id, name, fileBuffer);

    // Store metadata in encryption_key (JSON)
    const metadata = {
      salt,
      type
    };

    const userId = req.user.id;

    const fileRef = await db.collection('files').add({
      owner_id: userId,
      filename: name,
      size: size,
      iv: iv,
      encryption_key: metadata,
      password_hash: passwordHash,
      storage_path: storagePath,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    });

    const savedFileDoc = await fileRef.get();
    const savedFile = { id: savedFileDoc.id, ...savedFileDoc.data() };

    res.status(201).json({
      status: 'success',
      data: mapFileToFrontend(savedFile),
    });
  } catch (error) {
    console.error('[FileController] Upload error:', error);
    res.status(500).json({
      status: 'error',
      message: error.message,
    });
  }
};

export const verifyFilePassword = async (req, res) => {
  try {
    const { id } = req.params;
    const { password } = req.body;

    if (!password) {
      return res.status(400).json({ status: 'error', message: 'Password is required' });
    }

    const fileDoc = await db.collection('files').doc(id).get();

    if (!fileDoc.exists) {
      return res.status(404).json({ status: 'error', message: 'File not found' });
    }

    const file = fileDoc.data();

    if (file.locked_until && new Date(file.locked_until) > new Date()) {
      const remainingTime = Math.ceil((new Date(file.locked_until) - new Date()) / 1000 / 60);
      return res.status(429).json({
        status: 'error',
        message: `Too many failed attempts. File is locked for ${remainingTime} more minute(s).`,
        locked: true,
        lockedUntil: file.locked_until
      });
    }

    const isValid = await verifyPassword(password, file.password_hash);

    if (!isValid) {
      const newFailedAttempts = (file.failed_attempts || 0) + 1;
      let lockedUntil = null;

      if (newFailedAttempts >= 5) {
        lockedUntil = new Date(Date.now() + 5 * 60 * 1000).toISOString();
      }

      await fileDoc.ref.update({
        failed_attempts: newFailedAttempts,
        locked_until: lockedUntil
      });

      return res.status(401).json({
        status: 'error',
        message: 'Invalid password',
        valid: false,
        remainingAttempts: Math.max(0, 5 - newFailedAttempts),
        locked: lockedUntil !== null
      });
    }

    await fileDoc.ref.update({
      failed_attempts: 0,
      locked_until: null
    });

    res.status(200).json({
      status: 'success',
      valid: true,
      message: 'Password verified successfully'
    });

  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error.message,
    });
  }
};

export const downloadFile = async (req, res) => {
  try {
    const { id } = req.params;

    const fileDoc = await db.collection('files').doc(id).get();

    if (!fileDoc.exists) {
      return res.status(404).json({ status: 'error', message: 'File not found' });
    }

    const file = { id: fileDoc.id, ...fileDoc.data() };
    const fileBuffer = await fileStorage.readFile(file.storage_path);
    const base64Data = fileBuffer.toString('base64');

    const mappedFile = mapFileToFrontend(file);
    mappedFile.encryptedData = base64Data;

    res.status(200).json({
      status: 'success',
      data: mappedFile,
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error.message,
    });
  }
};

export const deleteFile = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;
    const userRole = req.user.active_role;

    const fileDoc = await db.collection('files').doc(id).get();

    if (!fileDoc.exists) {
      return res.status(404).json({ status: 'error', message: 'File not found' });
    }

    const file = fileDoc.data();

    // Only owner or admin can delete
    if (file.owner_id !== userId && userRole !== 'admin' && userRole !== 'administrator') {
      return res.status(403).json({ status: 'error', message: 'Access denied' });
    }

    await fileStorage.deleteFile(file.storage_path);
    await fileDoc.ref.delete();

    res.status(200).json({
      status: 'success',
      message: 'File deleted',
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error.message,
    });
  }
};

export default {
  getAllFiles,
  getFileById,
  uploadFile,
  verifyFilePassword,
  downloadFile,
  deleteFile,
};
