import { db } from '../config/firebase.js';

export const getDashboard = async (req, res) => {
  try {
    const [usersSnapshot, filesSnapshot, sharesSnapshot, pendingSnapshot] = await Promise.all([
      db.collection('users').get(),
      db.collection('files').get(),
      db.collection('shares').get(),
      db.collection('users').where('status', '==', 'pending').get()
    ]);

    res.status(200).json({
      status: 'success',
      data: {
        totalUsers: usersSnapshot.size,
        totalFiles: filesSnapshot.size,
        totalShares: sharesSnapshot.size,
        pendingApprovals: pendingSnapshot.size,
      },
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error.message,
    });
  }
};

export const approveUser = async (req, res) => {
  try {
    const { userId } = req.params;

    const userDoc = await db.collection('users').doc(userId).get();

    if (!userDoc.exists) {
      return res.status(404).json({ status: 'error', message: 'User not found' });
    }

    const userData = userDoc.data();
    let finalRole = userData.role_requested || 'employee';
    if (finalRole === 'admin') finalRole = 'administrator';

    await userDoc.ref.update({
      status: 'active',
      active_role: finalRole,
      updated_at: new Date().toISOString()
    });

    res.status(200).json({
      status: 'success',
      message: 'User account approved successfully',
      data: { userId },
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error.message,
    });
  }
};

export const rejectUser = async (req, res) => {
  try {
    const { userId } = req.params;

    await db.collection('users').doc(userId).update({
      status: 'rejected',
      updated_at: new Date().toISOString()
    });

    res.status(200).json({
      status: 'success',
      message: 'User account rejected',
      data: { userId },
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error.message,
    });
  }
};

export const suspendUser = async (req, res) => {
  try {
    const { userId } = req.params;

    await db.collection('users').doc(userId).update({
      status: 'suspended',
      updated_at: new Date().toISOString()
    });

    res.status(200).json({
      status: 'success',
      message: 'User account suspended',
      data: { userId },
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error.message,
    });
  }
};

export const getPendingApprovals = async (req, res) => {
  try {
    const snapshot = await db.collection('users')
      .where('status', '==', 'pending')
      .orderBy('created_at', 'desc')
      .get();

    const users = [];
    snapshot.forEach(doc => {
      users.push({ id: doc.id, ...doc.data() });
    });

    res.status(200).json({
      status: 'success',
      data: users,
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error.message,
    });
  }
};

export default {
  getDashboard,
  approveUser,
  rejectUser,
  suspendUser,
  getPendingApprovals,
};
