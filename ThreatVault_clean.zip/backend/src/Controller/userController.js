import { db } from '../config/firebase.js';

export const getAllUsers = async (req, res) => {
  try {
    const snapshot = await db.collection('users').orderBy('created_at', 'desc').get();
    const users = [];
    snapshot.forEach(doc => {
      users.push({ id: doc.id, ...doc.data() });
    });

    res.status(200).json({
      status: 'success',
      data: users,
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error.message,
    });
  }
};

export const getUserById = async (req, res) => {
  try {
    const { id } = req.params;
    const userDoc = await db.collection('users').doc(id).get();

    if (!userDoc.exists) {
      return res.status(404).json({
        status: 'error',
        message: 'User not found',
      });
    }

    res.status(200).json({
      status: 'success',
      data: { id: userDoc.id, ...userDoc.data() },
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error.message,
    });
  }
};

export const updateUser = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, active_role, status, employee_id, org_code, department } = req.body;

    const userRef = db.collection('users').doc(id);
    const userDoc = await userRef.get();

    if (!userDoc.exists) {
      return res.status(404).json({ status: 'error', message: 'User not found' });
    }

    const updateData = {
      updated_at: new Date().toISOString()
    };

    if (name !== undefined) updateData.name = name;
    if (active_role !== undefined) updateData.active_role = active_role;
    if (status !== undefined) updateData.status = status;
    if (employee_id !== undefined) updateData.employee_id = employee_id;
    if (org_code !== undefined) updateData.org_code = org_code;
    if (department !== undefined) updateData.department = department;

    await userRef.update(updateData);

    const updatedDoc = await userRef.get();

    res.status(200).json({
      status: 'success',
      message: 'User updated successfully',
      data: { id: updatedDoc.id, ...updatedDoc.data() },
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error.message,
    });
  }
};

export const deleteUser = async (req, res) => {
  try {
    const { id } = req.params;

    await db.collection('users').doc(id).delete();

    res.status(200).json({
      status: 'success',
      message: 'User deleted successfully',
      data: { id },
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error.message,
    });
  }
};

export const getUserProfile = async (req, res) => {
  try {
    const userId = req.user.id;

    const userDoc = await db.collection('users').doc(userId).get();

    if (!userDoc.exists) {
      return res.status(404).json({
        status: 'error',
        message: 'User not found',
      });
    }

    const userData = userDoc.data();
    const data = {
      id: userDoc.id,
      name: userData.name,
      email: userData.email,
      activeRole: userData.active_role === 'admin' || userData.active_role === 'administrator' ? 'administrator' : userData.active_role,
      status: userData.status,
      employeeId: userData.employee_id,
      orgCode: userData.org_code,
      department: userData.department,
      requestedRole: userData.role_requested,
      createdAt: userData.created_at,
      twoFactorEnabled: userData.two_factor_enabled
    };

    res.status(200).json({
      status: 'success',
      data: data,
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error.message,
    });
  }
};

export const updateUserProfile = async (req, res) => {
  try {
    const id = req.user.id;
    const { name, employee_id, org_code, department } = req.body;

    const userRef = db.collection('users').doc(id);
    const updateData = {
      updated_at: new Date().toISOString()
    };

    if (name !== undefined) updateData.name = name;
    if (employee_id !== undefined) updateData.employee_id = employee_id;
    if (org_code !== undefined) updateData.org_code = org_code;
    if (department !== undefined) updateData.department = department;

    await userRef.update(updateData);
    const updatedDoc = await userRef.get();

    res.status(200).json({
      status: 'success',
      message: 'Profile updated successfully',
      data: { id: updatedDoc.id, ...updatedDoc.data() },
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error.message,
    });
  }
};

export default {
  getAllUsers,
  getUserById,
  updateUser,
  deleteUser,
  getUserProfile,
  updateUserProfile,
};
