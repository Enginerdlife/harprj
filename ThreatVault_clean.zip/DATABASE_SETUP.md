# ThreatVault Database Setup Guide

## Current Primary Database: Firebase Firestore

Your ThreatVault instance is currently configured to use **Firebase Firestore**. You do **NOT** need to install PostgreSQL locally for the current version of the project.

### Firebase Configuration:
1. Ensure your `.env` file has the correct Firebase credentials:
   ```env
   FIREBASE_PROJECT_ID=...
   FIREBASE_CLIENT_EMAIL=...
   FIREBASE_PRIVATE_KEY="..."
   ```
2. The backend will automatically connect to Firestore on startup.

---

## Alternative/Legacy: PostgreSQL Setup

If you explicitly wish to switch the project back to PostgreSQL, follow these steps. **Note: This requires modifying the backend configuration code.**

### Option 1: Install PostgreSQL Locally
... (rest of the content) ...
